# RankForge (Paper 1.21.11)

Budowanie: `mvn clean package` (Java 21) -> `target/RankForge.jar` -> wrzuć do `plugins/`.

Pierwsze uruchomienie tworzy `plugins/RankForge/` z: `ranks.yml`, `players.yml`, `Icons/`.

Komendy (perm `rankforge.admin`, domyślnie OP): `/rank help`
