package pl.rankforge;

import io.papermc.paper.chat.ChatRenderer;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class ChatListener implements Listener {
    private final RankForge plugin;

    public ChatListener(RankForge plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onChat(AsyncChatEvent e) {
        Player p = e.getPlayer();
        RankForge.PendingInput in = plugin.inputs().remove(p.getUniqueId());
        if (in != null) {
            e.setCancelled(true);
            String text = PlainTextComponentSerializer.plainText().serialize(e.message()).trim();
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (text.equalsIgnoreCase("anuluj")) in.onCancel().run();
                else in.handler().accept(text);
            });
            return;
        }
        e.renderer(ChatRenderer.viewerUnaware((source, name, message) -> plugin.ranks().formatChat(source, message)));
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        plugin.ranks().apply(e.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        plugin.inputs().remove(e.getPlayer().getUniqueId());
        plugin.ranks().release(e.getPlayer());
    }
}
