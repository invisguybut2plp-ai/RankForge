package pl.rankforge;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.minimessage.MiniMessage;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class Rank {
    private static final MiniMessage MM = MiniMessage.miniMessage();

    public final String name;
    public String prefixText;
    public List<String> colors = new ArrayList<>();
    public boolean bold = false;
    public String nameColor = "#ffffff";
    public String chatColor = "#ffffff";
    public int weight = 10;
    public String parent = null;
    public List<String> permissions = new ArrayList<>();

    public Rank(String name) {
        this.name = name.toLowerCase(Locale.ROOT);
        this.prefixText = "[" + name.toUpperCase(Locale.ROOT) + "]";
    }

    public static int rgb(String hex, int def) {
        if (hex == null) return def;
        TextColor c = TextColor.fromHexString(hex);
        return c == null ? def : c.value();
    }

    public boolean hasPrefix() {
        return prefixText != null && !prefixText.isBlank();
    }

    /** Prefix jako MiniMessage: 0 kolorow = bialy, 1 = jednolity, 2+ = gradient. */
    public String prefixMini() {
        String t = MM.escapeTags(prefixText == null ? "" : prefixText);
        if (bold) t = "<bold>" + t + "</bold>";
        if (colors.isEmpty()) return t;
        if (colors.size() == 1) return "<color:" + colors.get(0) + ">" + t + "</color>";
        return "<gradient:" + String.join(":", colors) + ">" + t + "</gradient>";
    }

    public Component prefix() {
        return hasPrefix() ? MM.deserialize(prefixMini()) : Component.empty();
    }

    public Component nameComponent(String playerName) {
        return Component.text(playerName, TextColor.color(rgb(nameColor, 0xFFFFFF)));
    }

    public TextColor chat() {
        return TextColor.color(rgb(chatColor, 0xFFFFFF));
    }
}
