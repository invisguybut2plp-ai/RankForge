package pl.rankforge.gui;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import pl.rankforge.RankForge;

import java.util.List;
import java.util.function.Consumer;

/** Paleta 16 777 216 kolorow: suwaki R/G/B (przyciski -50 -10 -1 / +1 +10 +50), presety, HEX. */
public class ColorPickerGui extends Gui {
    private static final int[] PRESETS = {0xFF0000, 0xFF7F00, 0xFFFF00, 0x00FF00, 0x00FFFF, 0x0000FF, 0x7F00FF, 0xFF00FF, 0xFFFFFF};
    private static final Material[] PRESET_MATS = {Material.RED_DYE, Material.ORANGE_DYE, Material.YELLOW_DYE,
            Material.LIME_DYE, Material.CYAN_DYE, Material.BLUE_DYE, Material.PURPLE_DYE, Material.MAGENTA_DYE, Material.WHITE_DYE};
    private static final int[] DELTAS = {-50, -10, -1, 0, 0, 0, 1, 10, 50};
    private static final String[] CH = {"R", "G", "B"};
    private static final TextColor[] CC = {TextColor.color(0xFF5555), TextColor.color(0x55FF55), TextColor.color(0x5555FF)};
    private static final Material[] PANES = {Material.RED_STAINED_GLASS_PANE, Material.LIME_STAINED_GLASS_PANE, Material.BLUE_STAINED_GLASS_PANE};
    private static final Material[] DYES = {Material.RED_DYE, Material.GREEN_DYE, Material.BLUE_DYE};

    private final RankForge plugin;
    private final Player player;
    private final Consumer<String> onPick;
    private final Runnable onCancel;
    private final int[] v = new int[3];

    public ColorPickerGui(RankForge plugin, Player player, int rgb, Consumer<String> onPick, Runnable onCancel) {
        this.plugin = plugin;
        this.player = player;
        this.onPick = onPick;
        this.onCancel = onCancel;
        set(rgb);
        this.inv = Bukkit.createInventory(this, 54, Component.text("Wybierz kolor"));
    }

    private void set(int rgb) {
        v[0] = (rgb >> 16) & 255;
        v[1] = (rgb >> 8) & 255;
        v[2] = rgb & 255;
    }

    private int rgb() {
        return (v[0] << 16) | (v[1] << 8) | v[2];
    }

    private String hex() {
        return String.format("#%06x", rgb());
    }

    private static int clamp(int x) {
        return Math.max(0, Math.min(255, x));
    }

    public void open() {
        draw();
        player.openInventory(inv);
    }

    private void draw() {
        inv.clear();
        ItemStack filler = Items.make(Material.GRAY_STAINED_GLASS_PANE, Component.text(" "), List.of());
        for (int i = 0; i < 54; i++) inv.setItem(i, filler);

        inv.setItem(4, Items.dyed(Material.LEATHER_CHESTPLATE, rgb(),
                Component.text(hex(), TextColor.color(rgb())),
                List.of(Component.text("R " + v[0] + "  G " + v[1] + "  B " + v[2]),
                        Component.text("16 777 216 odcieni", NamedTextColor.DARK_GRAY))));

        for (int ch = 0; ch < 3; ch++) {
            int base = 9 + ch * 9;
            for (int col = 0; col < 9; col++) {
                int d = DELTAS[col];
                if (d == 0) continue;
                inv.setItem(base + col, Items.make(PANES[ch],
                        Component.text((d > 0 ? "+" : "") + d + " " + CH[ch], CC[ch]), List.of()));
            }
            int filled = v[ch] * 16 / 255;
            inv.setItem(base + 4, Items.make(DYES[ch], Component.text(CH[ch] + ": " + v[ch], CC[ch]),
                    List.of(Component.text("\u2588".repeat(filled) + "\u2591".repeat(16 - filled), CC[ch]))));
        }

        for (int i = 0; i < PRESETS.length; i++) {
            inv.setItem(36 + i, Items.make(PRESET_MATS[i],
                    Component.text(String.format("#%06x", PRESETS[i]), TextColor.color(PRESETS[i])),
                    List.of(Component.text("Kliknij, aby ustawic"))));
        }
        inv.setItem(45, Items.make(Material.NAME_TAG, Component.text("Wpisz HEX", NamedTextColor.YELLOW),
                List.of(Component.text("np. #ff8800 - wpisz na czacie"))));
        inv.setItem(47, Items.make(Material.BLACK_DYE, Component.text("Ciemniej", NamedTextColor.GRAY), List.of()));
        inv.setItem(48, Items.make(Material.LIGHT_GRAY_DYE, Component.text("Jasniej", NamedTextColor.WHITE), List.of()));
        inv.setItem(49, Items.make(Material.LIME_CONCRETE, Component.text("ZATWIERDZ " + hex(), NamedTextColor.GREEN), List.of()));
        inv.setItem(53, Items.make(Material.RED_CONCRETE, Component.text("Anuluj", NamedTextColor.RED), List.of()));
    }

    @Override
    public void click(InventoryClickEvent e) {
        int s = e.getSlot();
        if (s >= 9 && s < 36) {
            int ch = (s - 9) / 9;
            int d = DELTAS[(s - 9) % 9];
            if (d != 0) {
                v[ch] = clamp(v[ch] + d);
                draw();
            }
        } else if (s >= 36 && s < 45) {
            set(PRESETS[s - 36]);
            draw();
        } else if (s == 45) {
            plugin.awaitInput(player, "<yellow>Wpisz kolor HEX na czacie (np. <white>#ff8800</white>) lub <white>anuluj</white>.",
                    text -> {
                        String h = text.startsWith("#") ? text.substring(1) : text;
                        try {
                            if (h.length() != 6) throw new NumberFormatException();
                            set(Integer.parseInt(h, 16));
                        } catch (NumberFormatException ex) {
                            plugin.msg(player, "<red>To nie jest poprawny kolor HEX.");
                        }
                        open();
                    }, this::open);
        } else if (s == 47) {
            for (int i = 0; i < 3; i++) v[i] = clamp(v[i] - 15);
            draw();
        } else if (s == 48) {
            for (int i = 0; i < 3; i++) v[i] = clamp(v[i] + 15);
            draw();
        } else if (s == 49) {
            onPick.accept(hex());
        } else if (s == 53) {
            onCancel.run();
        }
    }
}
