package pl.rankforge.gui;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import pl.rankforge.PixelArt;
import pl.rankforge.Rank;
import pl.rankforge.RankForge;

import java.util.ArrayList;
import java.util.List;

public class RankEditorGui extends Gui {
    private final RankForge plugin;
    private final Player player;
    private final Rank rank;

    public RankEditorGui(RankForge plugin, Player player, Rank rank) {
        this.plugin = plugin;
        this.player = player;
        this.rank = rank;
        this.inv = Bukkit.createInventory(this, 27, Component.text("Ranga: " + rank.name));
    }

    public void open() {
        draw();
        player.openInventory(inv);
    }

    private void changed() {
        plugin.ranks().save();
        plugin.ranks().applyAll();
        draw();
    }

    private void draw() {
        inv.clear();
        ItemStack filler = Items.make(Material.GRAY_STAINED_GLASS_PANE, Component.text(" "), List.of());
        for (int i = 0; i < 27; i++) inv.setItem(i, filler);

        Component prefix = rank.hasPrefix() ? rank.prefix() : Component.text("(brak prefiksu)", NamedTextColor.DARK_GRAY);

        inv.setItem(4, Items.make(Material.PAPER, Component.text("Podglad", NamedTextColor.YELLOW), List.of(
                prefix.append(Component.space()).append(rank.nameComponent(player.getName()))
                        .append(Component.text(": Hej wszystkim!", rank.chat())))));

        inv.setItem(10, Items.make(Material.NAME_TAG, Component.text("Tekst prefiksu", NamedTextColor.GOLD), List.of(
                Component.text("Teraz: ").append(prefix),
                Component.empty(),
                Component.text("Kliknij i wpisz na czacie", NamedTextColor.YELLOW))));

        List<Component> colorLore = new ArrayList<>();
        for (String c : rank.colors) {
            colorLore.add(Component.text("\u25A0 " + c, TextColor.color(Rank.rgb(c, 0xFFFFFF))));
        }
        if (rank.colors.isEmpty()) colorLore.add(Component.text("(biały)", NamedTextColor.DARK_GRAY));
        colorLore.add(Component.empty());
        colorLore.add(Component.text("LPM: dodaj kolor (2+ = gradient)", NamedTextColor.YELLOW));
        colorLore.add(Component.text("PPM: usun ostatni | Shift+PPM: wyczysc", NamedTextColor.YELLOW));
        inv.setItem(11, Items.make(Material.GLOW_INK_SAC, Component.text("Kolory prefiksu", NamedTextColor.GOLD), colorLore));

        inv.setItem(12, Items.make(Material.WRITABLE_BOOK,
                Component.text("Pogrubienie: " + (rank.bold ? "TAK" : "NIE"), rank.bold ? NamedTextColor.GREEN : NamedTextColor.RED),
                List.of(Component.text("Kliknij, aby przelaczyc", NamedTextColor.YELLOW))));

        inv.setItem(13, Items.dyed(Material.LEATHER_HELMET, Rank.rgb(rank.nameColor, 0xFFFFFF),
                Component.text("Kolor nicku " + rank.nameColor, TextColor.color(Rank.rgb(rank.nameColor, 0xFFFFFF))),
                List.of(Component.text("Kliknij, aby wybrac z palety", NamedTextColor.YELLOW))));

        inv.setItem(14, Items.dyed(Material.LEATHER_BOOTS, Rank.rgb(rank.chatColor, 0xFFFFFF),
                Component.text("Kolor wiadomosci " + rank.chatColor, TextColor.color(Rank.rgb(rank.chatColor, 0xFFFFFF))),
                List.of(Component.text("Kliknij, aby wybrac z palety", NamedTextColor.YELLOW))));

        inv.setItem(15, Items.make(Material.CLOCK, Component.text("Waga: " + rank.weight, NamedTextColor.GOLD), List.of(
                Component.text("Wyzsza waga = wyzej w tabie"),
                Component.text("LPM +1 | PPM -1 | Shift = 10", NamedTextColor.YELLOW))));

        List<Component> iconLore = new ArrayList<>(PixelArt.render(plugin.ranks().iconFile(rank), 12));
        iconLore.add(Component.empty());
        iconLore.add(Component.text("Plik: Icons/" + rank.name + ".png", NamedTextColor.DARK_GRAY));
        iconLore.add(Component.text("Podmien plik, potem kliknij tutaj", NamedTextColor.YELLOW));
        inv.setItem(16, Items.make(Material.PAINTING, Component.text("Ikona rangi", NamedTextColor.GOLD), iconLore));

        List<Component> permLore = new ArrayList<>();
        int shown = 0;
        for (String p : rank.permissions) {
            if (shown++ >= 8) { permLore.add(Component.text("...")); break; }
            permLore.add(Component.text("- " + p, NamedTextColor.WHITE));
        }
        permLore.add(Component.empty());
        permLore.add(Component.text("/rank perm " + rank.name + " add <permisja>", NamedTextColor.YELLOW));
        inv.setItem(20, Items.make(Material.BOOK, Component.text("Permisje: " + rank.permissions.size(), NamedTextColor.GOLD), permLore));

        inv.setItem(22, Items.make(Material.EMERALD, Component.text("Gotowe", NamedTextColor.GREEN),
                List.of(Component.text("Zmiany zapisuja sie na biezaco"))));
    }

    @Override
    public void click(InventoryClickEvent e) {
        ClickType ct = e.getClick();
        switch (e.getSlot()) {
            case 10 -> plugin.awaitInput(player,
                    "<yellow>Wpisz na czacie tekst prefiksu (np. <white>[ADMIN]</white>), <white>-</white> = brak, <white>anuluj</white> = wroc.",
                    text -> {
                        rank.prefixText = text.equals("-") ? "" : text;
                        changed();
                        open();
                    }, this::open);
            case 11 -> {
                if (ct.isRightClick()) {
                    if (ct.isShiftClick()) rank.colors.clear();
                    else if (!rank.colors.isEmpty()) rank.colors.remove(rank.colors.size() - 1);
                    changed();
                } else {
                    int init = rank.colors.isEmpty() ? 0xFFFFFF : Rank.rgb(rank.colors.get(rank.colors.size() - 1), 0xFFFFFF);
                    new ColorPickerGui(plugin, player, init, hex -> {
                        rank.colors.add(hex);
                        changed();
                        open();
                    }, this::open).open();
                }
            }
            case 12 -> {
                rank.bold = !rank.bold;
                changed();
            }
            case 13 -> new ColorPickerGui(plugin, player, Rank.rgb(rank.nameColor, 0xFFFFFF), hex -> {
                rank.nameColor = hex;
                changed();
                open();
            }, this::open).open();
            case 14 -> new ColorPickerGui(plugin, player, Rank.rgb(rank.chatColor, 0xFFFFFF), hex -> {
                rank.chatColor = hex;
                changed();
                open();
            }, this::open).open();
            case 15 -> {
                int d = ct.isShiftClick() ? 10 : 1;
                if (ct.isRightClick()) d = -d;
                rank.weight = Math.max(0, Math.min(999, rank.weight + d));
                changed();
            }
            case 16 -> {
                plugin.ranks().ensureIcon(rank);
                changed();
            }
            case 22 -> player.closeInventory();
            default -> { }
        }
    }
}
