package pl.rankforge;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import pl.rankforge.gui.RankEditorGui;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class RankCommand implements CommandExecutor, TabCompleter {
    private final RankForge plugin;
    private final RankManager rm;

    public RankCommand(RankForge plugin) {
        this.plugin = plugin;
        this.rm = plugin.ranks();
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (!s.hasPermission("rankforge.admin")) {
            plugin.msg(s, "<red>Brak uprawnien.");
            return true;
        }
        if (a.length == 0 || a[0].equalsIgnoreCase("help")) {
            help(s);
            return true;
        }
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "create" -> {
                if (a.length < 2) { plugin.msg(s, "<gray>/rank create <nazwa>"); return true; }
                Rank r = rm.create(a[1]);
                if (r == null) { plugin.msg(s, "<red>Zla nazwa (a-z, 0-9, _ -) lub ranga juz istnieje."); return true; }
                plugin.msg(s, "<green>Utworzono range <white>" + r.name + "</white>.");
                if (s instanceof Player p) new RankEditorGui(plugin, p, r).open();
            }
            case "edit" -> {
                if (!(s instanceof Player p)) { plugin.msg(s, "<red>Tylko dla graczy."); return true; }
                Rank r = a.length > 1 ? rm.get(a[1]) : null;
                if (r == null) { plugin.msg(s, "<red>/rank edit <ranga>"); return true; }
                new RankEditorGui(plugin, p, r).open();
            }
            case "delete" -> {
                if (a.length < 2) { plugin.msg(s, "<gray>/rank delete <ranga>"); return true; }
                if (rm.delete(a[1])) plugin.msg(s, "<green>Usunieto range.");
                else plugin.msg(s, "<red>Nie ma takiej rangi (rangi <white>default</white> nie mozna usunac).");
            }
            case "list" -> {
                plugin.msg(s, "<gold>Rangi:");
                for (Rank r : rm.sorted()) {
                    s.sendMessage(Component.text(" - ", NamedTextColor.DARK_GRAY)
                            .append(r.hasPrefix() ? r.prefix().append(Component.space()) : Component.empty())
                            .append(Component.text(r.name, NamedTextColor.WHITE))
                            .append(Component.text(" (waga " + r.weight + ")", NamedTextColor.GRAY)));
                }
            }
            case "info" -> {
                Rank r = a.length > 1 ? rm.get(a[1]) : null;
                if (r == null) { plugin.msg(s, "<red>/rank info <ranga>"); return true; }
                s.sendMessage(Component.text("--- Ranga: ", NamedTextColor.GOLD)
                        .append(r.hasPrefix() ? r.prefix() : Component.text(r.name, NamedTextColor.WHITE)));
                for (Component line : PixelArt.render(rm.iconFile(r), 16)) s.sendMessage(line);
                plugin.msg(s, "<gray>Waga: <white>" + r.weight + "</white> | Dziedziczy po: <white>"
                        + (r.parent == null ? "-" : r.parent) + "</white> | Permisji: <white>" + r.permissions.size());
            }
            case "set" -> {
                if (a.length < 3) { plugin.msg(s, "<gray>/rank set <gracz> <ranga>"); return true; }
                Rank r = rm.get(a[2]);
                OfflinePlayer t = Bukkit.getPlayerExact(a[1]);
                if (t == null) {
                    t = Bukkit.getOfflinePlayer(a[1]);
                    if (!t.hasPlayedBefore()) { plugin.msg(s, "<red>Nie znam takiego gracza."); return true; }
                }
                if (r == null) { plugin.msg(s, "<red>Nie ma takiej rangi."); return true; }
                rm.setRank(t.getUniqueId(), r);
                plugin.msg(s, "<green>Gracz <white>" + a[1] + "</white> ma teraz range <white>" + r.name + "</white>.");
            }
            case "remove" -> {
                if (a.length < 2) { plugin.msg(s, "<gray>/rank remove <gracz>"); return true; }
                OfflinePlayer t = Bukkit.getPlayerExact(a[1]);
                if (t == null) t = Bukkit.getOfflinePlayer(a[1]);
                rm.clearRank(t.getUniqueId());
                plugin.msg(s, "<green>Gracz wraca do rangi <white>default</white>.");
            }
            case "perm" -> perm(s, a);
            case "parent" -> {
                if (a.length < 3) { plugin.msg(s, "<gray>/rank parent <ranga> <rodzic|none>"); return true; }
                Rank r = rm.get(a[1]);
                if (r == null) { plugin.msg(s, "<red>Nie ma takiej rangi."); return true; }
                if (a[2].equalsIgnoreCase("none")) {
                    r.parent = null;
                } else {
                    Rank p = rm.get(a[2]);
                    if (p == null) { plugin.msg(s, "<red>Nie ma rangi-rodzica."); return true; }
                    for (Rank cur = p; cur != null; cur = cur.parent == null ? null : rm.get(cur.parent)) {
                        if (cur == r) { plugin.msg(s, "<red>To stworzyloby petle dziedziczenia."); return true; }
                    }
                    r.parent = p.name;
                }
                rm.save();
                rm.applyAll();
                plugin.msg(s, "<green>Zapisano.");
            }
            case "weight" -> {
                if (a.length < 3) { plugin.msg(s, "<gray>/rank weight <ranga> <liczba>"); return true; }
                Rank r = rm.get(a[1]);
                if (r == null) { plugin.msg(s, "<red>Nie ma takiej rangi."); return true; }
                try {
                    r.weight = Math.max(0, Math.min(999, Integer.parseInt(a[2])));
                } catch (NumberFormatException ex) {
                    plugin.msg(s, "<red>Podaj liczbe.");
                    return true;
                }
                rm.save();
                rm.applyAll();
                plugin.msg(s, "<green>Waga ustawiona na <white>" + r.weight + "</white>.");
            }
            case "reload" -> {
                rm.load();
                rm.applyAll();
                plugin.msg(s, "<green>Przeladowano rangi i ikony.");
            }
            default -> help(s);
        }
        return true;
    }

    private void perm(CommandSender s, String[] a) {
        if (a.length < 3) { plugin.msg(s, "<gray>/rank perm <ranga> <add|remove|list> [permisja]"); return; }
        Rank r = rm.get(a[1]);
        if (r == null) { plugin.msg(s, "<red>Nie ma takiej rangi."); return; }
        switch (a[2].toLowerCase(Locale.ROOT)) {
            case "add" -> {
                if (a.length < 4) { plugin.msg(s, "<gray>/rank perm " + r.name + " add <permisja> <dark_gray>(minus z przodu = zabron)"); return; }
                if (!r.permissions.contains(a[3])) r.permissions.add(a[3]);
                rm.save();
                rm.applyAll();
                plugin.msg(s, "<green>Dodano <white>" + a[3] + "</white> do rangi " + r.name + ".");
            }
            case "remove" -> {
                if (a.length < 4) { plugin.msg(s, "<gray>/rank perm " + r.name + " remove <permisja>"); return; }
                if (r.permissions.remove(a[3])) {
                    rm.save();
                    rm.applyAll();
                    plugin.msg(s, "<green>Usunieto <white>" + a[3] + "</white>.");
                } else {
                    plugin.msg(s, "<red>Ranga nie ma takiej permisji.");
                }
            }
            case "list" -> {
                plugin.msg(s, "<gold>Permisje rangi " + r.name + ":");
                if (r.permissions.isEmpty()) s.sendMessage(Component.text(" (brak)", NamedTextColor.GRAY));
                for (String p : r.permissions) s.sendMessage(Component.text(" - " + p, NamedTextColor.WHITE));
                if (r.parent != null) plugin.msg(s, "<gray>+ dziedziczone po <white>" + r.parent);
            }
            default -> plugin.msg(s, "<gray>/rank perm <ranga> <add|remove|list> [permisja]");
        }
    }

    private void help(CommandSender s) {
        plugin.msg(s, "<gold>Komendy:");
        String[] lines = {
                "/rank create <nazwa> <dark_gray>- nowa ranga + GUI edycji",
                "/rank edit <ranga> <dark_gray>- GUI (prefix, kolory, ikona)",
                "/rank delete <ranga>",
                "/rank list | /rank info <ranga>",
                "/rank set <gracz> <ranga> | /rank remove <gracz>",
                "/rank perm <ranga> add|remove|list <permisja>",
                "/rank parent <ranga> <rodzic|none>",
                "/rank weight <ranga> <liczba> <dark_gray>- kolejnosc w tabie",
                "/rank reload <dark_gray>- przeladuj pliki i ikony"
        };
        for (String l : lines) plugin.msg(s, "<yellow>" + l);
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String label, String[] a) {
        if (!s.hasPermission("rankforge.admin")) return List.of();
        List<String> out = new ArrayList<>();
        if (a.length == 1) {
            out.addAll(List.of("create", "edit", "delete", "list", "info", "set", "remove", "perm", "parent", "weight", "reload"));
        } else {
            String sub = a[0].toLowerCase(Locale.ROOT);
            if (a.length == 2) {
                switch (sub) {
                    case "edit", "delete", "info", "perm", "parent", "weight" -> rm.sorted().forEach(r -> out.add(r.name));
                    case "set", "remove" -> Bukkit.getOnlinePlayers().forEach(p -> out.add(p.getName()));
                    default -> { }
                }
            } else if (a.length == 3) {
                switch (sub) {
                    case "perm" -> out.addAll(List.of("add", "remove", "list"));
                    case "set" -> rm.sorted().forEach(r -> out.add(r.name));
                    case "parent" -> { rm.sorted().forEach(r -> out.add(r.name)); out.add("none"); }
                    default -> { }
                }
            } else if (a.length == 4 && sub.equals("perm") && a[2].equalsIgnoreCase("remove")) {
                Rank r = rm.get(a[1]);
                if (r != null) out.addAll(r.permissions);
            }
        }
        String last = a[a.length - 1].toLowerCase(Locale.ROOT);
        out.removeIf(x -> !x.toLowerCase(Locale.ROOT).startsWith(last));
        return out;
    }
}
