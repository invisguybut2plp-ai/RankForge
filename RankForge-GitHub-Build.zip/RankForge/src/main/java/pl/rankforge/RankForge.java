package pl.rankforge;

import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import pl.rankforge.gui.GuiListener;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

public class RankForge extends JavaPlugin {
    public record PendingInput(Consumer<String> handler, Runnable onCancel) {}

    private static final MiniMessage MM = MiniMessage.miniMessage();
    private RankManager ranks;
    private final Map<UUID, PendingInput> inputs = new ConcurrentHashMap<>();

    @Override
    public void onEnable() {
        ranks = new RankManager(this);
        ranks.load();

        Bukkit.getPluginManager().registerEvents(new GuiListener(), this);
        Bukkit.getPluginManager().registerEvents(new ChatListener(this), this);

        RankCommand cmd = new RankCommand(this);
        getCommand("rank").setExecutor(cmd);
        getCommand("rank").setTabCompleter(cmd);

        ranks.applyAll();
        getLogger().info("RankForge wlaczony - zaladowano " + ranks.sorted().size() + " rang.");
    }

    @Override
    public void onDisable() {
        if (ranks != null) ranks.shutdown();
    }

    public RankManager ranks() {
        return ranks;
    }

    public Map<UUID, PendingInput> inputs() {
        return inputs;
    }

    public void msg(CommandSender s, String mini) {
        s.sendMessage(MM.deserialize("<dark_gray>[<gold>Rangi</gold>]</dark_gray> " + mini));
    }

    /** Zamyka GUI i czeka na wiadomosc gracza na czacie (wpisz "anuluj" aby wrocic). */
    public void awaitInput(Player p, String prompt, Consumer<String> handler, Runnable onCancel) {
        inputs.put(p.getUniqueId(), new PendingInput(handler, onCancel));
        Bukkit.getScheduler().runTask(this, (Runnable) p::closeInventory);
        msg(p, prompt);
    }
}
