package pl.rankforge.gui;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import pl.rankforge.PixelArt;
import pl.rankforge.Rank;
import pl.rankforge.RankForge;
import pl.rankforge.kit.KitUtil;
import pl.rankforge.kit.Lang;

import java.util.ArrayList;
import java.util.List;

/** Rank editor GUI. Every visible text comes from lang/<language>.yml (section rank.editor). */
public class RankEditorGui extends Gui {
    private final RankForge plugin;
    private final Player player;
    private final Rank rank;

    public RankEditorGui(RankForge plugin, Player player, Rank rank) {
        this.plugin = plugin;
        this.player = player;
        this.rank = rank;
        this.inv = Bukkit.createInventory(this, 36, Component.text(Lang.s("rank.editor.title", "rank", rank.name)));
    }

    public void open() {
        draw();
        player.openInventory(inv);
    }

    private void changed() {
        plugin.ranks().save();
        plugin.ranks().applyAll();
        draw();
    }

    /** Single text rank.editor.<key> as a component. */
    private static Component t(String key, String... kv) {
        return KitUtil.mm(Lang.s("rank.editor." + key, kv));
    }

    /** Lore list rank.editor.<key> as components. */
    private static List<Component> tl(String key, String... kv) {
        List<Component> out = new ArrayList<>();
        for (String line : Lang.l("rank.editor." + key, kv)) out.add(KitUtil.mm(line));
        return out;
    }

    private void draw() {
        inv.clear();
        ItemStack filler = Items.make(Material.GRAY_STAINED_GLASS_PANE, Component.text(" "), List.of());
        for (int i = 0; i < 36; i++) inv.setItem(i, filler);

        Component prefix = rank.hasPrefix() ? rank.prefix() : t("no-prefix");
        Component line = prefix.append(Component.space()).append(rank.nameComponent(player.getName()));

        inv.setItem(4, Items.make(Material.PAPER, t("preview.name", "rank", rank.name), List.of(
                t("preview.chat").append(line).append(Component.text(": " + Lang.s("rank.editor.hello"), rank.chat())),
                t("preview.tab").append(line))));

        List<Component> pre = new ArrayList<>();
        pre.add(t("prefix.now").append(prefix));
        pre.add(Component.empty());
        pre.addAll(tl("prefix.lore"));
        inv.setItem(10, Items.make(Material.NAME_TAG, t("prefix.name"), pre));

        List<Component> cl = new ArrayList<>();
        for (String c : rank.colors) cl.add(Component.text("■ " + c, TextColor.color(Rank.rgb(c, 0xFFFFFF))));
        if (rank.colors.isEmpty()) cl.add(t("colors.white"));
        cl.add(Component.empty());
        cl.addAll(tl("colors.lore"));
        inv.setItem(12, Items.make(Material.GLOW_INK_SAC, t("colors.name"), cl));

        inv.setItem(14, Items.make(Material.WRITABLE_BOOK, t(rank.bold ? "bold.on" : "bold.off"), tl("bold.lore")));

        inv.setItem(16, Items.dyed(Material.LEATHER_HELMET, Rank.rgb(rank.nameColor, 0xFFFFFF),
                t("name-color.name", "color", rank.nameColor), tl("name-color.lore")));

        inv.setItem(19, Items.dyed(Material.LEATHER_BOOTS, Rank.rgb(rank.chatColor, 0xFFFFFF),
                t("chat-color.name", "color", rank.chatColor), tl("chat-color.lore")));

        inv.setItem(21, Items.make(Material.CLOCK, t("weight.name", "weight", String.valueOf(rank.weight)), tl("weight.lore")));

        boolean active = plugin.pack().has(rank);
        List<Component> il = new ArrayList<>(PixelArt.render(plugin.ranks().iconFile(rank), 12));
        il.add(Component.empty());
        il.add(t("icon.file", "rank", rank.name));
        il.add(t(active ? "icon.active" : "icon.missing"));
        il.add(t("icon.reload"));
        inv.setItem(23, Items.make(Material.PAINTING, t("icon.name"), il));

        List<Component> pl = new ArrayList<>();
        int n = 0;
        for (String p : rank.permissions) {
            if (n++ >= 8) { pl.add(Component.text("...")); break; }
            pl.add(Component.text("- " + p, NamedTextColor.WHITE));
        }
        if (rank.permissions.isEmpty()) pl.add(t("perms.none"));
        pl.add(Component.empty());
        pl.addAll(tl("perms.lore"));
        inv.setItem(25, Items.make(Material.BOOK, t("perms.name", "count", String.valueOf(rank.permissions.size())), pl));

        inv.setItem(31, Items.make(Material.EMERALD, t("done.name"), tl("done.lore")));
    }

    @Override
    public void click(InventoryClickEvent e) {
        ClickType ct = e.getClick();
        switch (e.getSlot()) {
            case 10 -> plugin.awaitInput(player,
                    Lang.s("rank.editor.prompt.prefix"),
                    text -> { rank.prefixText = text.equals("-") ? "" : text; changed(); open(); }, this::open);
            case 12 -> {
                if (ct.isRightClick()) {
                    if (ct.isShiftClick()) rank.colors.clear();
                    else if (!rank.colors.isEmpty()) rank.colors.remove(rank.colors.size() - 1);
                    changed();
                } else {
                    int init = rank.colors.isEmpty() ? 0xFFFFFF : Rank.rgb(rank.colors.get(rank.colors.size() - 1), 0xFFFFFF);
                    new ColorPickerGui(plugin, player, init, hex -> { rank.colors.add(hex); changed(); open(); }, this::open).open();
                }
            }
            case 14 -> { rank.bold = !rank.bold; changed(); }
            case 16 -> new ColorPickerGui(plugin, player, Rank.rgb(rank.nameColor, 0xFFFFFF),
                    hex -> { rank.nameColor = hex; changed(); open(); }, this::open).open();
            case 19 -> new ColorPickerGui(plugin, player, Rank.rgb(rank.chatColor, 0xFFFFFF),
                    hex -> { rank.chatColor = hex; changed(); open(); }, this::open).open();
            case 21 -> {
                int d = ct.isShiftClick() ? 10 : 1;
                if (ct.isRightClick()) d = -d;
                rank.weight = Math.max(0, Math.min(999, rank.weight + d));
                changed();
            }
            case 23 -> { plugin.pack().rebuild(true); changed(); }
            case 25 -> {
                if (ct.isRightClick()) {
                    if (ct.isShiftClick()) rank.permissions.clear();
                    else if (!rank.permissions.isEmpty()) rank.permissions.remove(rank.permissions.size() - 1);
                    changed();
                } else {
                    plugin.awaitInput(player, Lang.s("rank.editor.prompt.perm"),
                            text -> {
                                if (!text.isBlank() && !rank.permissions.contains(text)) rank.permissions.add(text);
                                changed();
                                open();
                            }, this::open);
                }
            }
            case 31 -> player.closeInventory();
            default -> { }
        }
    }
}
