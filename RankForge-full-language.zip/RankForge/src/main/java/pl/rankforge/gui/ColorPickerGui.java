package pl.rankforge.gui;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import pl.rankforge.ColorMath;
import pl.rankforge.RankForge;
import pl.rankforge.kit.KitUtil;
import pl.rankforge.kit.Lang;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * All visible texts come from lang/<language>.yml (section rank.picker).
 * Paleta jak w Paincie: siatka 8x5 (poziomo odcień, pionowo nasycenie), po prawej pionowy suwak jasności.
 * PPM na siatce przybliża zakres odcieni (więc da się wybrać każdy z 16 777 216 kolorów).
 */
public class ColorPickerGui extends Gui {
    private static final int[] PRESETS = {0xFF0000, 0xFF7F00, 0xFFFF00, 0x00FF00, 0x00FFFF, 0x0000FF, 0x7F00FF, 0xFF00FF, 0xFFFFFF};
    private static final int[] DELTAS = {-50, -10, -1, 0, 0, 0, 1, 10, 50};
    private static final String[] CH = {"R", "G", "B"};
    private static final TextColor[] CC = {TextColor.color(0xFF5555), TextColor.color(0x55FF55), TextColor.color(0x5555FF)};
    private static final Material[] PANES = {Material.RED_STAINED_GLASS_PANE, Material.LIME_STAINED_GLASS_PANE, Material.BLUE_STAINED_GLASS_PANE};
    private static final Material[] DYES = {Material.RED_DYE, Material.GREEN_DYE, Material.BLUE_DYE};

    private final RankForge plugin;
    private final Player player;
    private final Consumer<String> onPick;
    private final Runnable onCancel;
    private int rgb;
    private double h, s, l;
    private double zStart = 0, zSpan = 360;
    private boolean rgbMode = false;

    public ColorPickerGui(RankForge plugin, Player player, int initial, Consumer<String> onPick, Runnable onCancel) {
        this.plugin = plugin;
        this.player = player;
        this.onPick = onPick;
        this.onCancel = onCancel;
        setRgb(initial);
        this.inv = Bukkit.createInventory(this, 54, Component.text(Lang.s("rank.picker.title")));
    }

    private void setRgb(int c) {
        rgb = c & 0xFFFFFF;
        double[] a = ColorMath.rgbToHsl(rgb);
        if (a[1] > 0.01 && a[2] > 0.01 && a[2] < 0.99) h = a[0];
        s = a[1];
        l = a[2];
    }

    private void applyHsl() {
        s = Math.max(0, Math.min(1, s));
        l = Math.max(0, Math.min(1, l));
        rgb = ColorMath.hslToRgb(h, s, l);
    }

    private static String hex(int c) {
        return String.format("#%06x", c);
    }

    /** Single text rank.picker.<key> as a component. */
    private static Component t(String key, String... kv) {
        return KitUtil.mm(Lang.s("rank.picker." + key, kv));
    }

    /** Lore list rank.picker.<key> as components. */
    private static List<Component> tl(String key, String... kv) {
        List<Component> out = new ArrayList<>();
        for (String line : Lang.l("rank.picker." + key, kv)) out.add(KitUtil.mm(line));
        return out;
    }

    private double hueAt(int c) {
        return ColorMath.norm(zStart + c * zSpan / 7.0);
    }

    public void open() {
        draw();
        player.openInventory(inv);
    }

    private void draw() {
        inv.clear();
        ItemStack filler = Items.make(Material.GRAY_STAINED_GLASS_PANE, Component.text(" "), List.of());
        for (int i = 0; i < 54; i++) inv.setItem(i, filler);
        if (rgbMode) drawRgb(); else drawPalette();

        inv.setItem(45, Items.make(Material.NAME_TAG, t("hex.name"), tl("hex.lore")));
        inv.setItem(46, Items.make(rgbMode ? Material.PAINTING : Material.COMPARATOR,
                t(rgbMode ? "mode-palette" : "mode-rgb"), tl("mode-lore")));
        inv.setItem(48, Items.make(Material.BLACK_DYE, t("darker"), List.of()));
        inv.setItem(50, Items.make(Material.WHITE_DYE, t("lighter"), List.of()));
        double[] hsl = ColorMath.rgbToHsl(rgb);
        inv.setItem(49, Items.dyed(Material.LEATHER_CHESTPLATE, rgb,
                t("confirm.name", "hex", hex(rgb)),
                tl("confirm.lore",
                        "r", String.valueOf((rgb >> 16) & 255), "g", String.valueOf((rgb >> 8) & 255), "b", String.valueOf(rgb & 255),
                        "h", String.format("%.0f", hsl[0]), "s", String.format("%.0f", hsl[1] * 100), "l", String.format("%.0f", hsl[2] * 100))));
        inv.setItem(53, Items.make(Material.RED_CONCRETE, t("cancel"), List.of()));
    }

    private void drawPalette() {
        double step = zSpan / 7.0;
        int bestCol = 0;
        double bestD = 1e9;
        for (int c = 0; c < 8; c++) {
            double d = Math.abs(ColorMath.norm(h - hueAt(c) + 180) - 180);
            if (d < bestD) { bestD = d; bestCol = c; }
        }
        boolean inWindow = bestD <= step / 2 + 0.01;
        int bestRow = (int) Math.max(0, Math.min(4, Math.round((1 - s) / 0.2)));

        for (int r = 0; r < 5; r++) {
            for (int c = 0; c < 8; c++) {
                int col = ColorMath.hslToRgb(hueAt(c), 1 - 0.2 * r, l);
                ItemStack it = Items.dyed(Material.LEATHER_HORSE_ARMOR, col,
                        Component.text(hex(col), NamedTextColor.WHITE),
                        tl("cell-lore"));
                if (inWindow && c == bestCol && r == bestRow) it = Items.glow(it);
                inv.setItem(r * 9 + c, it);
            }
            double lv = 0.9 - 0.2 * r;
            int lc = ColorMath.hslToRgb(h, s, lv);
            ItemStack li = Items.dyed(Material.LEATHER_CHESTPLATE, lc,
                    t("brightness.name", "value", String.format("%.0f", lv * 100)),
                    tl("brightness.lore"));
            if (Math.abs(l - lv) <= 0.1) li = Items.glow(li);
            inv.setItem(r * 9 + 8, li);
        }
        inv.setItem(47, Items.make(Material.SPYGLASS, t("zoom-out.name"),
                tl("zoom-out.lore", "from", String.format("%.0f", zStart), "to", String.format("%.0f", zStart + zSpan))));
        inv.setItem(51, Items.make(Material.LIGHT_GRAY_DYE, t("grays.name"), tl("grays.lore")));
        inv.setItem(52, Items.make(Material.BOOK, t("help.name"), tl("help.lore")));
    }

    private void drawRgb() {
        for (int ch = 0; ch < 3; ch++) {
            int base = 9 + ch * 9;
            int val = (rgb >> (16 - 8 * ch)) & 255;
            for (int col = 0; col < 9; col++) {
                int d = DELTAS[col];
                if (d == 0) continue;
                inv.setItem(base + col, Items.make(PANES[ch], Component.text((d > 0 ? "+" : "") + d + " " + CH[ch], CC[ch]), List.of()));
            }
            int filled = val * 16 / 255;
            inv.setItem(base + 4, Items.make(DYES[ch], Component.text(CH[ch] + ": " + val, CC[ch]),
                    List.of(Component.text("\u2588".repeat(filled) + "\u2591".repeat(16 - filled), CC[ch]))));
        }
        inv.setItem(4, Items.dyed(Material.LEATHER_CHESTPLATE, rgb, Component.text(hex(rgb), TextColor.color(rgb)), List.of()));
        for (int i = 0; i < PRESETS.length; i++) {
            inv.setItem(36 + i, Items.make(presetMat(i),
                    Component.text(hex(PRESETS[i]), TextColor.color(PRESETS[i])), tl("preset-lore")));
        }
    }

    private static Material presetMat(int i) {
        return new Material[]{Material.RED_DYE, Material.ORANGE_DYE, Material.YELLOW_DYE, Material.LIME_DYE, Material.CYAN_DYE,
                Material.BLUE_DYE, Material.PURPLE_DYE, Material.MAGENTA_DYE, Material.WHITE_DYE}[i];
    }

    @Override
    public void click(InventoryClickEvent e) {
        int slot = e.getSlot();
        boolean right = e.getClick().isRightClick();
        if (!rgbMode && slot < 45) {
            int r = slot / 9, c = slot % 9;
            if (c == 8) {
                l = 0.9 - 0.2 * r;
                applyHsl();
            } else if (right) {
                double center = hueAt(c);
                zSpan = Math.max(7, zSpan / 4);
                zStart = center - zSpan / 2;
            } else {
                h = hueAt(c);
                s = 1 - 0.2 * r;
                applyHsl();
            }
            draw();
            return;
        }
        if (rgbMode && slot >= 9 && slot < 36) {
            int ch = (slot - 9) / 9, d = DELTAS[(slot - 9) % 9];
            if (d != 0) {
                int shift = 16 - 8 * ch;
                int v = Math.max(0, Math.min(255, ((rgb >> shift) & 255) + d));
                setRgb((rgb & ~(255 << shift)) | (v << shift));
                draw();
            }
            return;
        }
        if (rgbMode && slot >= 36 && slot < 45) {
            setRgb(PRESETS[slot - 36]);
            draw();
            return;
        }
        switch (slot) {
            case 45 -> plugin.awaitInput(player, Lang.s("rank.picker.hex-prompt"),
                    text -> {
                        String hx = text.startsWith("#") ? text.substring(1) : text;
                        try {
                            if (hx.length() != 6) throw new NumberFormatException();
                            setRgb(Integer.parseInt(hx, 16));
                        } catch (NumberFormatException ex) {
                            plugin.tr(player, "picker.hex-invalid");
                        }
                        open();
                    }, this::open);
            case 46 -> { rgbMode = !rgbMode; draw(); }
            case 47 -> {
                if (!rgbMode) {
                    double center = zStart + zSpan / 2;
                    zSpan = Math.min(360, zSpan * 4);
                    zStart = zSpan >= 360 ? 0 : center - zSpan / 2;
                    draw();
                }
            }
            case 48 -> { l -= 0.03; applyHsl(); draw(); }
            case 50 -> { l += 0.03; applyHsl(); draw(); }
            case 51 -> { if (!rgbMode) { s = 0; applyHsl(); draw(); } }
            case 49 -> onPick.accept(hex(rgb));
            case 53 -> onCancel.run();
            default -> { }
        }
    }
}
