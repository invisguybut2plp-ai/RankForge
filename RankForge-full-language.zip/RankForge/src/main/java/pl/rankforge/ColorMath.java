package pl.rankforge;

/** Przeliczenia RGB <-> HSL (tak jak w palecie z Painta: odcień, nasycenie, jasność). */
public final class ColorMath {
    private ColorMath() {}

    public static double norm(double h) {
        return ((h % 360) + 360) % 360;
    }

    public static int hslToRgb(double h, double s, double l) {
        h = norm(h);
        s = Math.max(0, Math.min(1, s));
        l = Math.max(0, Math.min(1, l));
        double c = (1 - Math.abs(2 * l - 1)) * s;
        double x = c * (1 - Math.abs((h / 60) % 2 - 1));
        double m = l - c / 2;
        double r, g, b;
        if (h < 60) { r = c; g = x; b = 0; }
        else if (h < 120) { r = x; g = c; b = 0; }
        else if (h < 180) { r = 0; g = c; b = x; }
        else if (h < 240) { r = 0; g = x; b = c; }
        else if (h < 300) { r = x; g = 0; b = c; }
        else { r = c; g = 0; b = x; }
        int ri = (int) Math.round((r + m) * 255);
        int gi = (int) Math.round((g + m) * 255);
        int bi = (int) Math.round((b + m) * 255);
        return (ri << 16) | (gi << 8) | bi;
    }

    /** @return {h (0-360), s (0-1), l (0-1)} */
    public static double[] rgbToHsl(int rgb) {
        double r = ((rgb >> 16) & 255) / 255.0, g = ((rgb >> 8) & 255) / 255.0, b = (rgb & 255) / 255.0;
        double max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b));
        double l = (max + min) / 2, h = 0, s = 0;
        double d = max - min;
        if (d > 1e-9) {
            s = d / (1 - Math.abs(2 * l - 1));
            if (max == r) h = 60 * (((g - b) / d) % 6);
            else if (max == g) h = 60 * ((b - r) / d + 2);
            else h = 60 * ((r - g) / d + 4);
        }
        return new double[]{norm(h), Math.max(0, Math.min(1, s)), l};
    }
}
