package pl.rankforge.kit;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

import java.util.*;

/** One kit definition. Everything here is persisted in kits.yml. */
public final class Kit {
    public final String name;
    public String displayName;
    public List<String> description = new ArrayList<>();
    public Material icon = Material.BOOK;
    /** Number of item rows: 1..6 -> 9..54 kit slots. */
    public int rows = 3;
    /** Sort position in the kit list (lower first). */
    public int order = 0;
    public final Map<Integer, ItemStack> items = new TreeMap<>();

    /** Lower-case rank names allowed to redeem. */
    public final Set<String> ranks = new LinkedHashSet<>();
    /** Optional minimum rank (by RankForge weight). Empty = none. */
    public String minRank = "";
    /** Per-rank cooldown override in seconds. */
    public final Map<String, Long> rankCooldowns = new LinkedHashMap<>();
    /** Default cooldown in seconds (0 = none). */
    public long cooldown = 86400;
    public boolean oneTime = false;

    public boolean enabled = true;
    public boolean hidden = false;
    /** Ranks inheriting from an allowed rank may redeem as well. */
    public boolean inherit = true;
    public boolean dropIfFull = false;
    public boolean autoEquip = false;
    public boolean announce = false;
    public String permission = "";
    /** Console commands. Prefix with "player:" to run as the player. {player} is replaced. */
    public List<String> commands = new ArrayList<>();
    public List<String> worlds = new ArrayList<>();
    /** Epoch millis, 0 = no limit. */
    public long availableFrom = 0;
    public long availableUntil = 0;
    public int xp = 0;

    public String createdBy = "";
    public long createdAt = 0;
    public String editedBy = "";
    public long editedAt = 0;

    public Kit(String name) {
        this.name = name;
        this.displayName = "<gold>" + name;
    }

    public int size() { return rows * 9; }

    public void trim() { items.keySet().removeIf(s -> s >= size()); }
}
