package pl.rankforge.kit.gui;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import pl.rankforge.RankForge;
import pl.rankforge.gui.Gui;
import pl.rankforge.gui.Items;
import pl.rankforge.kit.Kit;
import pl.rankforge.kit.KitManager;
import pl.rankforge.kit.KitUtil;
import pl.rankforge.kit.Lang;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Main /kit menu: every kit the player may see, with status, paginated. Look is configurable. */
public class KitListGui extends Gui {
    private final RankForge plugin;
    private final KitManager kits;
    private final Player p;
    private int page;
    private List<Kit> visible = new ArrayList<>();
    private int rows;
    private int per;
    private boolean paged;
    private int pages;

    public KitListGui(RankForge plugin, KitManager kits, Player p, int page) {
        this.plugin = plugin;
        this.kits = kits;
        this.p = p;
        this.page = page;
    }

    private boolean admin() {
        return p.hasPermission("rankforge.kit.admin") || p.hasPermission("rankforge.admin");
    }

    public void open() {
        build();
        p.openInventory(inv);
        kits.sound(p, "open", "block.chest.open,0.6,1.2");
    }

    private void build() {
        boolean adm = admin();
        visible = new ArrayList<>();
        for (Kit k : kits.all()) {
            if (!k.enabled && !adm) continue;
            if (k.hidden && !adm && kits.check(p, k).status() != KitManager.Status.OK) continue;
            visible.add(k);
        }
        int total = visible.size();
        int cfgRows = plugin.getConfig().getInt("kits.gui.rows", 0);
        rows = cfgRows > 0 ? Math.min(6, cfgRows) : (total <= 45 ? Math.max(1, (total + 8) / 9) : 6);
        paged = total > rows * 9;
        if (paged && rows < 2) rows = 2;
        per = paged ? (rows - 1) * 9 : rows * 9;
        pages = Math.max(1, (total + per - 1) / per);
        page = Math.max(0, Math.min(page, pages - 1));

        inv = Bukkit.createInventory(this, rows * 9, KitUtil.mm(Lang.s("menu.title")));
        Material f = Material.matchMaterial(plugin.getConfig().getString("kits.gui.filler", "GRAY_STAINED_GLASS_PANE"));
        if (f != null && f.isItem() && !f.isAir()) Ui.fill(inv, f);

        for (int i = 0; i < per; i++) {
            int idx = page * per + i;
            if (idx >= total) break;
            inv.setItem(i, icon(visible.get(idx)));
        }
        if (total == 0) inv.setItem(Math.min(4, rows * 9 - 1), Ui.btn(Material.BARRIER, Lang.s("menu.empty")));
        if (paged) {
            int b = (rows - 1) * 9;
            if (page > 0) inv.setItem(b, Ui.btn(Material.ARROW, Lang.s("btn.prev"), Lang.s("btn.page", "page", String.valueOf(page), "pages", String.valueOf(pages))));
            inv.setItem(b + 4, Ui.btn(Material.BARRIER, Lang.s("btn.close")));
            if (page < pages - 1) inv.setItem(b + 8, Ui.btn(Material.ARROW, Lang.s("btn.next"), Lang.s("btn.page", "page", String.valueOf(page + 2), "pages", String.valueOf(pages))));
        }
    }

    /** Icon material depends on status when kits.gui.status-icons.* is set (KEEP = the kit's own icon). */
    private Material material(Kit k, KitManager.Status st) {
        String key = switch (st) {
            case OK -> "ready";
            case COOLDOWN -> "cooldown";
            case DISABLED -> "disabled";
            default -> "locked";
        };
        Material m = Material.matchMaterial(plugin.getConfig().getString("kits.gui.status-icons." + key, "KEEP"));
        return (m != null && m.isItem() && !m.isAir()) ? m : k.icon;
    }

    private ItemStack icon(Kit k) {
        KitManager.Check c = kits.check(p, k);
        String[] kv = kits.placeholders(p, k);
        ItemStack it = Items.make(material(k, c.status()),
                KitUtil.c(Lang.s("menu.item-name", kv)),
                KitUtil.lore(Lang.l("menu.item-lore", Map.of("description", k.description), kv)));
        boolean glow = plugin.getConfig().getBoolean("kits.gui.glow-available", true);
        return (glow && c.status() == KitManager.Status.OK) ? Items.glow(it) : it;
    }

    @Override
    public void click(InventoryClickEvent e) {
        int s = e.getSlot();
        if (paged && s >= (rows - 1) * 9) {
            int off = s - (rows - 1) * 9;
            if (off == 0 && page > 0) { page--; kits.sound(p, "page", "item.book.page_turn,0.8,1.0"); build(); p.openInventory(inv); }
            else if (off == 8 && page < pages - 1) { page++; kits.sound(p, "page", "item.book.page_turn,0.8,1.0"); build(); p.openInventory(inv); }
            else if (off == 4) p.closeInventory();
            return;
        }
        int idx = page * per + s;
        if (s < 0 || s >= per || idx >= visible.size()) return;
        Kit k = visible.get(idx);
        int back = page;
        kits.sound(p, "click", "ui.button.click,0.8,1.0");
        Ui.later(plugin, () -> new KitPreviewGui(plugin, kits, p, k, () -> new KitListGui(plugin, kits, p, back).open()).open());
    }
}
