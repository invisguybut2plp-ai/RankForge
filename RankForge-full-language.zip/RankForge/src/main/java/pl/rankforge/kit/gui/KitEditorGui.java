package pl.rankforge.kit.gui;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import pl.rankforge.RankForge;
import pl.rankforge.gui.Gui;
import pl.rankforge.kit.Kit;
import pl.rankforge.kit.KitManager;
import pl.rankforge.kit.KitUtil;
import pl.rankforge.kit.Lang;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

/** Two-page kit editor: page 1 = basics, page 2 = advanced. Every change is saved immediately. */
public class KitEditorGui extends Gui {
    /** Cooldown presets (seconds) cycled by the cooldown button: none, 30m, 1h, 6h, 12h, 1d, 3d, 7d, 30d. */
    private static final long[] PRESETS = {0, 1800, 3600, 21600, 43200, 86400, 259200, 604800, 2592000};

    private final RankForge plugin;
    private final KitManager kits;
    private final Player p;
    private final Kit kit;
    private int page;

    public KitEditorGui(RankForge plugin, KitManager kits, Player p, Kit kit) {
        this(plugin, kits, p, kit, 0);
    }

    public KitEditorGui(RankForge plugin, KitManager kits, Player p, Kit kit, int page) {
        this.plugin = plugin;
        this.kits = kits;
        this.p = p;
        this.kit = kit;
        this.page = page;
    }

    public void open() {
        inv = Bukkit.createInventory(this, 54, KitUtil.mm(Lang.s("ed.title", "kit", kit.name, "page", String.valueOf(page + 1))));
        draw();
        p.openInventory(inv);
    }

    private void changed() {
        kits.touch(kit, p.getName());
        kits.sound(p, "save", "entity.experience_orb.pickup,0.6,1.5");
        draw();
    }

    private void reopen() {
        Ui.later(plugin, () -> new KitEditorGui(plugin, kits, p, kit, page).open());
    }

    /** Asks for a chat message (prompt.<key>), then runs the handler and reopens the editor. */
    private void ask(String promptKey, Consumer<String> handler) {
        plugin.awaitInput(p, Lang.s("prompt." + promptKey) + Lang.s("msg.cancel-hint"), s -> {
            handler.accept(s);
            reopen();
        }, this::reopen);
    }

    private static String esc(String s) {
        return KitUtil.MM.escapeTags(s);
    }

    private static String str(int n) { return String.valueOf(n); }

    private void draw() {
        Ui.fill(inv, Material.GRAY_STAINED_GLASS_PANE);
        if (page == 0) drawBasic();
        else drawAdvanced();
        if (page == 1) inv.setItem(45, Ui.btn(Material.ARROW, Lang.s("ed.nav-basic")));
        if (page == 0) inv.setItem(53, Ui.btn(Material.ARROW, Lang.s("ed.nav-adv")));
        inv.setItem(49, Ui.btn(Material.BARRIER, Lang.s("ed.close"), Lang.l("ed.close-lore")));
    }

    private void drawBasic() {
        inv.setItem(10, Ui.b(Material.NAME_TAG, "name", "current", esc(kit.displayName)));
        List<String> dl = new ArrayList<>();
        for (String s : kit.description) dl.add("<dark_gray>- <white>" + esc(s));
        inv.setItem(11, Ui.b(Material.WRITABLE_BOOK, "desc", Map.of("lines", dl), "count", str(kit.description.size())));
        inv.setItem(12, Ui.b(kit.icon, "icon", "material", kit.icon.name()));
        inv.setItem(13, Ui.b(Material.COMPARATOR, "order", "order", str(kit.order)));
        inv.setItem(14, Ui.b(Material.HOPPER, "size", "rows", str(kit.rows), "slots", str(kit.size())));
        inv.setItem(15, Ui.b(Material.CHEST, "items", "stacks", str(kit.items.size()), "slots", str(kit.size())));
        inv.setItem(16, Ui.b(Material.DIAMOND, "ranks", "ranks", esc(kits.ranksText(kit))));
        inv.setItem(19, Ui.b(Material.CLOCK, "cooldown", "current", KitUtil.formatDuration(kit.cooldown)));
        inv.setItem(20, Ui.t(kit.oneTime, "onetime"));
        inv.setItem(21, Ui.t(kit.enabled, "enabled"));
        inv.setItem(22, Ui.t(kit.hidden, "hidden"));
        inv.setItem(23, Ui.b(Material.ENDER_EYE, "preview"));
        inv.setItem(24, Ui.b(Material.LAVA_BUCKET, "clear"));
        inv.setItem(25, Ui.b(Material.TNT, "delete"));
        inv.setItem(26, Ui.b(Material.ENDER_CHEST, "copy"));
        inv.setItem(40, Ui.b(Material.BOOK, "info",
                "created-by", kit.createdBy.isBlank() ? "?" : kit.createdBy, "created-at", KitUtil.formatDate(kit.createdAt),
                "edited-by", kit.editedBy.isBlank() ? "-" : kit.editedBy, "edited-at", KitUtil.formatDate(kit.editedAt)));
    }

    private void drawAdvanced() {
        inv.setItem(10, Ui.t(kit.inherit, "inherit"));
        inv.setItem(11, Ui.t(kit.dropIfFull, "drop"));
        inv.setItem(12, Ui.t(kit.autoEquip, "equip"));
        inv.setItem(13, Ui.t(kit.announce, "announce"));
        inv.setItem(14, Ui.b(Material.PAPER, "perm", "current", kit.permission.isBlank() ? Lang.s("word.none") : esc(kit.permission)));
        List<String> cl = new ArrayList<>();
        for (String s : kit.commands) cl.add("<dark_gray>- <white>" + esc(s));
        inv.setItem(15, Ui.b(Material.COMMAND_BLOCK, "cmds", Map.of("lines", cl)));
        inv.setItem(16, Ui.b(Material.GRASS_BLOCK, "worlds", "current", kit.worlds.isEmpty() ? Lang.s("word.none") : esc(String.join(", ", kit.worlds))));
        inv.setItem(19, Ui.b(Material.COMPASS, "from", "current", KitUtil.formatDate(kit.availableFrom)));
        inv.setItem(20, Ui.b(Material.REPEATER, "until", "current", KitUtil.formatDate(kit.availableUntil)));
        inv.setItem(21, Ui.b(Material.EXPERIENCE_BOTTLE, "xp", "current", str(kit.xp)));
    }

    @Override
    public void click(InventoryClickEvent e) {
        int s = e.getSlot();
        kits.sound(p, "click", "ui.button.click,0.8,1.0");
        if (s == 49) { p.closeInventory(); return; }
        if (s == 45 && page == 1) { page = 0; draw(); return; }
        if (s == 53 && page == 0) { page = 1; draw(); return; }
        if (page == 0) clickBasic(e, s);
        else clickAdvanced(e, s);
    }

    private void clickBasic(InventoryClickEvent e, int s) {
        boolean right = e.getClick().isRightClick();
        boolean shift = e.getClick().isShiftClick();
        switch (s) {
            case 10 -> ask("display-name", t -> {
                if (!t.isBlank()) { kit.displayName = t; kits.touch(kit, p.getName()); }
            });
            case 11 -> {
                if (shift && right) { kit.description.clear(); changed(); }
                else if (right) { if (!kit.description.isEmpty()) kit.description.remove(kit.description.size() - 1); changed(); }
                else ask("desc-line", t -> {
                    if (!t.isBlank()) { kit.description.add(t); kits.touch(kit, p.getName()); }
                });
            }
            case 12 -> {
                ItemStack cur = e.getCursor();
                if (cur != null && !cur.getType().isAir()) { kit.icon = cur.getType(); changed(); }
                else KitUtil.send(p, Lang.s("msg.pick-item"));
            }
            case 13 -> {
                int step = shift ? 10 : 1;
                kit.order += right ? -step : step;
                changed();
            }
            case 14 -> {
                int old = kit.rows;
                kit.rows = Math.max(1, Math.min(6, kit.rows + (right ? -1 : 1)));
                if (kit.rows < old) kit.trim();
                changed();
            }
            case 15 -> Ui.later(plugin, () -> new KitItemsEditor(plugin, kits, p, kit).open());
            case 16 -> Ui.later(plugin, () -> new KitRanksGui(plugin, kits, p, kit, 0).open());
            case 19 -> {
                if (shift && !right) {
                    ask("cooldown", t -> {
                        long v = KitUtil.parseDuration(t);
                        if (v < 0) KitUtil.send(p, Lang.s("msg.invalid-time"));
                        else { kit.cooldown = v; kits.touch(kit, p.getName()); }
                    });
                } else {
                    long cur = kit.cooldown;
                    long best;
                    if (right) {
                        best = PRESETS[PRESETS.length - 1];
                        for (long v : PRESETS) if (v < cur) best = v;
                    } else {
                        best = PRESETS[0];
                        for (int i = PRESETS.length - 1; i >= 0; i--) if (PRESETS[i] > cur) best = PRESETS[i];
                    }
                    kit.cooldown = best;
                    changed();
                }
            }
            case 20 -> { kit.oneTime = !kit.oneTime; changed(); }
            case 21 -> { kit.enabled = !kit.enabled; changed(); }
            case 22 -> { kit.hidden = !kit.hidden; changed(); }
            case 23 -> Ui.later(plugin, () -> new KitPreviewGui(plugin, kits, p, kit, this::reopen).open());
            case 24 -> Ui.later(plugin, () -> new ConfirmGui(plugin, p, Lang.s("ed.confirm.clear-title"),
                    Lang.l("ed.confirm.clear-info", "count", str(kit.items.size()), "kit", kit.name),
                    () -> { kit.items.clear(); kits.touch(kit, p.getName()); reopen(); }, this::reopen).open());
            case 25 -> Ui.later(plugin, () -> new ConfirmGui(plugin, p, Lang.s("ed.confirm.delete-title", "kit", kit.name),
                    Lang.l("ed.confirm.delete-info"),
                    () -> {
                        kits.delete(kit.name, p.getName());
                        p.closeInventory();
                        KitUtil.send(p, kits.text("deleted", "kit", kit.name));
                    }, this::reopen).open());
            case 26 -> {
                Runnable doIt = () -> {
                    int n = kits.importInventory(p, kit);
                    kits.touch(kit, p.getName());
                    KitUtil.send(p, Lang.s("msg.copied", "count", str(n)));
                    reopen();
                };
                if (kit.items.isEmpty()) Ui.later(plugin, doIt);
                else Ui.later(plugin, () -> new ConfirmGui(plugin, p, Lang.s("ed.confirm.replace-title"),
                        Lang.l("ed.confirm.replace-info"), doIt, this::reopen).open());
            }
            default -> { }
        }
    }

    private void clickAdvanced(InventoryClickEvent e, int s) {
        boolean right = e.getClick().isRightClick();
        boolean shift = e.getClick().isShiftClick();
        switch (s) {
            case 10 -> { kit.inherit = !kit.inherit; changed(); }
            case 11 -> { kit.dropIfFull = !kit.dropIfFull; changed(); }
            case 12 -> { kit.autoEquip = !kit.autoEquip; changed(); }
            case 13 -> { kit.announce = !kit.announce; changed(); }
            case 14 -> {
                if (right) { kit.permission = ""; changed(); }
                else ask("permission", t -> {
                    kit.permission = t.equalsIgnoreCase("none") ? "" : t;
                    kits.touch(kit, p.getName());
                });
            }
            case 15 -> {
                if (shift && right) { kit.commands.clear(); changed(); }
                else if (right) { if (!kit.commands.isEmpty()) kit.commands.remove(kit.commands.size() - 1); changed(); }
                else ask("command", t -> {
                    String cmd = t.startsWith("/") ? t.substring(1) : t;
                    if (!cmd.isBlank()) { kit.commands.add(cmd); kits.touch(kit, p.getName()); }
                });
            }
            case 16 -> {
                if (right) { kit.worlds.clear(); changed(); }
                else ask("world", t -> {
                    org.bukkit.World w = Bukkit.getWorld(t.trim());
                    if (w == null) KitUtil.send(p, Lang.s("msg.no-world", "world", esc(t)));
                    else if (kit.worlds.stream().noneMatch(x -> x.equalsIgnoreCase(w.getName()))) {
                        kit.worlds.add(w.getName());
                        kits.touch(kit, p.getName());
                    }
                });
            }
            case 19 -> {
                if (right) { kit.availableFrom = 0; changed(); }
                else ask("from", t -> {
                    long v = KitUtil.parseDate(t);
                    if (v < 0) KitUtil.send(p, Lang.s("msg.invalid-date"));
                    else { kit.availableFrom = v; kits.touch(kit, p.getName()); }
                });
            }
            case 20 -> {
                if (right) { kit.availableUntil = 0; changed(); }
                else ask("until", t -> {
                    long v = KitUtil.parseDate(t);
                    if (v < 0) KitUtil.send(p, Lang.s("msg.invalid-date"));
                    else { kit.availableUntil = v; kits.touch(kit, p.getName()); }
                });
            }
            case 21 -> ask("xp", t -> {
                try {
                    kit.xp = Math.max(0, Math.min(1_000_000, Integer.parseInt(t.trim())));
                    kits.touch(kit, p.getName());
                } catch (NumberFormatException ex) {
                    KitUtil.send(p, Lang.s("msg.not-number"));
                }
            });
            default -> { }
        }
    }
}
