package pl.rankforge.kit.gui;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import pl.rankforge.RankForge;
import pl.rankforge.gui.Gui;
import pl.rankforge.kit.KitUtil;
import pl.rankforge.kit.Lang;

import java.util.List;

/** Generic confirm / cancel menu for destructive actions. */
public class ConfirmGui extends Gui {
    private final RankForge plugin;
    private final Player p;
    private final String title;
    private final List<String> info;
    private final Runnable onConfirm;
    private final Runnable onCancel;

    public ConfirmGui(RankForge plugin, Player p, String title, List<String> info, Runnable onConfirm, Runnable onCancel) {
        this.plugin = plugin;
        this.p = p;
        this.title = title;
        this.info = info;
        this.onConfirm = onConfirm;
        this.onCancel = onCancel;
    }

    public void open() {
        inv = Bukkit.createInventory(this, 27, KitUtil.mm(title));
        Ui.fill(inv, Material.GRAY_STAINED_GLASS_PANE);
        inv.setItem(11, Ui.btn(Material.LIME_CONCRETE, Lang.s("confirm.yes"), Lang.l("confirm.yes-lore")));
        inv.setItem(13, Ui.btn(Material.PAPER, title, info));
        inv.setItem(15, Ui.btn(Material.RED_CONCRETE, Lang.s("confirm.no"), Lang.l("confirm.no-lore")));
        p.openInventory(inv);
    }

    @Override
    public void click(InventoryClickEvent e) {
        if (e.getSlot() == 11) Ui.later(plugin, onConfirm);
        else if (e.getSlot() == 15) Ui.later(plugin, onCancel);
    }
}
