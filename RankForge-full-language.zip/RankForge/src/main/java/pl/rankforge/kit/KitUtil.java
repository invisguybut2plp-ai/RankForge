package pl.rankforge.kit;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class KitUtil {
    public static final MiniMessage MM = MiniMessage.miniMessage();
    private static final Pattern PART = Pattern.compile("(\\d+)([wdhms])");
    private static final Pattern LEGACY = Pattern.compile("&([0-9a-fk-orA-FK-OR])");
    private static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    private KitUtil() {}

    private static String legacyTag(char c) {
        return switch (Character.toLowerCase(c)) {
            case '0' -> "<black>";
            case '1' -> "<dark_blue>";
            case '2' -> "<dark_green>";
            case '3' -> "<dark_aqua>";
            case '4' -> "<dark_red>";
            case '5' -> "<dark_purple>";
            case '6' -> "<gold>";
            case '7' -> "<gray>";
            case '8' -> "<dark_gray>";
            case '9' -> "<blue>";
            case 'a' -> "<green>";
            case 'b' -> "<aqua>";
            case 'c' -> "<red>";
            case 'd' -> "<light_purple>";
            case 'e' -> "<yellow>";
            case 'f' -> "<white>";
            case 'k' -> "<obfuscated>";
            case 'l' -> "<bold>";
            case 'm' -> "<strikethrough>";
            case 'n' -> "<underlined>";
            case 'o' -> "<italic>";
            default -> "<reset>";
        };
    }

    /** MiniMessage with legacy &-codes accepted too. */
    public static Component mm(String s) {
        Matcher m = LEGACY.matcher(s == null ? "" : s);
        StringBuilder sb = new StringBuilder();
        while (m.find()) m.appendReplacement(sb, Matcher.quoteReplacement(legacyTag(m.group(1).charAt(0))));
        m.appendTail(sb);
        return MM.deserialize(sb.toString());
    }

    /** Non-italic component for item names / lore. */
    public static Component c(String mini) {
        return mm(mini).decoration(TextDecoration.ITALIC, false);
    }

    public static List<Component> lore(List<String> lines) {
        List<Component> out = new ArrayList<>();
        for (String s : lines) out.add(c(s));
        return out;
    }

    /** The [Kits] prefix in the active language (lang key kit-prefix). */
    private static Component prefix() {
        return mm(Lang.s("kit-prefix"));
    }

    public static void send(CommandSender to, String mini) {
        to.sendMessage(prefix().append(mm(mini)));
    }

    public static void send(CommandSender to, Component msg) {
        to.sendMessage(prefix().append(msg));
    }

    public static String plain(String mini) {
        return PlainTextComponentSerializer.plainText().serialize(mm(mini));
    }

    public static ItemStack filler(Material m) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(Component.text(" "));
        it.setItemMeta(meta);
        return it;
    }

    /** "1d 2h 30m", "12h", "90s", "0"/"none" = 0. A bare number = seconds. Returns -1 if invalid. */
    public static long parseDuration(String in) {
        if (in == null) return -1;
        String s = in.trim().toLowerCase(Locale.ROOT).replace(" ", "");
        if (s.isEmpty()) return -1;
        if (s.equals("none") || s.equals("off")) return 0;
        try {
            if (s.matches("\\d{1,10}")) return Long.parseLong(s);
            Matcher m = PART.matcher(s);
            long total = 0;
            int end = 0;
            while (m.find()) {
                if (m.start() != end) return -1;
                long n = Long.parseLong(m.group(1));
                switch (m.group(2).charAt(0)) {
                    case 'w' -> total += n * 604800L;
                    case 'd' -> total += n * 86400L;
                    case 'h' -> total += n * 3600L;
                    case 'm' -> total += n * 60L;
                    default -> total += n;
                }
                end = m.end();
            }
            if (end == 0 || end != s.length() || total > 315_360_000L) return -1;
            return total;
        } catch (NumberFormatException ex) {
            return -1;
        }
    }

    public static String formatDuration(long secs) {
        if (secs <= 0) return Lang.s("word.none");
        long d = secs / 86400, h = (secs % 86400) / 3600, m = (secs % 3600) / 60, s = secs % 60;
        StringBuilder sb = new StringBuilder();
        if (d > 0) sb.append(d).append("d ");
        if (h > 0) sb.append(h).append("h ");
        if (m > 0) sb.append(m).append("m ");
        if (s > 0 && d == 0) sb.append(s).append("s");
        return sb.toString().trim();
    }

    /** "2026-12-24" or "2026-12-24 18:30" in the server time zone -> epoch millis, or -1. */
    public static long parseDate(String in) {
        if (in == null) return -1;
        String s = in.trim();
        try {
            LocalDateTime t = s.length() <= 10
                    ? LocalDate.parse(s).atStartOfDay()
                    : LocalDateTime.parse(s.replace(' ', 'T'));
            return t.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
        } catch (DateTimeParseException ex) {
            return -1;
        }
    }

    public static String formatDate(long millis) {
        if (millis <= 0) return Lang.s("word.none");
        return DATE.format(java.time.Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault()));
    }
}
