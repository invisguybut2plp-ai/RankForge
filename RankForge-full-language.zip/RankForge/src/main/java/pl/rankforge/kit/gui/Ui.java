package pl.rankforge.kit.gui;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import pl.rankforge.gui.Items;
import pl.rankforge.kit.KitUtil;
import pl.rankforge.kit.Lang;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

/** Small helpers shared by the kit GUIs. All texts come from the language file. */
final class Ui {
    private Ui() {}

    static void later(Plugin pl, Runnable r) {
        Bukkit.getScheduler().runTask(pl, r);
    }

    static ItemStack btn(Material m, String name, List<String> lines) {
        return Items.make(m, KitUtil.c(name), KitUtil.lore(lines));
    }

    static ItemStack btn(Material m, String name, String... lines) {
        return btn(m, name, new ArrayList<>(Arrays.asList(lines)));
    }

    /** Editor button: texts ed.<id>.name / ed.<id>.lore. */
    static ItemStack b(Material m, String id, String... kv) {
        return btn(m, Lang.s("ed." + id + ".name", kv), Lang.l("ed." + id + ".lore", kv));
    }

    static ItemStack b(Material m, String id, Map<String, List<String>> multi, String... kv) {
        return btn(m, Lang.s("ed." + id + ".name", kv), Lang.l("ed." + id + ".lore", multi, kv));
    }

    /** Editor on/off switch. */
    static ItemStack t(boolean on, String id) {
        List<String> l = new ArrayList<>();
        l.add(Lang.s(on ? "ui.on" : "ui.off"));
        l.addAll(Lang.l("ed." + id + ".lore"));
        l.add("");
        l.add(Lang.s("ui.toggle-hint"));
        ItemStack it = btn(on ? Material.LIME_DYE : Material.GRAY_DYE, Lang.s("ed." + id + ".name"), l);
        return on ? Items.glow(it) : it;
    }

    static void fill(Inventory inv, Material m) {
        ItemStack f = KitUtil.filler(m);
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, f.clone());
    }
}
