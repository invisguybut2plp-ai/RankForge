package pl.rankforge.kit;

import org.bukkit.configuration.file.YamlConfiguration;
import pl.rankforge.RankForge;

import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.Pattern;

/**
 * ALL texts of the plugin (rank GUIs, kit GUIs, items, chat messages, console logs). Config: {@code language: pl|en}.
 * Files live in plugins/RankForge/lang/ (created on first start, freely editable).
 * A key missing from the server's file falls back to the bundled file of the SAME language first
 * (so an old lang file never shows text in the wrong language) and only then to the bundled English text.
 * Placeholders look like {name}. A lore line that is only a placeholder is dropped when the value is empty.
 */
public final class Lang {
    private static final Pattern ONLY_PLACEHOLDER = Pattern.compile("\\{[a-z-]+\\}");
    private static YamlConfiguration cur = new YamlConfiguration();
    private static YamlConfiguration bundled = new YamlConfiguration();
    private static YamlConfiguration fallback = new YamlConfiguration();
    private static String code = "pl";

    private Lang() {}

    /** Active language code (the file name without .yml). */
    public static String code() {
        return code;
    }

    public static void load(RankForge plugin) {
        File dir = new File(plugin.getDataFolder(), "lang");
        dir.mkdirs();
        for (String c : new String[]{"pl", "en"}) {
            if (!new File(dir, c + ".yml").exists()) plugin.saveResource("lang/" + c + ".yml", false);
        }
        String want = plugin.getConfig().getString("language", "pl").toLowerCase(Locale.ROOT).trim().replaceAll("[^a-z0-9_-]", "");
        File f = new File(dir, want + ".yml");
        if (want.isEmpty() || !f.exists()) {
            plugin.getLogger().warning("Unknown language '" + want + "' (Nieznany jezyk) - using pl (available: files in plugins/RankForge/lang/).");
            want = "pl";
            f = new File(dir, "pl.yml");
        }
        code = want;
        cur = YamlConfiguration.loadConfiguration(f);
        bundled = loadBundled(plugin, want);
        fallback = loadBundled(plugin, "en");
    }

    private static YamlConfiguration loadBundled(RankForge plugin, String lang) {
        YamlConfiguration y = new YamlConfiguration();
        try (InputStream in = plugin.getResource("lang/" + lang + ".yml")) {
            if (in != null) {
                try (Reader r = new InputStreamReader(in, StandardCharsets.UTF_8)) {
                    y = YamlConfiguration.loadConfiguration(r);
                }
            }
        } catch (Exception ignored) { }
        return y;
    }

    private static String apply(String v, String... kv) {
        for (int i = 0; i + 1 < kv.length; i += 2) v = v.replace("{" + kv[i] + "}", kv[i + 1] == null ? "" : kv[i + 1]);
        return v;
    }

    /** Single text. kv = placeholder name, value, name, value... */
    public static String s(String key, String... kv) {
        String v = cur.getString(key);
        if (v == null) v = bundled.getString(key);
        if (v == null) v = fallback.getString(key);
        return apply(v == null ? key : v, kv);
    }

    public static List<String> l(String key, String... kv) {
        return l(key, Map.of(), kv);
    }

    /** List text; a line equal to "{key}" is replaced by the lines in {@code multi}. */
    public static List<String> l(String key, Map<String, List<String>> multi, String... kv) {
        List<String> raw = cur.isList(key) ? cur.getStringList(key)
                : bundled.isList(key) ? bundled.getStringList(key) : fallback.getStringList(key);
        Map<String, String> vals = new HashMap<>();
        for (int i = 0; i + 1 < kv.length; i += 2) vals.put(kv[i], kv[i + 1] == null ? "" : kv[i + 1]);
        List<String> out = new ArrayList<>();
        for (String line : raw) {
            String t = line.trim();
            if (ONLY_PLACEHOLDER.matcher(t).matches()) {
                String name = t.substring(1, t.length() - 1);
                if (multi.containsKey(name)) { out.addAll(multi.get(name)); continue; }
                if (vals.containsKey(name) && vals.get(name).isEmpty()) continue;
            }
            out.add(apply(line, kv));
        }
        return out;
    }
}
