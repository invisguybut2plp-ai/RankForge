package pl.rankforge.kit;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import pl.rankforge.RankForge;
import pl.rankforge.kit.gui.KitEditorGui;
import pl.rankforge.kit.gui.KitItemsEditor;

public class KitListener implements Listener {
    private final RankForge plugin;
    private final KitManager kits;

    public KitListener(RankForge plugin, KitManager kits) {
        this.plugin = plugin;
        this.kits = kits;
    }

    /** Tells players on join how many kits they can redeem (config: kits.notify-on-join). */
    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        if (!plugin.getConfig().getBoolean("kits.notify-on-join", true)) return;
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!p.isOnline() || !p.hasPermission("rankforge.kit") || p.hasPermission("rankforge.kit.bypass")) return;
            int n = kits.readyCount(p);
            if (n > 0) KitUtil.send(p, kits.text("join-notify", "count", String.valueOf(n)));
        }, 80L);
    }

    /** The item chest is a normal inventory: whatever is inside when it closes becomes the kit. */
    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (!(e.getInventory().getHolder() instanceof KitItemsEditor ed)) return;
        if (!(e.getPlayer() instanceof Player p)) return;
        Kit kit = ed.kit();
        if (kits.get(kit.name) != kit) return; // kit was deleted meanwhile
        ed.commit();
        kits.touch(kit, p.getName());
        KitUtil.send(p, Lang.s("msg.items-saved", "count", String.valueOf(kit.items.size())));
        if (plugin.isEnabled() && p.isOnline()) {
            Bukkit.getScheduler().runTask(plugin, () -> new KitEditorGui(plugin, kits, p, kit).open());
        }
    }
}
