package pl.rankforge.kit.gui;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import pl.rankforge.RankForge;
import pl.rankforge.kit.Kit;
import pl.rankforge.kit.KitManager;
import pl.rankforge.kit.KitUtil;

import java.util.Map;

/**
 * A normal, freely editable chest with exactly kit.size() slots. Move items in from your own
 * inventory (full metadata is kept); whatever is inside when you close it becomes the kit.
 * Deliberately NOT a {@code Gui}, because Gui cancels every click.
 */
public class KitItemsEditor implements InventoryHolder {
    private final RankForge plugin;
    private final KitManager kits;
    private final Player p;
    private final Kit kit;
    private Inventory inv;

    public KitItemsEditor(RankForge plugin, KitManager kits, Player p, Kit kit) {
        this.plugin = plugin;
        this.kits = kits;
        this.p = p;
        this.kit = kit;
    }

    public void open() {
        inv = Bukkit.createInventory(this, kit.size(), KitUtil.mm(pl.rankforge.kit.Lang.s("items.title", "kit", kit.name, "size", String.valueOf(kit.size()))));
        for (Map.Entry<Integer, ItemStack> e : kit.items.entrySet()) {
            if (e.getKey() < kit.size()) inv.setItem(e.getKey(), e.getValue().clone());
        }
        p.openInventory(inv);
        KitUtil.send(p, pl.rankforge.kit.Lang.s("msg.items-hint"));
    }

    /** Copies the chest contents into the kit (full ItemStack metadata is kept). */
    public void commit() {
        kit.items.clear();
        for (int i = 0; i < inv.getSize(); i++) {
            ItemStack it = inv.getItem(i);
            if (it != null && !it.getType().isAir()) kit.items.put(i, it.clone());
        }
    }

    public Kit kit() { return kit; }

    @Override
    public Inventory getInventory() { return inv; }
}
