package pl.rankforge.kit;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import pl.rankforge.RankForge;

/**
 * Optional PlaceholderAPI expansion. Only loaded when PlaceholderAPI is installed
 * (RankForge calls {@link #hook} behind an isPluginEnabled check).
 *
 * %rankforge_kit_count%            kits the player can redeem right now
 * %rankforge_kit_available_<kit>%  yes / no
 * %rankforge_kit_cooldown_<kit>%   ready / time left / unavailable
 * %rankforge_kit_rank_<kit>%       ranks that can redeem it
 * %rankforge_kit_redeemed_<kit>%   how many times the player redeemed it
 */
public class KitPlaceholders extends PlaceholderExpansion {
    private final RankForge plugin;
    private final KitManager kits;

    private KitPlaceholders(RankForge plugin, KitManager kits) {
        this.plugin = plugin;
        this.kits = kits;
    }

    public static void hook(RankForge plugin, KitManager kits) {
        new KitPlaceholders(plugin, kits).register();
        plugin.getLogger().info(Lang.s("log.papi"));
    }

    @Override public String getIdentifier() { return "rankforge"; }
    @Override public String getAuthor() { return "RankForge"; }
    @Override public String getVersion() { return plugin.getPluginMeta().getVersion(); }
    @Override public boolean persist() { return true; }

    @Override
    public String onRequest(OfflinePlayer offline, String params) {
        if (!params.startsWith("kit_")) return null;
        Player p = offline == null ? null : offline.getPlayer();
        if (params.equals("kit_count")) return p == null ? "0" : String.valueOf(kits.readyCount(p));

        int us = params.indexOf('_', 4);
        if (us < 0) return null;
        String type = params.substring(4, us);
        Kit k = kits.get(params.substring(us + 1));
        if (k == null) return "unknown kit";
        if (type.equals("rank")) return kits.ranksText(k);
        if (p == null) return "";

        KitManager.Check c = kits.check(p, k);
        switch (type) {
            case "available":
                return c.status() == KitManager.Status.OK ? "yes" : "no";
            case "cooldown":
                if (c.status() == KitManager.Status.OK) return "ready";
                if (c.status() == KitManager.Status.COOLDOWN) return KitUtil.formatDuration(c.remaining());
                return "unavailable";
            case "redeemed": {
                KitManager.Claim cl = kits.claim(p.getUniqueId(), k.name);
                return String.valueOf(cl == null ? 0 : cl.count);
            }
            default:
                return null;
        }
    }
}
