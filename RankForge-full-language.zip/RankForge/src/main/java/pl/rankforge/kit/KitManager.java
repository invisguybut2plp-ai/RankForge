package pl.rankforge.kit;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import pl.rankforge.Rank;
import pl.rankforge.RankForge;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class KitManager {
    public enum Status { OK, DISABLED, NO_PERMISSION, WRONG_RANK, WRONG_WORLD, NOT_YET, EXPIRED, ONE_TIME_DONE, COOLDOWN }

    public record Check(Status status, long remaining) {}

    /** Per player + kit: last redeem time and number of redemptions. */
    public static final class Claim {
        public long last;
        public int count;
    }

    private final RankForge plugin;
    private final Map<String, Kit> kits = new LinkedHashMap<>();
    private final Map<UUID, Map<String, Claim>> claims = new HashMap<>();
    private final ExecutorService io = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "RankForge-Kits-IO");
        t.setDaemon(true);
        return t;
    });
    private File kitsFile;
    private File dataFile;
    private File logFile;

    public KitManager(RankForge plugin) {
        this.plugin = plugin;
    }

    // ---------------------------------------------------------------- messages / config

    /** Text from the active language file (lang/<language>.yml), key msg.<key>. */
    public String text(String key, String... kv) {
        return Lang.s("msg." + key, kv);
    }

    /** Config kits.sounds.<key>: "sound.key,volume,pitch" (volume/pitch optional), or "none". */
    public void sound(Player p, String configKey, String def) {
        String v = plugin.getConfig().getString("kits.sounds." + configKey, def);
        if (v == null || v.isBlank() || v.equalsIgnoreCase("none")) return;
        String[] parts = v.split(",");
        float vol = 0.8f, pitch = 1.0f;
        try {
            if (parts.length > 1) vol = Float.parseFloat(parts[1].trim());
            if (parts.length > 2) pitch = Float.parseFloat(parts[2].trim());
        } catch (NumberFormatException ignored) { }
        p.playSound(p.getLocation(), parts[0].trim(), vol, pitch);
    }

    public RankForge plugin() { return plugin; }

    // ---------------------------------------------------------------- storage

    public synchronized void load() {
        plugin.getDataFolder().mkdirs();
        kitsFile = new File(plugin.getDataFolder(), "kits.yml");
        dataFile = new File(plugin.getDataFolder(), "kit-data.yml");
        logFile = new File(plugin.getDataFolder(), "kit-log.txt");
        kits.clear();
        claims.clear();

        YamlConfiguration y = readYaml(kitsFile);
        ConfigurationSection root = y.getConfigurationSection("kits");
        if (root != null) {
            for (String key : root.getKeys(false)) {
                try {
                    ConfigurationSection s = root.getConfigurationSection(key);
                    if (s == null) continue;
                    Kit k = readKit(key, s);
                    kits.put(k.name, k);
                } catch (Exception ex) {
                    plugin.getLogger().warning(Lang.s("log.kit-skipped", "kit", key, "error", String.valueOf(ex.getMessage())));
                }
            }
        }

        YamlConfiguration d = readYaml(dataFile);
        ConfigurationSection players = d.getConfigurationSection("players");
        if (players != null) {
            for (String u : players.getKeys(false)) {
                try {
                    UUID id = UUID.fromString(u);
                    ConfigurationSection ps = players.getConfigurationSection(u);
                    if (ps == null) continue;
                    Map<String, Claim> map = new HashMap<>();
                    for (String kn : ps.getKeys(false)) {
                        ConfigurationSection cs = ps.getConfigurationSection(kn);
                        if (cs == null) continue;
                        Claim c = new Claim();
                        c.last = cs.getLong("last", 0);
                        c.count = cs.getInt("count", 0);
                        map.put(kn, c);
                    }
                    claims.put(id, map);
                } catch (IllegalArgumentException ignored) { }
            }
        }
    }

    /** Loads a yaml file; a corrupt file is backed up (never silently overwritten). */
    private YamlConfiguration readYaml(File f) {
        YamlConfiguration y = new YamlConfiguration();
        if (!f.exists()) return y;
        try {
            y.load(f);
        } catch (IOException | InvalidConfigurationException ex) {
            File bak = new File(f.getParentFile(), f.getName() + ".broken-" + System.currentTimeMillis());
            try {
                Files.copy(f.toPath(), bak.toPath(), StandardCopyOption.REPLACE_EXISTING);
            } catch (IOException ignored) { }
            plugin.getLogger().severe(Lang.s("log.file-invalid", "file", f.getName(), "error", String.valueOf(ex.getMessage()), "backup", bak.getName()));
            return new YamlConfiguration();
        }
        return y;
    }

    private Kit readKit(String key, ConfigurationSection s) {
        Kit k = new Kit(key.toLowerCase(Locale.ROOT));
        k.displayName = s.getString("display-name", "<gold>" + key);
        k.description = new ArrayList<>(s.getStringList("description"));
        Material m = Material.matchMaterial(s.getString("icon", "BOOK"));
        k.icon = (m == null || !m.isItem() || m.isAir()) ? Material.CHEST : m;
        k.rows = Math.max(1, Math.min(6, s.getInt("inventory.rows", 3)));
        k.order = s.getInt("gui-order", 0);
        k.enabled = s.getBoolean("enabled", true);
        k.hidden = s.getBoolean("hidden", false);
        k.permission = s.getString("permission", "");
        k.worlds = new ArrayList<>(s.getStringList("worlds"));
        k.availableFrom = s.getLong("available-from", 0);
        k.availableUntil = s.getLong("available-until", 0);
        for (String r : s.getStringList("ranks.allowed")) k.ranks.add(r.toLowerCase(Locale.ROOT));
        k.minRank = s.getString("ranks.minimum", "");
        k.inherit = s.getBoolean("ranks.include-inheriting", true);
        ConfigurationSection rc = s.getConfigurationSection("ranks.cooldown-overrides");
        if (rc != null) for (String r : rc.getKeys(false)) k.rankCooldowns.put(r.toLowerCase(Locale.ROOT), Math.max(0, rc.getLong(r)));
        k.cooldown = Math.max(0, s.getLong("cooldown.duration", 86400));
        k.oneTime = "ONCE".equalsIgnoreCase(s.getString("cooldown.type", "TIME"));
        k.dropIfFull = s.getBoolean("settings.drop-overflow", false);
        k.autoEquip = s.getBoolean("settings.auto-equip-armor", false);
        k.announce = s.getBoolean("settings.announce-redemption", false);
        k.commands = new ArrayList<>(s.getStringList("rewards.commands"));
        k.xp = Math.max(0, s.getInt("rewards.xp", 0));
        k.createdBy = s.getString("audit.created-by", "");
        k.createdAt = s.getLong("audit.created-at", 0);
        k.editedBy = s.getString("audit.edited-by", "");
        k.editedAt = s.getLong("audit.edited-at", 0);
        ConfigurationSection is = s.getConfigurationSection("items");
        if (is != null) {
            for (String sk : is.getKeys(false)) {
                try {
                    int slot = Integer.parseInt(sk);
                    ItemStack it = is.getItemStack(sk);
                    if (it != null && slot >= 0) k.items.put(slot, it);
                    else plugin.getLogger().warning(Lang.s("log.item-unloadable", "kit", key, "slot", sk));
                } catch (NumberFormatException ignored) { }
            }
        }
        k.trim();
        return k;
    }

    /** Serialises on the main thread, writes on the IO thread (atomic replace). */
    public synchronized void save() {
        YamlConfiguration y = new YamlConfiguration();
        for (Kit k : kits.values()) {
            String p = "kits." + k.name + ".";
            y.set(p + "enabled", k.enabled);
            y.set(p + "hidden", k.hidden);
            y.set(p + "display-name", k.displayName);
            y.set(p + "description", k.description);
            y.set(p + "icon", k.icon.name());
            y.set(p + "gui-order", k.order);
            y.set(p + "permission", k.permission);
            y.set(p + "worlds", k.worlds);
            y.set(p + "available-from", k.availableFrom);
            y.set(p + "available-until", k.availableUntil);
            y.set(p + "ranks.allowed", new ArrayList<>(k.ranks));
            y.set(p + "ranks.minimum", k.minRank);
            y.set(p + "ranks.include-inheriting", k.inherit);
            for (Map.Entry<String, Long> e : k.rankCooldowns.entrySet()) y.set(p + "ranks.cooldown-overrides." + e.getKey(), e.getValue());
            y.set(p + "cooldown.type", k.oneTime ? "ONCE" : "TIME");
            y.set(p + "cooldown.duration", k.cooldown);
            y.set(p + "inventory.rows", k.rows);
            y.set(p + "settings.drop-overflow", k.dropIfFull);
            y.set(p + "settings.auto-equip-armor", k.autoEquip);
            y.set(p + "settings.announce-redemption", k.announce);
            y.set(p + "rewards.commands", k.commands);
            y.set(p + "rewards.xp", k.xp);
            y.set(p + "audit.created-by", k.createdBy);
            y.set(p + "audit.created-at", k.createdAt);
            y.set(p + "audit.edited-by", k.editedBy);
            y.set(p + "audit.edited-at", k.editedAt);
            for (Map.Entry<Integer, ItemStack> e : k.items.entrySet()) y.set(p + "items." + e.getKey(), e.getValue());
        }
        writeAtomic(kitsFile, y.saveToString());
    }

    private synchronized void saveData() {
        YamlConfiguration d = new YamlConfiguration();
        for (Map.Entry<UUID, Map<String, Claim>> e : claims.entrySet()) {
            for (Map.Entry<String, Claim> k : e.getValue().entrySet()) {
                String p = "players." + e.getKey() + "." + k.getKey() + ".";
                d.set(p + "last", k.getValue().last);
                d.set(p + "count", k.getValue().count);
            }
        }
        writeAtomic(dataFile, d.saveToString());
    }

    private void writeAtomic(File target, String content) {
        io.execute(() -> {
            try {
                File tmp = new File(target.getParentFile(), target.getName() + ".tmp");
                Files.writeString(tmp.toPath(), content, StandardCharsets.UTF_8);
                Files.move(tmp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING);
            } catch (IOException ex) {
                plugin.getLogger().severe(Lang.s("log.write-failed", "file", target.getName(), "error", String.valueOf(ex.getMessage())));
            }
        });
    }

    /** Appends one line to kit-log.txt (redemptions and admin actions). */
    public void log(String line) {
        if (!plugin.getConfig().getBoolean("kits.log", true)) return;
        String out = LocalDateTime.now().withNano(0) + " " + line + System.lineSeparator();
        io.execute(() -> {
            try {
                Files.writeString(logFile.toPath(), out, StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.APPEND);
            } catch (IOException ignored) { }
        });
    }

    public void shutdown() {
        save();
        saveData();
        io.shutdown();
        try {
            io.awaitTermination(5, TimeUnit.SECONDS);
        } catch (InterruptedException ignored) {
            Thread.currentThread().interrupt();
        }
    }

    // ---------------------------------------------------------------- kits

    public Kit get(String name) { return name == null ? null : kits.get(name.toLowerCase(Locale.ROOT)); }

    public List<Kit> all() {
        List<Kit> l = new ArrayList<>(kits.values());
        l.sort(Comparator.comparingInt((Kit k) -> k.order).thenComparing(k -> k.name));
        return l;
    }

    public Kit create(String name, String by) {
        Kit k = new Kit(name.toLowerCase(Locale.ROOT));
        Material def = Material.matchMaterial(plugin.getConfig().getString("kits.default-icon", "BOOK"));
        if (def != null && def.isItem() && !def.isAir()) k.icon = def;
        k.createdBy = by;
        k.createdAt = System.currentTimeMillis();
        kits.put(k.name, k);
        save();
        log("CREATE kit=" + k.name + " by=" + by);
        return k;
    }

    public Kit clone(Kit src, String newName, String by) {
        Kit k = create(newName, by);
        k.displayName = src.displayName;
        k.description = new ArrayList<>(src.description);
        k.icon = src.icon;
        k.rows = src.rows;
        k.order = src.order;
        for (Map.Entry<Integer, ItemStack> e : src.items.entrySet()) k.items.put(e.getKey(), e.getValue().clone());
        k.ranks.addAll(src.ranks);
        k.minRank = src.minRank;
        k.rankCooldowns.putAll(src.rankCooldowns);
        k.cooldown = src.cooldown;
        k.oneTime = src.oneTime;
        k.enabled = src.enabled;
        k.hidden = src.hidden;
        k.inherit = src.inherit;
        k.dropIfFull = src.dropIfFull;
        k.autoEquip = src.autoEquip;
        k.announce = src.announce;
        k.permission = src.permission;
        k.commands = new ArrayList<>(src.commands);
        k.worlds = new ArrayList<>(src.worlds);
        k.availableFrom = src.availableFrom;
        k.availableUntil = src.availableUntil;
        k.xp = src.xp;
        save();
        return k;
    }

    public boolean delete(String name, String by) {
        Kit k = kits.remove(name.toLowerCase(Locale.ROOT));
        if (k == null) return false;
        for (Map<String, Claim> m : claims.values()) m.remove(k.name);
        save();
        saveData();
        log("DELETE kit=" + k.name + " by=" + by);
        return true;
    }

    /** Call after any admin edit: stamps the audit fields and saves. */
    public void touch(Kit k, String by) {
        k.editedBy = by;
        k.editedAt = System.currentTimeMillis();
        save();
        log("EDIT kit=" + k.name + " by=" + by);
    }

    /** Replaces the kit items with a COPY of the player's inventory (the player keeps their items). */
    public int importInventory(Player p, Kit k) {
        List<ItemStack> list = new ArrayList<>();
        for (ItemStack it : p.getInventory().getStorageContents()) {
            if (it != null && !it.getType().isAir()) list.add(it.clone());
        }
        k.rows = Math.max(k.rows, Math.min(6, (list.size() + 8) / 9));
        k.items.clear();
        int slot = 0;
        for (ItemStack it : list) {
            if (slot >= k.size()) break;
            k.items.put(slot++, it);
        }
        return k.items.size();
    }

    /** Number of kits this player could redeem right now (used for join reminders / placeholders). */
    public int readyCount(Player p) {
        int n = 0;
        for (Kit k : kits.values()) {
            if (!k.items.isEmpty() && check(p, k).status() == Status.OK) n++;
        }
        return n;
    }

    // ---------------------------------------------------------------- ranks / cooldowns

    private Rank rankOf(Player p) {
        Rank r = plugin.ranks().rankOf(p.getUniqueId());
        return r != null ? r : plugin.ranks().get("default");
    }

    /** Player's rank first, then its parents (when the kit allows inheritance). */
    private List<String> chain(Player p, Kit k) {
        List<String> out = new ArrayList<>();
        Rank r = rankOf(p);
        int guard = 0;
        while (r != null && guard++ < 32) {
            out.add(r.name.toLowerCase(Locale.ROOT));
            if (!k.inherit || r.parent == null || r.parent.isBlank()) break;
            r = plugin.ranks().get(r.parent);
        }
        return out;
    }

    /** Allowed = rank is selected (or inherits from a selected one) OR rank weight >= minimum rank weight. */
    public boolean rankAllowed(Player p, Kit k) {
        Rank min = k.minRank == null || k.minRank.isBlank() ? null : plugin.ranks().get(k.minRank);
        if (k.ranks.isEmpty() && min == null) return true;
        for (String r : chain(p, k)) if (k.ranks.contains(r)) return true;
        Rank mine = rankOf(p);
        return min != null && mine != null && mine.weight >= min.weight;
    }

    public long cooldownFor(Player p, Kit k) {
        for (String r : chain(p, k)) {
            Long v = k.rankCooldowns.get(r);
            if (v != null) return v;
        }
        return k.cooldown;
    }

    public Claim claim(UUID u, String kit) {
        Map<String, Claim> m = claims.get(u);
        return m == null ? null : m.get(kit);
    }

    public void resetClaims(UUID u, String kit) {
        if (kit == null) claims.remove(u);
        else {
            Map<String, Claim> m = claims.get(u);
            if (m != null) m.remove(kit);
        }
        saveData();
    }

    public Check check(Player p, Kit k) {
        if (p.hasPermission("rankforge.kit.bypass")) return new Check(Status.OK, 0);
        if (!k.enabled) return new Check(Status.DISABLED, 0);
        long now = System.currentTimeMillis();
        if (k.availableFrom > 0 && now < k.availableFrom) return new Check(Status.NOT_YET, 0);
        if (k.availableUntil > 0 && now > k.availableUntil) return new Check(Status.EXPIRED, 0);
        if (!k.permission.isBlank() && !p.hasPermission(k.permission)) return new Check(Status.NO_PERMISSION, 0);
        if (!k.worlds.isEmpty() && k.worlds.stream().noneMatch(w -> w.equalsIgnoreCase(p.getWorld().getName())))
            return new Check(Status.WRONG_WORLD, 0);
        if (!rankAllowed(p, k)) return new Check(Status.WRONG_RANK, 0);
        Claim c = claim(p.getUniqueId(), k.name);
        if (c != null && c.last > 0) {
            if (k.oneTime) return new Check(Status.ONE_TIME_DONE, 0);
            long cd = cooldownFor(p, k);
            long left = c.last + cd * 1000L - now;
            if (cd > 0 && left > 0) return new Check(Status.COOLDOWN, (left + 999) / 1000);
        }
        return new Check(Status.OK, 0);
    }

    /** One line of status text (used both in chat and GUI lore). */
    public String statusText(Check c, Kit k) {
        return switch (c.status()) {
            case OK -> text("ready");
            case COOLDOWN -> text("cooldown", "cooldown", KitUtil.formatDuration(c.remaining()));
            case WRONG_RANK -> text("wrong-rank", "ranks", ranksText(k));
            case WRONG_WORLD -> text("wrong-world");
            case ONE_TIME_DONE -> text("one-time");
            case DISABLED -> text("disabled");
            case NO_PERMISSION -> text("no-permission");
            case NOT_YET -> text("not-yet", "date", KitUtil.formatDate(k.availableFrom));
            case EXPIRED -> text("expired");
        };
    }

    public String ranksText(Kit k) {
        List<String> parts = new ArrayList<>(k.ranks);
        if (k.minRank != null && !k.minRank.isBlank()) parts.add(">= " + k.minRank);
        return parts.isEmpty() ? Lang.s("word.everyone") : String.join(", ", parts);
    }

    /** Placeholder pairs for the menu / preview lore templates (see lang file: menu.item-lore). */
    public String[] placeholders(Player p, Kit k) {
        Check c = check(p, k);
        Claim cl = claim(p.getUniqueId(), k.name);
        return new String[]{
                "name", k.displayName,
                "ranks", ranksText(k),
                "cooldown", k.oneTime ? Lang.s("word.once") : KitUtil.formatDuration(cooldownFor(p, k)),
                "items", String.valueOf(k.items.size()),
                "xp", k.xp > 0 ? Lang.s("xp-line", "xp", String.valueOf(k.xp)) : "",
                "uses", String.valueOf(cl == null ? 0 : cl.count),
                "status", statusText(c, k)
        };
    }

    // ---------------------------------------------------------------- redeem

    private boolean hasSpace(Player p, List<ItemStack> give) {
        if (give.isEmpty()) return true;
        ItemStack[] cur = p.getInventory().getStorageContents();
        Inventory tmp = Bukkit.createInventory(null, 36);
        for (int i = 0; i < 36 && i < cur.length; i++) tmp.setItem(i, cur[i] == null ? null : cur[i].clone());
        List<ItemStack> copy = new ArrayList<>();
        for (ItemStack it : give) copy.add(it.clone());
        return tmp.addItem(copy.toArray(new ItemStack[0])).isEmpty();
    }

    /**
     * Redeems a kit. All checks run here, server-side, every time (the GUI is never trusted).
     * force = admin give that ignores every restriction and doesn't start a cooldown.
     */
    public boolean redeem(Player p, Kit k, boolean force) {
        if (!p.isOnline() || get(k.name) != k) return false;
        if (!force) {
            Check c = check(p, k);
            if (c.status() != Status.OK) {
                KitUtil.send(p, statusText(c, k));
                sound(p, "deny", "entity.villager.no,0.8,1.0");
                return false;
            }
        }

        // plan: armor that can be auto-equipped, everything else goes to the inventory
        List<ItemStack> rest = new ArrayList<>();
        ItemStack helmet = null, chest = null, legs = null, boots = null;
        PlayerInventory pi = p.getInventory();
        for (ItemStack src : k.items.values()) {
            ItemStack it = src.clone();
            String n = it.getType().name();
            if (k.autoEquip && it.getAmount() == 1) {
                if (n.endsWith("_HELMET") && helmet == null && pi.getHelmet() == null) { helmet = it; continue; }
                if (n.endsWith("_CHESTPLATE") && chest == null && pi.getChestplate() == null) { chest = it; continue; }
                if (n.endsWith("_LEGGINGS") && legs == null && pi.getLeggings() == null) { legs = it; continue; }
                if (n.endsWith("_BOOTS") && boots == null && pi.getBoots() == null) { boots = it; continue; }
            }
            rest.add(it);
        }
        if (!k.dropIfFull && !hasSpace(p, rest)) {
            KitUtil.send(p, text("inventory-full"));
            sound(p, "deny", "entity.villager.no,0.8,1.0");
            return false;
        }

        // start the cooldown BEFORE handing anything out, so nothing can be redeemed twice
        if (!force) {
            Claim c = claims.computeIfAbsent(p.getUniqueId(), x -> new HashMap<>()).computeIfAbsent(k.name, x -> new Claim());
            c.last = System.currentTimeMillis();
            c.count++;
            saveData();
        }

        if (helmet != null) pi.setHelmet(helmet);
        if (chest != null) pi.setChestplate(chest);
        if (legs != null) pi.setLeggings(legs);
        if (boots != null) pi.setBoots(boots);
        Map<Integer, ItemStack> left = pi.addItem(rest.toArray(new ItemStack[0]));
        for (ItemStack it : left.values()) p.getWorld().dropItemNaturally(p.getLocation(), it);
        if (k.xp > 0) p.giveExp(k.xp);

        for (String raw : k.commands) {
            String cmd = raw.replace("{player}", p.getName()).trim();
            if (cmd.startsWith("/")) cmd = cmd.substring(1);
            if (cmd.isEmpty()) continue;
            try {
                if (cmd.regionMatches(true, 0, "player:", 0, 7)) p.performCommand(cmd.substring(7).trim());
                else Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
            } catch (Exception ex) {
                plugin.getLogger().warning("Kit " + k.name + ": command failed '" + cmd + "': " + ex.getMessage());
            }
        }

        sound(p, "redeem", "entity.player.levelup,0.8,1.2");
        if (plugin.getConfig().getBoolean("kits.effects.title-on-redeem", true)) {
            p.showTitle(net.kyori.adventure.title.Title.title(
                    KitUtil.mm(Lang.s("title.redeemed.title")),
                    KitUtil.mm(Lang.s("title.redeemed.subtitle", "kit", k.displayName))));
        }
        Component name = KitUtil.mm(k.displayName);
        KitUtil.send(p, KitUtil.mm(text("redeemed", "kit", "@@KIT@@")).replaceText(b -> b.matchLiteral("@@KIT@@").replacement(name)));
        if (k.announce) {
            Bukkit.broadcast(KitUtil.mm(text("announce", "player", p.getName(), "kit", "@@KIT@@"))
                    .replaceText(b -> b.matchLiteral("@@KIT@@").replacement(name)));
        }
        log((force ? "GIVE" : "REDEEM") + " kit=" + k.name + " player=" + p.getName());
        return true;
    }
}
