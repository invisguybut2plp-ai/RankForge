package pl.rankforge.kit;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import pl.rankforge.RankForge;
import pl.rankforge.kit.gui.ConfirmGui;
import pl.rankforge.kit.gui.KitEditorGui;
import pl.rankforge.kit.gui.KitListGui;
import pl.rankforge.kit.gui.KitPreviewGui;

import java.util.*;

public class KitCommand implements CommandExecutor, TabCompleter {
    private static final List<String> ADMIN_SUBS = List.of("create", "edit", "delete", "reload", "list", "give", "reset", "seticon", "clone");
    private static final Set<String> PLAYER_SUBS = Set.of("help", "claim");
    private static final Set<String> RESERVED = new HashSet<>(List.of("help", "claim", "create", "edit", "delete", "reload", "list", "give", "reset", "seticon", "clone"));

    private final RankForge plugin;
    private final KitManager kits;

    public KitCommand(RankForge plugin, KitManager kits) {
        this.plugin = plugin;
        this.kits = kits;
    }

    private static boolean isAdmin(CommandSender s) {
        return s.hasPermission("rankforge.kit.admin") || s.hasPermission("rankforge.admin");
    }

    private static String m(String key, String... kv) {
        return Lang.s("msg." + key, kv);
    }

    private void deny(CommandSender s) {
        KitUtil.send(s, m("admin-only"));
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        boolean admin = isAdmin(sender);
        if (args.length == 0) {
            if (!(sender instanceof Player p)) { KitUtil.send(sender, m("players-only")); return true; }
            if (!p.hasPermission("rankforge.kit")) { deny(sender); return true; }
            new KitListGui(plugin, kits, p, 0).open();
            return true;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        if (RESERVED.contains(sub) && !PLAYER_SUBS.contains(sub) && !admin) { deny(sender); return true; }

        switch (sub) {
            case "help" -> help(sender, admin);
            case "claim" -> {
                if (!(sender instanceof Player p)) { KitUtil.send(sender, m("players-only")); return true; }
                if (!p.hasPermission("rankforge.kit")) { deny(sender); return true; }
                Kit k = need(sender, args, 1);
                if (k == null) return true;
                if (!k.enabled && !admin) { KitUtil.send(sender, m("unknown-kit")); return true; }
                kits.redeem(p, k, false);
            }
            case "create" -> {
                if (!(sender instanceof Player p)) { KitUtil.send(sender, m("players-only")); return true; }
                if (args.length >= 2) createKit(p, args[1]);
                else plugin.awaitInput(p, Lang.s("prompt.kit-id") + m("cancel-hint"), txt -> createKit(p, txt), () -> { });
            }
            case "edit" -> {
                if (!(sender instanceof Player p)) { KitUtil.send(sender, m("players-only")); return true; }
                Kit k = need(sender, args, 1);
                if (k != null) new KitEditorGui(plugin, kits, p, k).open();
            }
            case "delete" -> {
                Kit k = need(sender, args, 1);
                if (k == null) return true;
                if (sender instanceof Player p) {
                    new ConfirmGui(plugin, p, Lang.s("ed.confirm.delete-title", "kit", k.name), Lang.l("ed.confirm.delete-info"),
                            () -> { kits.delete(k.name, p.getName()); p.closeInventory(); KitUtil.send(p, m("deleted", "kit", k.name)); },
                            p::closeInventory).open();
                } else {
                    kits.delete(k.name, sender.getName());
                    KitUtil.send(sender, m("deleted", "kit", k.name));
                }
            }
            case "reload" -> {
                plugin.reloadLanguage();
                kits.load();
                KitUtil.send(sender, m("reloaded"));
            }
            case "list" -> {
                KitUtil.send(sender, m("list-header", "count", String.valueOf(kits.all().size())));
                for (Kit k : kits.all()) {
                    KitUtil.send(sender, m("list-line", "name", k.name, "state", Lang.s(k.enabled ? "word.on" : "word.off"),
                            "items", String.valueOf(k.items.size()), "ranks", kits.ranksText(k)));
                }
            }
            case "give" -> {
                if (args.length < 3) { KitUtil.send(sender, m("usage-give")); return true; }
                Player t = Bukkit.getPlayerExact(args[1]);
                Kit k = need(sender, args, 2);
                if (k == null) return true;
                if (t == null) { KitUtil.send(sender, m("not-online")); return true; }
                boolean force = !plugin.getConfig().getBoolean("kits.give-respects-restrictions", false);
                if (kits.redeem(t, k, force)) KitUtil.send(sender, m("give-ok", "kit", k.name, "player", t.getName()));
                else KitUtil.send(sender, m("give-fail", "player", t.getName()));
            }
            case "reset" -> {
                if (args.length < 2) { KitUtil.send(sender, m("usage-reset")); return true; }
                OfflinePlayer op = Bukkit.getPlayerExact(args[1]);
                if (op == null) op = Bukkit.getOfflinePlayerIfCached(args[1]);
                if (op == null) { KitUtil.send(sender, m("unknown-player")); return true; }
                String kn = null;
                if (args.length >= 3) {
                    Kit k = need(sender, args, 2);
                    if (k == null) return true;
                    kn = k.name;
                }
                kits.resetClaims(op.getUniqueId(), kn);
                kits.log("RESET player=" + args[1] + " kit=" + (kn == null ? "*" : kn) + " by=" + sender.getName());
                KitUtil.send(sender, kn == null ? m("reset-all", "player", args[1]) : m("reset-one", "player", args[1], "kit", kn));
            }
            case "seticon" -> {
                if (!(sender instanceof Player p)) { KitUtil.send(sender, m("players-only")); return true; }
                Kit k = need(sender, args, 1);
                if (k == null) return true;
                ItemStack hand = p.getInventory().getItemInMainHand();
                if (hand.getType().isAir()) { KitUtil.send(p, m("hold-item")); return true; }
                k.icon = hand.getType();
                kits.touch(k, p.getName());
                KitUtil.send(p, m("icon-set", "kit", k.name, "material", k.icon.name()));
            }
            case "clone" -> {
                if (args.length < 3) { KitUtil.send(sender, m("usage-clone")); return true; }
                Kit src = need(sender, args, 1);
                if (src == null) return true;
                String nn = args[2].toLowerCase(Locale.ROOT);
                if (!validName(nn) || kits.get(nn) != null) { KitUtil.send(sender, m("bad-name")); return true; }
                kits.clone(src, nn, sender.getName());
                KitUtil.send(sender, m("created", "kit", nn));
            }
            default -> {
                // /kit <kitname> -> preview
                if (!(sender instanceof Player p)) { KitUtil.send(sender, m("players-only")); return true; }
                if (!p.hasPermission("rankforge.kit")) { deny(sender); return true; }
                Kit k = kits.get(args[0]);
                if (k == null || (!k.enabled && !admin)) { KitUtil.send(sender, m("unknown-kit")); return true; }
                new KitPreviewGui(plugin, kits, p, k, p::closeInventory).open();
            }
        }
        return true;
    }

    private Kit need(CommandSender s, String[] args, int idx) {
        if (args.length <= idx) { KitUtil.send(s, m("specify-kit")); return null; }
        Kit k = kits.get(args[idx]);
        if (k == null) KitUtil.send(s, m("unknown-kit"));
        return k;
    }

    private static boolean validName(String n) {
        return n.matches("[a-z0-9_-]{1,24}") && !RESERVED.contains(n);
    }

    private void createKit(Player p, String raw) {
        String name = raw.trim().toLowerCase(Locale.ROOT);
        if (!validName(name)) { KitUtil.send(p, m("bad-name")); return; }
        if (kits.get(name) != null) { KitUtil.send(p, m("exists")); return; }
        Kit k = kits.create(name, p.getName());
        KitUtil.send(p, m("created", "kit", k.name));
        KitUtil.send(p, m("tip-create"));
        new KitEditorGui(plugin, kits, p, k).open();
    }

    private void help(CommandSender s, boolean admin) {
        KitUtil.send(s, Lang.s("help.title"));
        for (String line : Lang.l("help.player")) KitUtil.send(s, line);
        if (!admin) return;
        for (String line : Lang.l("help.admin")) KitUtil.send(s, line);
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String alias, String[] args) {
        boolean admin = isAdmin(s);
        List<String> out = new ArrayList<>();
        String cur = args[args.length - 1].toLowerCase(Locale.ROOT);
        if (args.length == 1) {
            out.add("help");
            out.add("claim");
            if (admin) out.addAll(ADMIN_SUBS);
            for (Kit k : kits.all()) if (k.enabled || admin) out.add(k.name);
        } else if (args.length == 2 && args[0].equalsIgnoreCase("claim")) {
            for (Kit k : kits.all()) if (k.enabled || admin) out.add(k.name);
        } else if (admin) {
            String sub = args[0].toLowerCase(Locale.ROOT);
            switch (sub) {
                case "edit", "delete", "seticon", "clone" -> { if (args.length == 2) for (Kit k : kits.all()) out.add(k.name); }
                case "give", "reset" -> {
                    if (args.length == 2) for (Player p : Bukkit.getOnlinePlayers()) out.add(p.getName());
                    else if (args.length == 3) for (Kit k : kits.all()) out.add(k.name);
                }
                default -> { }
            }
        }
        out.removeIf(x -> !x.toLowerCase(Locale.ROOT).startsWith(cur));
        return out;
    }
}
