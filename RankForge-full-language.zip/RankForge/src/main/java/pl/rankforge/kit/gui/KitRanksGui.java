package pl.rankforge.kit.gui;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import pl.rankforge.Rank;
import pl.rankforge.RankForge;
import pl.rankforge.gui.Gui;
import pl.rankforge.gui.Items;
import pl.rankforge.kit.Kit;
import pl.rankforge.kit.KitManager;
import pl.rankforge.kit.KitUtil;
import pl.rankforge.kit.Lang;

import java.util.ArrayList;
import java.util.List;

/** Pick which RankForge ranks can redeem a kit, per-rank cooldowns and the minimum rank. */
public class KitRanksGui extends Gui {
    private final RankForge plugin;
    private final KitManager kits;
    private final Player p;
    private final Kit kit;
    private int page;
    private List<Rank> list = new ArrayList<>();

    public KitRanksGui(RankForge plugin, KitManager kits, Player p, Kit kit, int page) {
        this.plugin = plugin;
        this.kits = kits;
        this.p = p;
        this.kit = kit;
        this.page = page;
    }

    public void open() {
        inv = Bukkit.createInventory(this, 54, KitUtil.mm(Lang.s("ranks.title", "kit", kit.name)));
        draw();
        p.openInventory(inv);
    }

    private void draw() {
        list = plugin.ranks().sorted();
        int pages = Math.max(1, (list.size() + 44) / 45);
        page = Math.max(0, Math.min(page, pages - 1));
        Ui.fill(inv, Material.GRAY_STAINED_GLASS_PANE);
        for (int i = 0; i < 45; i++) {
            int idx = page * 45 + i;
            inv.setItem(i, null);
            if (idx >= list.size()) continue;
            Rank r = list.get(idx);
            boolean on = kit.ranks.contains(r.name);
            boolean min = r.name.equalsIgnoreCase(kit.minRank);
            Long cd = kit.rankCooldowns.get(r.name);
            List<Component> lore = new ArrayList<>();
            if (r.hasPrefix()) lore.add(KitUtil.c(Lang.s("ranks.prefix")).append(r.prefix()));
            for (String line : Lang.l("ranks.lore",
                    "weight", String.valueOf(r.weight),
                    "can", Lang.s(on ? "ranks.yes" : "ranks.no"),
                    "min", min ? Lang.s("ranks.min-line") : "",
                    "cooldown", cd == null ? KitUtil.formatDuration(kit.cooldown) + " " + Lang.s("ranks.default") : KitUtil.formatDuration(cd),
                    "prefix", "")) {
                lore.add(KitUtil.c(line));
            }
            ItemStack it = Items.make(on ? Material.LIME_CONCRETE : (min ? Material.YELLOW_CONCRETE : Material.GRAY_CONCRETE),
                    KitUtil.c("<white>" + r.name), lore);
            inv.setItem(i, (on || min) ? Items.glow(it) : it);
        }
        if (page > 0) inv.setItem(45, Ui.btn(Material.ARROW, Lang.s("btn.prev")));
        inv.setItem(46, Ui.btn(Material.ARROW, Lang.s("ranks.back")));
        inv.setItem(48, Ui.btn(Material.BARRIER, Lang.s("ranks.clear-min"),
                Lang.l("ranks.clear-min-lore", "current", kit.minRank.isBlank() ? Lang.s("word.none") : kit.minRank)));
        inv.setItem(49, Ui.btn(Material.HOPPER, Lang.s("ranks.all"), Lang.l("ranks.all-lore")));
        if (page < pages - 1) inv.setItem(53, Ui.btn(Material.ARROW, Lang.s("btn.next")));
    }

    private void reopen() {
        Ui.later(plugin, () -> new KitRanksGui(plugin, kits, p, kit, page).open());
    }

    @Override
    public void click(InventoryClickEvent e) {
        int s = e.getSlot();
        kits.sound(p, "click", "ui.button.click,0.8,1.0");
        if (s < 45) {
            int idx = page * 45 + s;
            if (idx >= list.size()) return;
            Rank r = list.get(idx);
            ClickType t = e.getClick();
            if (t == ClickType.SHIFT_LEFT) {
                kit.minRank = r.name.equalsIgnoreCase(kit.minRank) ? "" : r.name;
            } else if (t == ClickType.LEFT) {
                if (!kit.ranks.remove(r.name)) kit.ranks.add(r.name);
            } else if (t == ClickType.SHIFT_RIGHT) {
                kit.rankCooldowns.remove(r.name);
            } else if (t == ClickType.RIGHT) {
                plugin.awaitInput(p, Lang.s("prompt.rank-cooldown", "rank", r.name) + Lang.s("msg.cancel-hint"),
                        txt -> {
                            long v = KitUtil.parseDuration(txt);
                            if (v < 0) KitUtil.send(p, Lang.s("msg.invalid-time"));
                            else {
                                kit.rankCooldowns.put(r.name, v);
                                kits.touch(kit, p.getName());
                            }
                            reopen();
                        }, this::reopen);
                return;
            } else return;
            kits.touch(kit, p.getName());
            draw();
            return;
        }
        switch (s) {
            case 45 -> { if (page > 0) { page--; draw(); } }
            case 53 -> { page++; draw(); }
            case 46 -> Ui.later(plugin, () -> new KitEditorGui(plugin, kits, p, kit, 0).open());
            case 48 -> { kit.minRank = ""; kits.touch(kit, p.getName()); draw(); }
            case 49 -> { kit.ranks.clear(); kit.minRank = ""; kits.touch(kit, p.getName()); draw(); }
            default -> { }
        }
    }
}
