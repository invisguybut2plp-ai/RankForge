package pl.rankforge.kit.gui;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import pl.rankforge.RankForge;
import pl.rankforge.gui.Gui;
import pl.rankforge.kit.Kit;
import pl.rankforge.kit.KitManager;
import pl.rankforge.kit.KitUtil;
import pl.rankforge.kit.Lang;

import java.util.List;
import java.util.Map;

/** Read-only view of a kit's contents with Redeem / Cancel buttons. */
public class KitPreviewGui extends Gui {
    private final RankForge plugin;
    private final KitManager kits;
    private final Player p;
    private final Kit kit;
    private final Runnable back;
    private int page = 0;
    private int perPage;
    private int pages;
    private int base;

    public KitPreviewGui(RankForge plugin, KitManager kits, Player p, Kit kit, Runnable back) {
        this.plugin = plugin;
        this.kits = kits;
        this.p = p;
        this.kit = kit;
        this.back = back;
    }

    public void open() {
        perPage = Math.min(kit.size(), 45);
        pages = Math.max(1, (kit.size() + perPage - 1) / perPage);
        base = perPage;
        inv = Bukkit.createInventory(this, base + 9, KitUtil.mm(Lang.s("preview.title", "kit", kit.displayName)));
        draw();
        p.openInventory(inv);
        kits.sound(p, "open", "block.chest.open,0.6,1.2");
    }

    private void draw() {
        inv.clear();
        for (int i = base; i < base + 9; i++) inv.setItem(i, KitUtil.filler(Material.GRAY_STAINED_GLASS_PANE));
        for (Map.Entry<Integer, ItemStack> e : kit.items.entrySet()) {
            int slot = e.getKey() - page * perPage;
            if (slot >= 0 && slot < perPage) inv.setItem(slot, e.getValue().clone());
        }
        if (pages > 1) {
            if (page > 0) inv.setItem(base, Ui.btn(Material.ARROW, Lang.s("btn.prev"), Lang.s("btn.page", "page", String.valueOf(page), "pages", String.valueOf(pages))));
            if (page < pages - 1) inv.setItem(base + 8, Ui.btn(Material.ARROW, Lang.s("btn.next"), Lang.s("btn.page", "page", String.valueOf(page + 2), "pages", String.valueOf(pages))));
        }
        KitManager.Check c = kits.check(p, kit);
        boolean ok = c.status() == KitManager.Status.OK;
        String[] kv = kits.placeholders(p, kit);
        inv.setItem(base + 2, Ui.btn(Material.RED_CONCRETE, Lang.s("preview.cancel"), Lang.l("preview.cancel-lore")));
        inv.setItem(base + 4, Ui.btn(Material.BOOK, Lang.s("preview.info-name", kv),
                Lang.l("preview.info-lore", Map.of("description", kit.description), kv)));
        inv.setItem(base + 6, ok
                ? Ui.btn(Material.LIME_CONCRETE, Lang.s("preview.redeem"), Lang.l("preview.redeem-lore"))
                : Ui.btn(Material.BARRIER, Lang.s("preview.cant"), List.of(kits.statusText(c, kit))));
    }

    @Override
    public void click(InventoryClickEvent e) {
        int off = e.getSlot() - base;
        if (off < 0 || off > 8) return;
        switch (off) {
            case 0 -> { if (page > 0) { page--; kits.sound(p, "page", "item.book.page_turn,0.8,1.0"); draw(); } }
            case 8 -> { if (page < pages - 1) { page++; kits.sound(p, "page", "item.book.page_turn,0.8,1.0"); draw(); } }
            case 2 -> {
                kits.sound(p, "click", "ui.button.click,0.8,1.0");
                if (back != null) Ui.later(plugin, back);
                else p.closeInventory();
            }
            case 6 -> {
                // everything is re-checked server-side inside redeem()
                if (kits.redeem(p, kit, false)) p.closeInventory();
                else draw();
            }
            default -> { }
        }
    }
}
