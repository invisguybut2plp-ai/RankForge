package pl.rankforge;

import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import pl.rankforge.kit.Lang;

import java.io.File;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.file.Files;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** Buduje i rozsyła resource pack z ikonami rang (czcionka bitmapowa). */
public class ResourcePackService {
    public static final UUID PACK_ID = UUID.nameUUIDFromBytes("rankforge-icons".getBytes());
    public static final Key FONT = Key.key("rankforge", "icons");

    private final RankForge plugin;
    private PackServer server;
    private volatile byte[] sha1;
    private volatile String sha1Hex = "";
    private final Set<String> packed = ConcurrentHashMap.newKeySet();
    private final Set<UUID> loaded = ConcurrentHashMap.newKeySet();
    private boolean warnedNoUrl = false;

    public ResourcePackService(RankForge plugin) {
        this.plugin = plugin;
    }

    private FileConfiguration cfg() {
        return plugin.getConfig();
    }

    private String mode() {
        return cfg().getString("resource-pack.mode", "builtin").toLowerCase(Locale.ROOT);
    }

    public void start() {
        if (mode().equals("builtin")) {
            int port = cfg().getInt("resource-pack.port", 25580);
            try {
                server = new PackServer(port);
                server.start();
                plugin.getLogger().info(Lang.s("log.pack-started", "port", String.valueOf(port)));
            } catch (IOException e) {
                server = null;
                plugin.getLogger().warning(Lang.s("log.pack-start-failed", "port", String.valueOf(port), "error", String.valueOf(e.getMessage())));
            }
        }
        rebuild(false);
    }

    public void stop() {
        if (server != null) server.stop();
        server = null;
    }

    /** Przebudowuje paczkę z folderu Icons. Zwraca true, jeśli zawartość się zmieniła. */
    public synchronized boolean rebuild(boolean resend) {
        RankManager rm = plugin.ranks();
        boolean enabled = cfg().getBoolean("icons.enabled", true) && !mode().equals("off");
        String old = sha1Hex;
        packed.clear();
        sha1 = null;
        sha1Hex = "";

        if (enabled) {
            List<String> ignore = cfg().getStringList("icons.ignore");
            Map<String, File> icons = new LinkedHashMap<>();
            for (Rank r : rm.sorted()) {
                if (ignore.contains(r.name)) continue;
                File f = rm.iconFile(r);
                if (f.isFile()) icons.put(r.name, f);
            }
            rm.assignGlyphs(icons.keySet());
            Map<String, Integer> glyphs = new HashMap<>();
            for (String n : icons.keySet()) glyphs.put(n, rm.get(n).glyph);
            try {
                PackBuilder.Result res = PackBuilder.build(icons, glyphs,
                        Math.max(4, cfg().getInt("icons.height", 8)), cfg().getInt("resource-pack.pack-format", 75),
                        Lang.s("rank.pack.description"));
                if (res.zip() != null) {
                    Files.write(new File(plugin.getDataFolder(), "resourcepack.zip").toPath(), res.zip());
                    sha1 = res.sha1();
                    sha1Hex = PackBuilder.hex(res.sha1());
                    packed.addAll(res.included());
                    if (server != null) server.setData(res.zip());
                }
            } catch (IOException e) {
                plugin.getLogger().warning(Lang.s("log.pack-build-failed", "error", String.valueOf(e.getMessage())));
            }
        }

        boolean changed = !old.equals(sha1Hex);
        if (changed) loaded.clear();
        if (changed && resend && sha1 != null) {
            for (Player p : Bukkit.getOnlinePlayers()) send(p);
        }
        return changed;
    }

    public boolean available() {
        return sha1 != null;
    }

    public boolean has(Rank r) {
        return available() && r != null && r.glyph != 0 && packed.contains(r.name);
    }

    public boolean viewerHasPack(UUID id) {
        return loaded.contains(id);
    }

    public void markLoaded(UUID id) {
        loaded.add(id);
    }

    public void markUnloaded(UUID id) {
        loaded.remove(id);
    }

    public int count() {
        return packed.size();
    }

    public String sha1Hex() {
        return sha1Hex;
    }

    public String modeName() {
        return mode();
    }

    public String urlFor(Player p) {
        if (mode().equals("url")) {
            String u = cfg().getString("resource-pack.url", "");
            return u == null || u.isBlank() ? null : u;
        }
        String host = cfg().getString("resource-pack.host", "");
        if (host == null || host.isBlank()) {
            InetSocketAddress vh = p == null ? null : p.getVirtualHost();
            if (vh != null) host = vh.getHostString();
        }
        if (host == null || host.isBlank()) host = Bukkit.getIp();
        if (host == null || host.isBlank()) return null;
        return "http://" + host + ":" + cfg().getInt("resource-pack.port", 25580)
                + "/rankforge.zip?h=" + sha1Hex.substring(0, 8);
    }

    public void send(Player p) {
        if (!available()) return;
        String url = urlFor(p);
        if (url == null) {
            if (!warnedNoUrl) {
                warnedNoUrl = true;
                plugin.getLogger().warning(Lang.s("log.pack-no-host"));
            }
            return;
        }
        // empty prompt (or the old built-in Polish default) = text from the language file
        String prompt = cfg().getString("resource-pack.prompt", "");
        if (prompt == null || prompt.isBlank() || prompt.equals("Ikony rang")) prompt = Lang.s("rank.pack.prompt");
        p.setResourcePack(PACK_ID, url, sha1,
                Component.text(prompt),
                cfg().getBoolean("resource-pack.force", false));
    }

    /** Znak-ikona rangi (musi być biały, inaczej czcionka tintuje obrazek). */
    public Component icon(Rank r) {
        return Component.text(new String(Character.toChars(r.glyph)), NamedTextColor.WHITE)
                .font(FONT)
                .decoration(TextDecoration.BOLD, false)
                .decoration(TextDecoration.ITALIC, false);
    }
}
