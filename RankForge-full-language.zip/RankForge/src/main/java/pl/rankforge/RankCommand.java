package pl.rankforge;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import pl.rankforge.gui.RankEditorGui;
import pl.rankforge.kit.KitUtil;
import pl.rankforge.kit.Lang;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class RankCommand implements CommandExecutor, TabCompleter {
    private final RankForge plugin;
    private final RankManager rm;

    public RankCommand(RankForge plugin) {
        this.plugin = plugin;
        this.rm = plugin.ranks();
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (!s.hasPermission("rankforge.admin")) {
            plugin.tr(s, "no-permission");
            return true;
        }
        if (a.length == 0 || a[0].equalsIgnoreCase("help")) {
            help(s);
            return true;
        }
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "create" -> {
                if (a.length < 2) { plugin.tr(s, "usage.create"); return true; }
                Rank r = rm.create(a[1]);
                if (r == null) { plugin.tr(s, "bad-name"); return true; }
                plugin.tr(s, "created", "rank", r.name);
                if (s instanceof Player p) new RankEditorGui(plugin, p, r).open();
            }
            case "edit" -> {
                if (!(s instanceof Player p)) { plugin.tr(s, "players-only"); return true; }
                Rank r = a.length > 1 ? rm.get(a[1]) : null;
                if (r == null) { plugin.tr(s, "usage.edit"); return true; }
                new RankEditorGui(plugin, p, r).open();
            }
            case "delete" -> {
                if (a.length < 2) { plugin.tr(s, "usage.delete"); return true; }
                if (rm.delete(a[1])) plugin.tr(s, "deleted");
                else plugin.tr(s, "delete-fail");
            }
            case "list" -> {
                plugin.tr(s, "list.header");
                for (Rank r : rm.sorted()) {
                    s.sendMessage(Component.text(" - ", NamedTextColor.DARK_GRAY)
                            .append(r.hasPrefix() ? r.prefix().append(Component.space()) : Component.empty())
                            .append(Component.text(r.name, NamedTextColor.WHITE))
                            .append(KitUtil.mm(Lang.s("rank.list.weight", "weight", String.valueOf(r.weight)))));
                }
            }
            case "info" -> {
                Rank r = a.length > 1 ? rm.get(a[1]) : null;
                if (r == null) { plugin.tr(s, "usage.info"); return true; }
                s.sendMessage(KitUtil.mm(Lang.s("rank.info.header"))
                        .append(r.hasPrefix() ? r.prefix() : Component.text(r.name, NamedTextColor.WHITE)));
                for (Component line : PixelArt.render(rm.iconFile(r), 16)) s.sendMessage(line);
                plugin.tr(s, "info.line", "weight", String.valueOf(r.weight),
                        "parent", r.parent == null ? "-" : r.parent, "perms", String.valueOf(r.permissions.size()));
            }
            case "set" -> {
                if (a.length < 3) { plugin.tr(s, "usage.set"); return true; }
                Rank r = rm.get(a[2]);
                OfflinePlayer t = Bukkit.getPlayerExact(a[1]);
                if (t == null) {
                    t = Bukkit.getOfflinePlayer(a[1]);
                    if (!t.hasPlayedBefore()) { plugin.tr(s, "unknown-player"); return true; }
                }
                if (r == null) { plugin.tr(s, "unknown-rank"); return true; }
                rm.setRank(t.getUniqueId(), r);
                plugin.tr(s, "set-ok", "player", a[1], "rank", r.name);
            }
            case "remove" -> {
                if (a.length < 2) { plugin.tr(s, "usage.remove"); return true; }
                OfflinePlayer t = Bukkit.getPlayerExact(a[1]);
                if (t == null) t = Bukkit.getOfflinePlayer(a[1]);
                rm.clearRank(t.getUniqueId());
                plugin.tr(s, "removed");
            }
            case "perm" -> perm(s, a);
            case "parent" -> {
                if (a.length < 3) { plugin.tr(s, "usage.parent"); return true; }
                Rank r = rm.get(a[1]);
                if (r == null) { plugin.tr(s, "unknown-rank"); return true; }
                if (a[2].equalsIgnoreCase("none")) {
                    r.parent = null;
                } else {
                    Rank p = rm.get(a[2]);
                    if (p == null) { plugin.tr(s, "no-parent"); return true; }
                    for (Rank cur = p; cur != null; cur = cur.parent == null ? null : rm.get(cur.parent)) {
                        if (cur == r) { plugin.tr(s, "parent-loop"); return true; }
                    }
                    r.parent = p.name;
                }
                rm.save();
                rm.applyAll();
                plugin.tr(s, "saved");
            }
            case "weight" -> {
                if (a.length < 3) { plugin.tr(s, "usage.weight"); return true; }
                Rank r = rm.get(a[1]);
                if (r == null) { plugin.tr(s, "unknown-rank"); return true; }
                try {
                    r.weight = Math.max(0, Math.min(999, Integer.parseInt(a[2])));
                } catch (NumberFormatException ex) {
                    plugin.tr(s, "not-number");
                    return true;
                }
                rm.save();
                rm.applyAll();
                plugin.tr(s, "weight-set", "weight", String.valueOf(r.weight));
            }
            case "reload" -> {
                plugin.reloadLanguage();
                rm.load();
                plugin.pack().rebuild(true);
                rm.applyAll();
                plugin.tr(s, "reloaded", "count", String.valueOf(plugin.pack().count()));
            }
            case "pack" -> {
                ResourcePackService ps = plugin.pack();
                ps.rebuild(true);
                plugin.tr(s, "pack.status", "count", String.valueOf(ps.count()), "mode", ps.modeName());
                plugin.tr(s, "pack.sha", "sha", ps.sha1Hex().isEmpty() ? "-" : ps.sha1Hex());
                plugin.tr(s, "pack.file");
                if (s instanceof Player p && ps.available()) { ps.send(p); plugin.tr(s, "pack.sent"); }
            }
            default -> help(s);
        }
        return true;
    }

    private void perm(CommandSender s, String[] a) {
        if (a.length < 3) { plugin.tr(s, "usage.perm"); return; }
        Rank r = rm.get(a[1]);
        if (r == null) { plugin.tr(s, "unknown-rank"); return; }
        switch (a[2].toLowerCase(Locale.ROOT)) {
            case "add" -> {
                if (a.length < 4) { plugin.tr(s, "usage.perm-add", "rank", r.name); return; }
                if (!r.permissions.contains(a[3])) r.permissions.add(a[3]);
                rm.save();
                rm.applyAll();
                plugin.tr(s, "perm.added", "perm", a[3], "rank", r.name);
            }
            case "remove" -> {
                if (a.length < 4) { plugin.tr(s, "usage.perm-remove", "rank", r.name); return; }
                if (r.permissions.remove(a[3])) {
                    rm.save();
                    rm.applyAll();
                    plugin.tr(s, "perm.removed", "perm", a[3]);
                } else {
                    plugin.tr(s, "perm.missing");
                }
            }
            case "list" -> {
                plugin.tr(s, "perm.header", "rank", r.name);
                if (r.permissions.isEmpty()) s.sendMessage(KitUtil.mm(Lang.s("rank.perm.none")));
                for (String p : r.permissions) s.sendMessage(Component.text(" - " + p, NamedTextColor.WHITE));
                if (r.parent != null) plugin.tr(s, "perm.inherited", "parent", r.parent);
            }
            default -> plugin.tr(s, "usage.perm");
        }
    }

    private void help(CommandSender s) {
        plugin.msg(s, Lang.s("rank.help.title"));
        for (String l : Lang.l("rank.help.lines")) plugin.msg(s, "<yellow>" + l);
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String label, String[] a) {
        if (!s.hasPermission("rankforge.admin")) return List.of();
        List<String> out = new ArrayList<>();
        if (a.length == 1) {
            out.addAll(List.of("create", "edit", "delete", "list", "info", "set", "remove", "perm", "parent", "weight", "reload", "pack"));
        } else {
            String sub = a[0].toLowerCase(Locale.ROOT);
            if (a.length == 2) {
                switch (sub) {
                    case "edit", "delete", "info", "perm", "parent", "weight" -> rm.sorted().forEach(r -> out.add(r.name));
                    case "set", "remove" -> Bukkit.getOnlinePlayers().forEach(p -> out.add(p.getName()));
                    default -> { }
                }
            } else if (a.length == 3) {
                switch (sub) {
                    case "perm" -> out.addAll(List.of("add", "remove", "list"));
                    case "set" -> rm.sorted().forEach(r -> out.add(r.name));
                    case "parent" -> { rm.sorted().forEach(r -> out.add(r.name)); out.add("none"); }
                    default -> { }
                }
            } else if (a.length == 4 && sub.equals("perm") && a[2].equalsIgnoreCase("remove")) {
                Rank r = rm.get(a[1]);
                if (r != null) out.addAll(r.permissions);
            }
        }
        String last = a[a.length - 1].toLowerCase(Locale.ROOT);
        out.removeIf(x -> !x.toLowerCase(Locale.ROOT).startsWith(last));
        return out;
    }
}
