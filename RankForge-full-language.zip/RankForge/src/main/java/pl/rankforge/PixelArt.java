package pl.rankforge;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextColor;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/** Zamienia PNG na pixel-art zlozony z kolorowych znakow (dziala bez resource packa). */
public final class PixelArt {
    private static final int BG = 0x2A2A2A;

    private PixelArt() {}

    public static List<Component> render(File file, int cols) {
        List<Component> lines = new ArrayList<>();
        if (file == null || !file.exists()) return lines;
        try {
            BufferedImage src = ImageIO.read(file);
            if (src == null) return lines;
            int rows = Math.max(1, (int) Math.round(cols * (double) src.getHeight() / src.getWidth() * 0.75));
            for (int y = 0; y < rows; y++) {
                Component line = Component.empty();
                StringBuilder run = new StringBuilder();
                int runColor = -1;
                for (int x = 0; x < cols; x++) {
                    int c = sample(src, x, y, cols, rows);
                    if (run.length() > 0 && c != runColor) {
                        line = line.append(Component.text(run.toString(), TextColor.color(runColor)));
                        run.setLength(0);
                    }
                    runColor = c;
                    run.append('\u2588');
                }
                if (run.length() > 0) line = line.append(Component.text(run.toString(), TextColor.color(runColor)));
                lines.add(line);
            }
        } catch (IOException ignored) {
        }
        return lines;
    }

    private static int sample(BufferedImage img, int cx, int cy, int cols, int rows) {
        int w = img.getWidth(), h = img.getHeight();
        int x0 = cx * w / cols, x1 = Math.max(x0 + 1, (cx + 1) * w / cols);
        int y0 = cy * h / rows, y1 = Math.max(y0 + 1, (cy + 1) * h / rows);
        long a = 0, r = 0, g = 0, b = 0;
        int n = 0;
        for (int y = y0; y < Math.min(y1, h); y++) {
            for (int x = x0; x < Math.min(x1, w); x++) {
                int p = img.getRGB(x, y);
                int pa = p >>> 24;
                a += pa;
                r += (long) ((p >> 16) & 255) * pa;
                g += (long) ((p >> 8) & 255) * pa;
                b += (long) (p & 255) * pa;
                n++;
            }
        }
        if (n == 0 || a == 0 || a / n < 100) return BG;
        return ((int) (r / a) << 16) | ((int) (g / a) << 8) | (int) (b / a);
    }
}
