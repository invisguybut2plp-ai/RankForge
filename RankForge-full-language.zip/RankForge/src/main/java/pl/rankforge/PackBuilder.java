package pl.rankforge;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** Buduje resource pack z czcionką bitmapową: kazda ikona rangi = jeden znak (U+E000...). */
public final class PackBuilder {
    private PackBuilder() {}

    public record Result(Set<String> included, byte[] zip, byte[] sha1) {}

    public static Result build(Map<String, File> icons, Map<String, Integer> glyphs, int height, int packFormat, String description) throws IOException {
        Set<String> included = new LinkedHashSet<>();
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        StringBuilder providers = new StringBuilder();
        try (ZipOutputStream zip = new ZipOutputStream(bos)) {
            String mcmeta = "{\"pack\":{\"pack_format\":" + packFormat
                    + ",\"supported_formats\":{\"min_inclusive\":34,\"max_inclusive\":999},"
                    + "\"description\":\"" + jsonEscape(description) + "\"}}";
            put(zip, "pack.mcmeta", mcmeta.getBytes(StandardCharsets.UTF_8));

            for (Map.Entry<String, File> e : icons.entrySet()) {
                Integer glyph = glyphs.get(e.getKey());
                if (glyph == null) continue;
                BufferedImage src;
                try {
                    src = ImageIO.read(e.getValue());
                } catch (IOException ex) {
                    continue;
                }
                if (src == null) continue;
                BufferedImage img = new BufferedImage(src.getWidth(), src.getHeight(), BufferedImage.TYPE_INT_ARGB);
                img.getGraphics().drawImage(src, 0, 0, null);
                ByteArrayOutputStream png = new ByteArrayOutputStream();
                ImageIO.write(img, "png", png);
                put(zip, "assets/rankforge/textures/icon/" + e.getKey() + ".png", png.toByteArray());

                if (providers.length() > 0) providers.append(',');
                providers.append("{\"type\":\"bitmap\",\"file\":\"rankforge:icon/").append(e.getKey())
                        .append(".png\",\"ascent\":").append(height - 1)
                        .append(",\"height\":").append(height)
                        .append(",\"chars\":[\"").append(String.format("\\u%04x", glyph)).append("\"]}");
                included.add(e.getKey());
            }
            if (included.isEmpty()) return new Result(included, null, null);
            String font = "{\"providers\":[" + providers + "]}";
            put(zip, "assets/rankforge/font/icons.json", font.getBytes(StandardCharsets.UTF_8));
        }
        byte[] data = bos.toByteArray();
        try {
            return new Result(included, data, MessageDigest.getInstance("SHA-1").digest(data));
        } catch (NoSuchAlgorithmException ex) {
            throw new IOException(ex);
        }
    }

    private static String jsonEscape(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " ").replace("\r", " ");
    }

    private static void put(ZipOutputStream zip, String name, byte[] data) throws IOException {
        ZipEntry ze = new ZipEntry(name);
        ze.setTime(946684800000L);
        zip.putNextEntry(ze);
        zip.write(data);
        zip.closeEntry();
    }

    public static String hex(byte[] b) {
        StringBuilder sb = new StringBuilder();
        for (byte x : b) sb.append(String.format("%02x", x));
        return sb.toString();
    }
}
