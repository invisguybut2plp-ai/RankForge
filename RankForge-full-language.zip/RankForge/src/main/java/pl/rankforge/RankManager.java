package pl.rankforge;

import net.kyori.adventure.audience.Audience;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.JoinConfiguration;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.permissions.PermissionAttachment;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;
import pl.rankforge.kit.KitUtil;
import pl.rankforge.kit.Lang;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class RankManager {
    private static final String TEAM_PREFIX = "rfx";

    private final RankForge plugin;
    private final Map<String, Rank> ranks = new ConcurrentHashMap<>();
    private final Map<UUID, String> assigned = new ConcurrentHashMap<>();
    private final Map<UUID, PermissionAttachment> attachments = new HashMap<>();
    private final Map<String, Component> hoverCache = new ConcurrentHashMap<>();
    private File ranksFile, playersFile, iconsDir;

    public RankManager(RankForge plugin) {
        this.plugin = plugin;
    }

    // ---------------------------------------------------------------- storage

    public void load() {
        File dir = plugin.getDataFolder();
        dir.mkdirs();
        iconsDir = new File(dir, "Icons");
        boolean first = !iconsDir.exists();
        iconsDir.mkdirs();
        if (first) writeReadme();
        ranksFile = new File(dir, "ranks.yml");
        playersFile = new File(dir, "players.yml");

        ranks.clear();
        assigned.clear();
        hoverCache.clear();

        YamlConfiguration y = YamlConfiguration.loadConfiguration(ranksFile);
        ConfigurationSection sec = y.getConfigurationSection("ranks");
        if (sec != null) {
            for (String key : sec.getKeys(false)) {
                ConfigurationSection s = sec.getConfigurationSection(key);
                if (s == null) continue;
                Rank r = new Rank(key);
                r.prefixText = s.getString("prefix", "");
                r.colors = new ArrayList<>(s.getStringList("colors"));
                r.bold = s.getBoolean("bold", false);
                r.nameColor = s.getString("name-color", "#ffffff");
                r.chatColor = s.getString("chat-color", "#ffffff");
                r.weight = s.getInt("weight", 10);
                r.glyph = s.getInt("glyph", 0);
                r.parent = s.getString("parent", null);
                r.permissions = new ArrayList<>(s.getStringList("permissions"));
                ranks.put(r.name, r);
            }
        }
        if (ranks.isEmpty()) {
            Rank def = new Rank("default");
            def.prefixText = "";
            def.nameColor = "#aaaaaa";
            def.weight = 0;
            ranks.put(def.name, def);

            Rank admin = new Rank("admin");
            admin.prefixText = "[ADMIN]";
            admin.colors = new ArrayList<>(List.of("#ff5555", "#ffaa00"));
            admin.bold = true;
            admin.nameColor = "#ffaa00";
            admin.weight = 100;
            ranks.put(admin.name, admin);
        }

        YamlConfiguration p = YamlConfiguration.loadConfiguration(playersFile);
        ConfigurationSection ps = p.getConfigurationSection("players");
        if (ps != null) {
            for (String k : ps.getKeys(false)) {
                try {
                    assigned.put(UUID.fromString(k), ps.getString(k, "default"));
                } catch (IllegalArgumentException ignored) {
                }
            }
        }
        save();
    }

    public synchronized void save() {
        YamlConfiguration y = new YamlConfiguration();
        for (Rank r : sorted()) {
            String b = "ranks." + r.name + ".";
            y.set(b + "prefix", r.prefixText);
            y.set(b + "colors", r.colors);
            y.set(b + "bold", r.bold);
            y.set(b + "name-color", r.nameColor);
            y.set(b + "chat-color", r.chatColor);
            y.set(b + "weight", r.weight);
            y.set(b + "glyph", r.glyph);
            y.set(b + "parent", r.parent);
            y.set(b + "permissions", r.permissions);
        }
        YamlConfiguration p = new YamlConfiguration();
        assigned.forEach((id, rank) -> p.set("players." + id, rank));
        try {
            y.save(ranksFile);
            p.save(playersFile);
        } catch (IOException e) {
            plugin.getLogger().warning(Lang.s("log.rank-save-failed", "error", String.valueOf(e.getMessage())));
        }
    }

    private void writeReadme() {
        String txt = String.join(System.lineSeparator(), Lang.l("rank.icons-readme")) + System.lineSeparator();
        try {
            Files.writeString(new File(iconsDir, "README.txt").toPath(), txt);
        } catch (IOException ignored) {
        }
    }

    // ---------------------------------------------------------------- ranks

    public Rank get(String n) {
        return n == null ? null : ranks.get(n.toLowerCase(Locale.ROOT));
    }

    public List<Rank> sorted() {
        return ranks.values().stream()
                .sorted(Comparator.comparingInt((Rank r) -> r.weight).reversed().thenComparing(r -> r.name))
                .toList();
    }

    public Rank create(String name) {
        name = name.toLowerCase(Locale.ROOT);
        if (!name.matches("[a-z0-9_-]{1,24}") || ranks.containsKey(name)) return null;
        Rank r = new Rank(name);
        ranks.put(name, r);
        save();
        return r;
    }

    public boolean delete(String name) {
        name = name.toLowerCase(Locale.ROOT);
        if (name.equals("default") || ranks.remove(name) == null) return false;
        for (Rank r : ranks.values()) if (name.equals(r.parent)) r.parent = null;
        save();
        applyAll();
        return true;
    }

    public Rank rankOf(UUID id) {
        Rank r = get(assigned.get(id));
        return r != null ? r : ranks.get("default");
    }

    public void setRank(UUID id, Rank r) {
        assigned.put(id, r.name);
        save();
        Player p = Bukkit.getPlayer(id);
        if (p != null) apply(p);
        cleanupTeams();
    }

    public void clearRank(UUID id) {
        assigned.remove(id);
        save();
        Player p = Bukkit.getPlayer(id);
        if (p != null) apply(p);
        cleanupTeams();
    }

    public Set<String> effectivePermissions(Rank r) {
        List<Rank> chain = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        Rank cur = r;
        while (cur != null && seen.add(cur.name)) {
            chain.add(cur);
            cur = cur.parent == null ? null : ranks.get(cur.parent);
        }
        Collections.reverse(chain);
        Set<String> out = new LinkedHashSet<>();
        for (Rank c : chain) out.addAll(c.permissions);
        return out;
    }

    public void assignGlyphs(Collection<String> names) {
        Set<Integer> used = new HashSet<>();
        int next = 0xE000;
        boolean changed = false;
        for (String n : names) {
            Rank r = ranks.get(n);
            if (r == null) continue;
            if (r.glyph == 0 || !used.add(r.glyph)) {
                while (used.contains(next)) next++;
                r.glyph = next;
                used.add(next);
                changed = true;
            }
        }
        if (changed) save();
    }

    // ---------------------------------------------------------------- icons

    public File iconFile(Rank r) {
        return new File(iconsDir, r.name + ".png");
    }

    public void clearCache() {
        hoverCache.clear();
    }

    private static int lerp(int a, int b, float t) {
        return Math.round(a + (b - a) * t);
    }

    public Component hover(Rank r) {
        return hoverCache.computeIfAbsent(r.name, k -> {
            Component head = KitUtil.mm(Lang.s("rank.hover"))
                    .append(r.hasPrefix() ? r.prefix() : Component.text(r.name, NamedTextColor.WHITE));
            List<Component> art = PixelArt.render(iconFile(r), 16);
            if (art.isEmpty()) return head;
            return head.appendNewline().append(Component.join(JoinConfiguration.newlines(), art));
        });
    }

    // ---------------------------------------------------------------- chat / tab / permissions

    public Component formatChat(Player p, Component message, Audience viewer) {
        Rank r = rankOf(p.getUniqueId());
        if (r == null) {
            return Component.text(p.getName()).append(Component.text(": ", NamedTextColor.GRAY)).append(message);
        }
        ResourcePackService pack = plugin.pack();
        boolean icon = pack != null && plugin.getConfig().getBoolean("icons.in-chat", true) && pack.has(r)
                && viewer instanceof Player vp && pack.viewerHasPack(vp.getUniqueId());
        Component out = Component.empty();
        if (icon || r.hasPrefix()) {
            Component head = Component.empty();
            if (icon) head = head.append(pack.icon(r));
            if (icon && r.hasPrefix()) head = head.append(Component.space());
            if (r.hasPrefix()) head = head.append(r.prefix());
            out = out.append(head.hoverEvent(HoverEvent.showText(hover(r)))).append(Component.space());
        }
        return out.append(r.nameComponent(p.getName()))
                .append(Component.text(": ", NamedTextColor.GRAY))
                .append(message.colorIfAbsent(r.chat()));
    }

    public void apply(Player p) {
        Rank r = rankOf(p.getUniqueId());

        // permisje
        PermissionAttachment old = attachments.remove(p.getUniqueId());
        if (old != null) {
            try {
                p.removeAttachment(old);
            } catch (IllegalArgumentException ignored) {
            }
        }
        if (r != null) {
            PermissionAttachment att = p.addAttachment(plugin);
            for (String perm : effectivePermissions(r)) {
                boolean neg = perm.startsWith("-");
                String node = neg ? perm.substring(1) : perm;
                if (!node.isBlank()) att.setPermission(node, !neg);
            }
            attachments.put(p.getUniqueId(), att);
        }
        p.recalculatePermissions();
        p.updateCommands();

        // nazwa w tabie: klient NIE dodaje prefiksu teamu do własnej nazwy tab, więc wstawiamy go sami
        ResourcePackService pack = plugin.pack();
        boolean hasPrefix = r != null && r.hasPrefix();
        boolean tabIcon = pack != null && r != null && plugin.getConfig().getBoolean("icons.in-tab", true) && pack.has(r);
        Component prefix = r != null ? r.prefix() : Component.empty();
        Component name = r != null ? r.nameComponent(p.getName()) : Component.text(p.getName());
        Component iconC = tabIcon ? pack.icon(r).append(Component.space()) : Component.empty();
        Component full = iconC.append(hasPrefix ? prefix.append(Component.space()).append(name) : name);
        p.displayName(hasPrefix ? prefix.append(Component.space()).append(name) : name);
        p.playerListName(full);

        // team = prefix w tabie, nad glowa i kolejnosc w tabie
        Scoreboard sb = Bukkit.getScoreboardManager().getMainScoreboard();
        for (Team t : sb.getTeams()) {
            if (t.getName().startsWith(TEAM_PREFIX) && t.hasEntry(p.getName())) t.removeEntry(p.getName());
        }
        if (r != null) {
            String tn = String.format(TEAM_PREFIX + "%03d", Math.max(0, sorted().indexOf(r)));
            Team t = sb.getTeam(tn);
            if (t == null) t = sb.registerNewTeam(tn);
            boolean ntIcon = pack != null && plugin.getConfig().getBoolean("icons.in-nametag", false) && pack.has(r);
            Component ntp = (ntIcon ? pack.icon(r).append(Component.space()) : Component.empty())
                    .append(hasPrefix ? prefix.append(Component.space()) : Component.empty());
            t.prefix(ntp);
            t.color(NamedTextColor.nearestTo(TextColor.color(Rank.rgb(r.nameColor, 0xFFFFFF))));
            t.addEntry(p.getName());
        }
    }

    public void applyAll() {
        hoverCache.clear();
        for (Player p : Bukkit.getOnlinePlayers()) apply(p);
        cleanupTeams();
    }

    private void cleanupTeams() {
        Scoreboard sb = Bukkit.getScoreboardManager().getMainScoreboard();
        for (Team t : new ArrayList<>(sb.getTeams())) {
            if (t.getName().startsWith(TEAM_PREFIX) && t.getSize() == 0) t.unregister();
        }
    }

    public void release(Player p) {
        PermissionAttachment old = attachments.remove(p.getUniqueId());
        if (old != null) {
            try {
                p.removeAttachment(old);
            } catch (IllegalArgumentException ignored) {
            }
        }
        Scoreboard sb = Bukkit.getScoreboardManager().getMainScoreboard();
        for (Team t : sb.getTeams()) {
            if (t.getName().startsWith(TEAM_PREFIX) && t.hasEntry(p.getName())) t.removeEntry(p.getName());
        }
        cleanupTeams();
    }

    public void shutdown() {
        for (Player p : Bukkit.getOnlinePlayers()) release(p);
        save();
    }
}
