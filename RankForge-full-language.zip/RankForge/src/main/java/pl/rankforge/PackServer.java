package pl.rankforge;

import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Maleńki serwer HTTP, który wystawia resourcepack.zip graczom. */
public class PackServer {
    private final int port;
    private HttpServer server;
    private ExecutorService pool;
    private volatile byte[] data = new byte[0];

    public PackServer(int port) {
        this.port = port;
    }

    public void setData(byte[] data) {
        this.data = data == null ? new byte[0] : data;
    }

    public void start() throws IOException {
        server = HttpServer.create(new InetSocketAddress(port), 0);
        pool = Executors.newFixedThreadPool(2, r -> {
            Thread t = new Thread(r, "RankForge-PackServer");
            t.setDaemon(true);
            return t;
        });
        server.createContext("/rankforge.zip", ex -> {
            byte[] d = data;
            ex.getResponseHeaders().add("Content-Type", "application/zip");
            if ("HEAD".equalsIgnoreCase(ex.getRequestMethod())) {
                ex.getResponseHeaders().add("Content-Length", String.valueOf(d.length));
                ex.sendResponseHeaders(200, -1);
                ex.close();
                return;
            }
            ex.sendResponseHeaders(200, d.length);
            try (OutputStream os = ex.getResponseBody()) {
                os.write(d);
            }
        });
        server.setExecutor(pool);
        server.start();
    }

    public void stop() {
        if (server != null) server.stop(0);
        if (pool != null) pool.shutdownNow();
    }
}
