# RankForge (Paper 1.21.11)

Budowanie: `mvn clean package` (Java 21) -> `target/RankForge.jar` -> wrzuć do `plugins/`.

Pierwsze uruchomienie tworzy `plugins/RankForge/` z: `ranks.yml`, `players.yml`, `Icons/`.

Komendy (perm `rankforge.admin`, domyślnie OP): `/rank help`

## Kity (`/kit`)

Gracz: `/kit` (menu), `/kit <kit>` (podglad + REDEEM), `/kit help`. Perm: `rankforge.kit` (domyslnie wszyscy).
Admin (`rankforge.kit.admin` lub `rankforge.admin`): `/kit create [id]`, `edit`, `delete`, `clone`, `list`, `give`, `reset`, `seticon`, `reload`.
Bypass rang/cooldownow: `rankforge.kit.bypass`.
Pliki: `kits.yml` (definicje, itemy z pelnym ItemStack), `kit-data.yml` (cooldowny/statystyki), `kit-log.txt`.
Ustawienia: sekcja `kits:` w `config.yml`; wiadomości i teksty: `lang/*.yml`.
- (opcjonalnie) PlaceholderAPI: %rankforge_kit_count%, %rankforge_kit_available_<kit>%, %rankforge_kit_cooldown_<kit>%, %rankforge_kit_rank_<kit>%, %rankforge_kit_redeemed_<kit>%

### Język i wygląd (cała wtyczka)
- `language: pl` / `en` w `config.yml` zmienia język **wszystkiego**: GUI (rangi, kolory, kity), nazwy i opisy przedmiotów w GUI, wiadomości na czacie, komendy `/rank` i `/kit` (pomoc, opisy), komunikaty w konsoli oraz opis paczki ikon. Po zmianie: `/rank reload` albo `/kit reload`.
- Teksty w `plugins/RankForge/lang/*.yml` (kolory MiniMessage lub `&`, lore jako szablony z `{placeholderami}`): sekcje `rank:` (rangi, edytor, paleta kolorów), `ed:`/`menu:`/`preview:`/... (kity), `log:` (konsola). Brakujący klucz w Twoim pliku jest brany z wbudowanego pliku tego samego języka, więc stary plik nie pokaże tekstu w złym języku.
- Własny język: skopiuj `lang/en.yml` jako `lang/xx.yml`, przetłumacz i ustaw `language: xx`.
- Placeholdery PlaceholderAPI (`yes`/`no`/`ready`/`unavailable`) zwracają stałe wartości niezależne od języka, żeby nie psuć warunków w innych wtyczkach.
- Domyślna ikona kitów: `kits.default-icon` (BOOK). Inne ikony zależnie od statusu: `kits.gui.status-icons`. Dźwięki, tytuł po odbiorze i filler: sekcja `kits:` w `config.yml`.
