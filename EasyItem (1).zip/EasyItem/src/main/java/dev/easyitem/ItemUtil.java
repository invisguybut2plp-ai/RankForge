package dev.easyitem;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.*;
import org.bukkit.attribute.*;
import org.bukkit.command.CommandSender;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import java.util.*;
import java.util.function.Consumer;
import java.util.stream.Collectors;

public final class ItemUtil {
    private ItemUtil() {}
    private static final LegacyComponentSerializer LEG = LegacyComponentSerializer.builder().character('&').hexColors().build();

    /** &c colors and &#rrggbb hex, italics off. */
    public static Component color(String s) { return LEG.deserialize(s).decoration(TextDecoration.ITALIC, false); }
    public static void msg(CommandSender s, String t) { s.sendMessage(color("&6[EasyItem] &f" + t)); }
    public static String txt(String[] a, int i) { return i >= a.length ? "" : String.join(" ", Arrays.copyOfRange(a, i, a.length)); }
    public static List<Component> lore(ItemMeta m) { return m.lore() == null ? new ArrayList<>() : new ArrayList<>(m.lore()); }

    static NamespacedKey abKey() { return new NamespacedKey(EasyItem.I, "abilities"); }

    public static List<Ability> abilities(ItemMeta m) {
        List<Ability> out = new ArrayList<>();
        if (m == null) return out;
        String raw = m.getPersistentDataContainer().get(abKey(), PersistentDataType.STRING);
        if (raw == null || raw.isEmpty()) return out;
        for (String l : raw.split("\n")) try { out.add(Ability.parse(l)); } catch (Exception ignored) {}
        return out;
    }
    public static List<Ability> abilities(ItemStack it) { return it == null ? new ArrayList<>() : abilities(it.getItemMeta()); }

    public static void setAbilities(ItemMeta m, List<Ability> list) {
        if (list.isEmpty()) m.getPersistentDataContainer().remove(abKey());
        else m.getPersistentDataContainer().set(abKey(), PersistentDataType.STRING,
                list.stream().map(Ability::serialize).collect(Collectors.joining("\n")));
    }
    public static void addAbility(ItemMeta m, Ability ab) { List<Ability> l = abilities(m); l.add(ab); setAbilities(m, l); }

    public static Enchantment enchant(String n) {
        try { return Registry.ENCHANTMENT.get(NamespacedKey.minecraft(n.toLowerCase().replace("minecraft:", ""))); }
        catch (Exception e) { return null; }
    }

    public static Attribute attribute(String n) {
        n = n.toLowerCase().replaceFirst("^(generic|player)[_.]", "");
        for (String c : new String[]{n, "generic." + n, "player." + n}) {
            try { Attribute a = Registry.ATTRIBUTE.get(NamespacedKey.minecraft(c)); if (a != null) return a; }
            catch (Exception ignored) {}
        }
        return null;
    }

    public static void addAttribute(ItemMeta m, String name, double amt, String slot, String op) {
        Attribute at = attribute(name);
        if (at == null) throw new IllegalArgumentException("Unknown attribute: " + name);
        EquipmentSlotGroup g = EquipmentSlotGroup.getByName(slot.toLowerCase());
        if (g == null) throw new IllegalArgumentException("Unknown slot: " + slot + " (mainhand, offhand, head, chest, legs, feet, armor, any)");
        m.addAttributeModifier(at, new AttributeModifier(new NamespacedKey(EasyItem.I, "m" + System.nanoTime()),
                amt, AttributeModifier.Operation.valueOf(op.toUpperCase()), g));
    }

    /** Edit the meta of the item in the player's main hand. */
    public static boolean edit(Player p, Consumer<ItemMeta> c) {
        ItemStack it = p.getInventory().getItemInMainHand();
        if (it.getType().isAir()) { msg(p, "&cHold an item first!"); return false; }
        ItemMeta m = it.getItemMeta();
        c.accept(m);
        it.setItemMeta(m);
        p.getInventory().setItemInMainHand(it);
        return true;
    }

    // ---------- protection flags (soulbound / undroppable / noplace) ----------
    static NamespacedKey pKey() { return new NamespacedKey(EasyItem.I, "protect"); }

    public static Set<String> flags(ItemMeta m) {
        if (m == null) return new HashSet<>();
        String s = m.getPersistentDataContainer().get(pKey(), PersistentDataType.STRING);
        return s == null || s.isEmpty() ? new HashSet<>() : new HashSet<>(Arrays.asList(s.split(",")));
    }
    public static boolean hasFlag(ItemStack it, String f) { return it != null && it.hasItemMeta() && flags(it.getItemMeta()).contains(f); }
    public static void toggleFlag(ItemMeta m, String f) {
        Set<String> s = flags(m);
        if (!s.remove(f)) s.add(f);
        if (s.isEmpty()) m.getPersistentDataContainer().remove(pKey());
        else m.getPersistentDataContainer().set(pKey(), PersistentDataType.STRING, String.join(",", s));
    }
}
