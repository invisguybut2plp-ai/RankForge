package dev.easyitem;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.*;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import java.util.*;
import java.util.function.Consumer;
import static dev.easyitem.ItemUtil.*;

/** Chest-GUI editor for the item in your main hand. */
public class Editor implements Listener {
    static class Gui implements InventoryHolder {
        final Inventory inv;
        final Map<Integer, Consumer<InventoryClickEvent>> actions = new HashMap<>();
        Gui(int size, String title) {
            inv = Bukkit.createInventory(this, size, color(title));
            ItemStack f = icon(Material.GRAY_STAINED_GLASS_PANE, " ");
            for (int i = 0; i < size; i++) inv.setItem(i, f);
        }
        void set(int slot, ItemStack it, Consumer<InventoryClickEvent> a) { inv.setItem(slot, it); if (a != null) actions.put(slot, a); }
        @Override public Inventory getInventory() { return inv; }
    }

    private final Map<UUID, Consumer<String>> pending = new HashMap<>();

    static ItemStack icon(Material m, String name, String... lore) {
        ItemStack i = new ItemStack(m);
        ItemMeta mm = i.getItemMeta();
        mm.displayName(color(name));
        if (lore.length > 0) mm.lore(Arrays.stream(lore).map(ItemUtil::color).toList());
        i.setItemMeta(mm);
        return i;
    }

    /** Close the GUI, wait for the player's next chat message, then reopen the editor. */
    private void ask(Player p, String prompt, Consumer<String> handler) {
        p.closeInventory();
        msg(p, prompt + " &7(type &ccancel&7 to abort)");
        pending.put(p.getUniqueId(), s -> {
            try { handler.accept(s); } catch (Exception ex) { msg(p, "&c" + ex.getMessage()); }
            open(p);
        });
    }

    private void safe(Player p, Runnable r) { try { r.run(); } catch (Exception ex) { msg(p, "&c" + ex.getMessage()); } }

    private static String onOff(boolean b) { return b ? "&2ON" : "&cOFF"; }

    // ---------------- main menu ----------------
    public void open(Player p) {
        ItemStack it = p.getInventory().getItemInMainHand();
        if (it.getType().isAir()) { msg(p, "&cHold an item to edit it."); return; }
        ItemMeta m = it.getItemMeta();
        Set<String> fl = flags(m);
        Gui g = new Gui(27, "&8EasyItem Editor");
        g.set(13, it.clone(), null);
        g.set(10, icon(Material.NAME_TAG, "&eRename", "&7Type the name in chat", "&7Color codes and hex work"),
            e -> ask(p, "Type the new name.", s -> edit(p, x -> x.displayName(color(s)))));
        g.set(11, icon(Material.WRITABLE_BOOK, "&eAdd lore line", "&7Type the line in chat"),
            e -> ask(p, "Type the lore line.", s -> edit(p, x -> { List<Component> lo = lore(x); lo.add(color(s)); x.lore(lo); })));
        g.set(12, icon(Material.BARRIER, "&cClear lore"), e -> { edit(p, x -> x.lore(null)); open(p); });
        g.set(14, icon(Material.ENCHANTING_TABLE, "&dEnchantments", "&7Any enchant, level up to 255"), e -> openEnchants(p));
        g.set(15, icon(Material.BLAZE_POWDER, "&6Abilities", "&7" + abilities(m).size() + " on this item", "&7Pick WHEN + WHAT"), e -> openAbilities(p));
        g.set(16, icon(Material.IRON_SWORD, "&bAdd attribute", "&7Type: <attribute> <amount> [slot]", "&7e.g. attack_damage 20 mainhand"),
            e -> ask(p, "Type: <attribute> <amount> [slot]", s -> edit(p, x -> {
                String[] t = s.trim().split("\\s+");
                addAttribute(x, t[0], Double.parseDouble(t[1]), t.length > 2 ? t[2] : "mainhand", "add_number");
            })));
        g.set(19, icon(Material.ANVIL, "&aUnbreakable: " + onOff(m.isUnbreakable()), "&7Click to toggle"),
            e -> { edit(p, x -> x.setUnbreakable(!x.isUnbreakable())); open(p); });
        g.set(20, icon(Material.GLOWSTONE_DUST, "&aGlow: " + onOff(Boolean.TRUE.equals(m.getEnchantmentGlintOverride())), "&7Click to toggle"),
            e -> { edit(p, x -> x.setEnchantmentGlintOverride(!Boolean.TRUE.equals(x.getEnchantmentGlintOverride()))); open(p); });
        g.set(21, icon(Material.BOOKSHELF, "&6Presets", "&7Ready-made ability kits", "&7(edit them in config.yml)"), e -> openPresets(p));
        g.set(22, icon(Material.EMERALD, "&aSave to library", "&7Type an id in chat"),
            e -> ask(p, "Type an id to save this item as.", s -> {
                String id = s.trim().replace(' ', '_');
                EasyItem.I.saveItem(id, p.getInventory().getItemInMainHand());
                msg(p, "&aSaved! Get it back with /ei give " + id);
            }));
        g.set(23, icon(Material.TOTEM_OF_UNDYING, "&aSoulbound: " + onOff(fl.contains("soulbound")), "&7Keep on death"),
            e -> { edit(p, x -> toggleFlag(x, "soulbound")); open(p); });
        g.set(24, icon(Material.HOPPER, "&aUndroppable: " + onOff(fl.contains("undroppable")), "&7Can't be thrown away"),
            e -> { edit(p, x -> toggleFlag(x, "undroppable")); open(p); });
        g.set(26, icon(Material.REDSTONE, "&cClose"), e -> p.closeInventory());
        p.openInventory(g.inv);
    }

    // ---------------- enchants ----------------
    private void openEnchants(Player p) {
        ItemMeta m = p.getInventory().getItemInMainHand().getItemMeta();
        Gui g = new Gui(54, "&8Enchantments");
        int i = 0;
        for (Enchantment en : Registry.ENCHANTMENT) {
            if (i >= 45) break;
            int lv = m.getEnchantLevel(en);
            g.set(i++, icon(lv > 0 ? Material.ENCHANTED_BOOK : Material.BOOK, (lv > 0 ? "&d" : "&7") + en.getKey().getKey() + " &f" + lv,
                "&eLeft +1 &7| &eRight -1", "&eShift +10 / -10 &7| &eQ = 255"), e -> {
                int cur = p.getInventory().getItemInMainHand().getItemMeta().getEnchantLevel(en);
                int nl = switch (e.getClick()) {
                    case LEFT -> cur + 1; case RIGHT -> cur - 1;
                    case SHIFT_LEFT -> cur + 10; case SHIFT_RIGHT -> cur - 10;
                    case DROP -> 255; default -> cur;
                };
                final int lvl = Math.max(0, Math.min(255, nl));
                edit(p, x -> { if (lvl == 0) x.removeEnchant(en); else x.addEnchant(en, lvl, true); });
                openEnchants(p);
            });
        }
        g.set(49, icon(Material.ARROW, "&7Back"), e -> open(p));
        p.openInventory(g.inv);
    }

    // ---------------- presets ----------------
    private void openPresets(Player p) {
        Gui g = new Gui(27, "&8Presets");
        var sec = EasyItem.I.getConfig().getConfigurationSection("presets");
        int i = 0;
        if (sec != null) for (String key : sec.getKeys(false)) {
            if (i >= 18) break;
            List<String> lines = new ArrayList<>(sec.getStringList(key).stream().map(l -> "&7" + l).toList());
            lines.add("&aClick to add to your item");
            g.set(i++, icon(Material.BOOK, "&e" + key, lines.toArray(new String[0])),
                e -> { safe(p, () -> edit(p, x -> EasyItem.I.applyPreset(x, key))); open(p); });
        }
        g.set(26, icon(Material.ARROW, "&7Back"), e -> open(p));
        p.openInventory(g.inv);
    }

    // ---------------- abilities ----------------
    private void openAbilities(Player p) {
        List<Ability> list = abilities(p.getInventory().getItemInMainHand());
        Gui g = new Gui(27, "&8Abilities");
        for (int i = 0; i < list.size() && i < 18; i++) {
            final int idx = i;
            Ability a = list.get(i);
            g.set(i, icon(Material.BLAZE_POWDER, "&6" + a.type(), "&7When: &f" + a.trigger() + " &8(" + Ability.TRIGGER_INFO.get(a.trigger()) + ")",
                "&7Cooldown: &f" + a.cooldown() + "s", "&7Params: &f" + a.param(), " ",
                "&eLeft click: &7next trigger", "&eRight click: &7edit cooldown/params", "&eShift+Right: &cremove"), e -> {
                ClickType ct = e.getClick();
                if (ct == ClickType.RIGHT) {
                    ask(p, "Type: &e<cooldown> <params>&f (now: &e" + a.cooldown() + " " + a.param() + "&f)", s -> {
                        String[] sp = s.trim().split("\\s+", 2);
                        double cd = Double.parseDouble(sp[0]);
                        edit(p, x -> { List<Ability> l = abilities(x); Ability o = l.get(idx); l.set(idx, new Ability(o.trigger(), o.type(), sp.length > 1 ? sp[1] : "", cd)); setAbilities(x, l); });
                    });
                    return;
                }
                if (ct == ClickType.SHIFT_RIGHT) edit(p, x -> { List<Ability> l = abilities(x); l.remove(idx); setAbilities(x, l); });
                else if (ct == ClickType.LEFT) edit(p, x -> {
                    List<Ability> l = abilities(x); Ability o = l.get(idx);
                    String nt = Ability.TRIGGERS.get((Ability.TRIGGERS.indexOf(o.trigger()) + 1) % Ability.TRIGGERS.size());
                    l.set(idx, new Ability(nt, o.type(), o.param(), o.cooldown())); setAbilities(x, l);
                });
                openAbilities(p);
            });
        }
        g.set(22, icon(Material.EMERALD, "&aAdd ability", "&7Choose when it fires, then what it does"), e -> pickTrigger(p));
        g.set(26, icon(Material.ARROW, "&7Back"), e -> open(p));
        p.openInventory(g.inv);
    }

    private void pickTrigger(Player p) {
        Gui g = new Gui(18, "&8WHEN should it fire?");
        int i = 0;
        for (String t : Ability.TRIGGERS) { final String trig = t; g.set(i++, icon(Material.LEVER, "&e" + t, "&7" + Ability.TRIGGER_INFO.get(t)), e -> pickType(p, trig)); }
        g.set(17, icon(Material.ARROW, "&7Back"), e -> openAbilities(p));
        p.openInventory(g.inv);
    }

    private void pickType(Player p, String trigger) {
        Gui g = new Gui(36, "&8WHAT should it do?");
        int i = 0;
        for (String t : Ability.TYPES) {
            final String type = t;
            String hint = Ability.HINT.getOrDefault(t, "");
            g.set(i++, icon(Material.NETHER_STAR, "&b" + t, "&7Example: &f5 " + hint), e ->
                ask(p, "Type: &e<cooldown seconds> <params>&f  e.g. &e5 " + hint, s -> {
                    String[] sp = s.trim().split("\\s+", 2);
                    Ability ab = new Ability(trigger, type, sp.length > 1 ? sp[1] : "", Double.parseDouble(sp[0]));
                    edit(p, x -> addAbility(x, ab));
                }));
        }
        p.openInventory(g.inv);
    }

    // ---------------- events ----------------
    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof Gui g)) return;
        e.setCancelled(true);
        if (e.getClickedInventory() == e.getView().getTopInventory()) {
            var a = g.actions.get(e.getSlot());
            if (a != null) a.accept(e);
        }
    }
    @EventHandler public void onDrag(InventoryDragEvent e) { if (e.getView().getTopInventory().getHolder() instanceof Gui) e.setCancelled(true); }
    @EventHandler public void onQuit(PlayerQuitEvent e) { pending.remove(e.getPlayer().getUniqueId()); }

    @EventHandler
    public void onChat(AsyncChatEvent e) {
        Consumer<String> h = pending.remove(e.getPlayer().getUniqueId());
        if (h == null) return;
        e.setCancelled(true);
        String s = PlainTextComponentSerializer.plainText().serialize(e.message());
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTask(EasyItem.I, () -> { if (s.equalsIgnoreCase("cancel")) open(p); else h.accept(s); });
    }
}
