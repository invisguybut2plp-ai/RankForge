package dev.easyitem;

import org.bukkit.event.*;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.inventory.ItemStack;
import java.util.Iterator;

/** Item protection flags: soulbound (kept on death), undroppable, noplace. */
public class ProtectListener implements Listener {
    public static final java.util.List<String> FLAGS = java.util.List.of("soulbound", "undroppable", "noplace");

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        if (e.getKeepInventory()) return;
        Iterator<ItemStack> it = e.getDrops().iterator();
        while (it.hasNext()) {
            ItemStack i = it.next();
            if (ItemUtil.hasFlag(i, "soulbound")) { e.getItemsToKeep().add(i); it.remove(); }
        }
    }
    @EventHandler public void onDrop(PlayerDropItemEvent e) { if (ItemUtil.hasFlag(e.getItemDrop().getItemStack(), "undroppable")) e.setCancelled(true); }
    @EventHandler public void onPlace(BlockPlaceEvent e) { if (ItemUtil.hasFlag(e.getItemInHand(), "noplace")) e.setCancelled(true); }
}
