package dev.easyitem;

import com.destroystokyo.paper.event.player.PlayerJumpEvent;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import java.util.*;

/** Turns game events into ability triggers. */
public class AbilityListener implements Listener {
    private final Map<String, Long> cooldowns = new HashMap<>();
    private boolean busy; // stops abilities from re-triggering themselves (e.g. a DAMAGE effect on HIT_ENTITY)

    public AbilityListener() {
        Bukkit.getScheduler().runTaskTimer(EasyItem.I, () -> {
            long now = System.currentTimeMillis();
            cooldowns.values().removeIf(v -> v < now);
            for (Player p : Bukkit.getOnlinePlayers()) {
                fire(p, p.getInventory().getItemInMainHand(), "HOLD", null, null);
                for (ItemStack armor : p.getInventory().getArmorContents()) fire(p, armor, "WEAR", null, null);
            }
        }, 20, 20);
    }

    private static boolean has(ItemStack it, String trigger) {
        return it != null && it.hasItemMeta() && ItemUtil.abilities(it).stream().anyMatch(a -> a.trigger().equals(trigger));
    }
    private static ItemStack hand(Player p) { return p.getInventory().getItemInMainHand(); }

    private void fire(Player p, ItemStack it, String trigger, Entity victim, Location at) {
        if (busy || p == null || it == null || !it.hasItemMeta()) return;
        List<Ability> list = ItemUtil.abilities(it);
        if (list.isEmpty()) return;
        busy = true;
        try {
            for (Ability ab : list) {
                if (!ab.trigger().equals(trigger)) continue;
                String key = p.getUniqueId() + ab.serialize();
                long now = System.currentTimeMillis();
                Long until = cooldowns.get(key);
                if (until != null && until > now) {
                    if (!trigger.equals("HOLD") && !trigger.equals("WEAR"))
                        p.sendActionBar(ItemUtil.color("&cCooldown: " + String.format("%.1f", (until - now) / 1000.0) + "s"));
                    continue;
                }
                if (ab.cooldown() > 0) cooldowns.put(key, now + (long) (ab.cooldown() * 1000));
                ab.run(p, victim, at);
            }
        } finally { busy = false; }
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        Action a = e.getAction();
        Player p = e.getPlayer();
        boolean right = a == Action.RIGHT_CLICK_AIR || a == Action.RIGHT_CLICK_BLOCK;
        boolean left = a == Action.LEFT_CLICK_AIR || a == Action.LEFT_CLICK_BLOCK;
        if (!right && !left) return;
        boolean sn = p.isSneaking();
        fire(p, e.getItem(), right ? (sn ? "SHIFT_RIGHT_CLICK" : "RIGHT_CLICK") : (sn ? "SHIFT_LEFT_CLICK" : "LEFT_CLICK"), null, null);
        if (e.getClickedBlock() != null)
            fire(p, e.getItem(), right ? "RIGHT_CLICK_BLOCK" : "LEFT_CLICK_BLOCK", null, e.getClickedBlock().getLocation().add(0.5, 1, 0.5));
    }

    @EventHandler
    public void onClickEntity(PlayerInteractEntityEvent e) {
        if (e.getHand() == EquipmentSlot.HAND) fire(e.getPlayer(), hand(e.getPlayer()), "RIGHT_CLICK_ENTITY", e.getRightClicked(), null);
    }

    @EventHandler
    public void onHit(EntityDamageByEntityEvent e) {
        if (e.getDamager() instanceof Player p) fire(p, hand(p), "HIT_ENTITY", e.getEntity(), null);
    }

    @EventHandler
    public void onDamaged(EntityDamageEvent e) {
        if (e.getEntity() instanceof Player p)
            fire(p, hand(p), "DAMAGED", e instanceof EntityDamageByEntityEvent x ? x.getDamager() : null, null);
    }

    @EventHandler
    public void onKill(EntityDeathEvent e) {
        Player k = e.getEntity().getKiller();
        if (k != null) fire(k, hand(k), "KILL", e.getEntity(), e.getEntity().getLocation());
    }

    @EventHandler
    public void onBreak(BlockBreakEvent e) {
        fire(e.getPlayer(), hand(e.getPlayer()), "BREAK_BLOCK", null, e.getBlock().getLocation().add(0.5, 0.5, 0.5));
    }

    @EventHandler
    public void onSneak(PlayerToggleSneakEvent e) {
        if (e.isSneaking()) fire(e.getPlayer(), hand(e.getPlayer()), "SNEAK", null, null);
    }

    @EventHandler
    public void onJump(PlayerJumpEvent e) { fire(e.getPlayer(), hand(e.getPlayer()), "JUMP", null, null); }

    @EventHandler
    public void onDrop(PlayerDropItemEvent e) {
        ItemStack it = e.getItemDrop().getItemStack();
        if (has(it, "DROP")) { e.setCancelled(true); fire(e.getPlayer(), it, "DROP", null, null); }
    }

    @EventHandler
    public void onSwap(PlayerSwapHandItemsEvent e) {
        ItemStack it = e.getOffHandItem(); // the item you were holding
        if (has(it, "SWAP_HAND")) { e.setCancelled(true); fire(e.getPlayer(), it, "SWAP_HAND", null, null); }
    }
}
