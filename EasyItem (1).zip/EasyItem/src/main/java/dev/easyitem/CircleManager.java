package dev.easyitem;

import org.bukkit.*;
import org.bukkit.block.*;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.block.*;
import org.bukkit.event.entity.EntityExplodeEvent;
import java.util.*;

/** Temporary block effects (circle, cage, wall). Everything placed here is restored later and can't be broken. */
public class CircleManager implements Listener {
    private record Entry(BlockData orig, long expire) {}
    private final Map<Block, Entry> map = new HashMap<>();

    public CircleManager() { Bukkit.getScheduler().runTaskTimer(EasyItem.I, this::tick, 10, 10); }

    private void tick() {
        long now = System.currentTimeMillis();
        map.entrySet().removeIf(en -> {
            if (en.getValue().expire() > now) return false;
            en.getKey().setBlockData(en.getValue().orig(), false);
            return true;
        });
    }

    private long exp(int seconds) {
        if (seconds <= 0) seconds = EasyItem.I.getConfig().getInt("circle.default-seconds", 10);
        return System.currentTimeMillis() + seconds * 1000L;
    }

    private boolean place(Block b, Material mat, long expire) {
        if (!mat.isBlock() || mat.isAir() || mat.hasGravity()) throw new IllegalArgumentException("Can't use " + mat + " here.");
        Entry old = map.get(b);
        if (old == null) {
            Set<String> bl = new HashSet<>(EasyItem.I.getConfig().getStringList("circle.blacklist"));
            if (bl.contains(b.getType().name()) || b.getState(false) instanceof TileState) return false;
        }
        map.put(b, new Entry(old != null ? old.orig() : b.getBlockData(), expire)); // overlap: keep the ORIGINAL block
        b.setType(mat, false);
        return true;
    }

    /** Ground under the player becomes `mat` in a circle. */
    public int create(Player p, int radius, int seconds, Material mat) {
        radius = Math.max(1, Math.min(radius, EasyItem.I.getConfig().getInt("circle.max-radius", 12)));
        Location l = p.getLocation();
        World w = l.getWorld();
        int y = l.getBlockY() - 1;
        while (y > l.getBlockY() - 4 && !w.getBlockAt(l.getBlockX(), y, l.getBlockZ()).getType().isSolid()) y--;
        long expire = exp(seconds);
        int changed = 0;
        for (int dx = -radius; dx <= radius; dx++)
            for (int dz = -radius; dz <= radius; dz++) {
                if (dx * dx + dz * dz > radius * radius) continue;
                Block b = w.getBlockAt(l.getBlockX() + dx, y, l.getBlockZ() + dz);
                Material t = b.getType();
                if (map.containsKey(b) || (t.isSolid() && t != mat)) if (place(b, mat, expire)) changed++;
            }
        return changed;
    }

    /** Hollow 3x3 shell (4 tall) around a location, e.g. to trap a mob. */
    public void cage(Location c, Material mat, int seconds) {
        long expire = exp(seconds);
        Block base = c.getBlock();
        for (int dx = -1; dx <= 1; dx++)
            for (int dz = -1; dz <= 1; dz++)
                for (int dy = -1; dy <= 2; dy++)
                    if (Math.abs(dx) == 1 || Math.abs(dz) == 1 || dy == -1 || dy == 2) place(base.getRelative(dx, dy, dz), mat, expire);
    }

    /** Wall in front of the player. */
    public void wall(Player p, Material mat, int width, int height, int seconds) {
        long expire = exp(seconds);
        BlockFace f = p.getFacing();
        Block base = p.getLocation().getBlock().getRelative(f, 3);
        boolean xAxis = f == BlockFace.NORTH || f == BlockFace.SOUTH;
        width = Math.min(width, 15); height = Math.min(height, 10);
        for (int i = -width / 2; i <= width / 2; i++)
            for (int h = 0; h < height; h++)
                place(base.getRelative(xAxis ? i : 0, h, xAxis ? 0 : i), mat, expire);
    }

    public void restoreAll() {
        map.forEach((b, en) -> b.setBlockData(en.orig(), false));
        map.clear();
    }

    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        if (!map.containsKey(e.getBlock())) return;
        e.setCancelled(true);
        e.getPlayer().sendActionBar(ItemUtil.color("&7These blocks are temporary."));
    }
    @EventHandler public void onExplode(EntityExplodeEvent e) { e.blockList().removeIf(map::containsKey); }
    @EventHandler public void onBlockExplode(BlockExplodeEvent e) { e.blockList().removeIf(map::containsKey); }
    @EventHandler public void onPistonExtend(BlockPistonExtendEvent e) { if (e.getBlocks().stream().anyMatch(map::containsKey)) e.setCancelled(true); }
    @EventHandler public void onPistonRetract(BlockPistonRetractEvent e) { if (e.getBlocks().stream().anyMatch(map::containsKey)) e.setCancelled(true); }
}
