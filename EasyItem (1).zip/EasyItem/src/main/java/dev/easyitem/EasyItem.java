package dev.easyitem;

import net.kyori.adventure.text.Component;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.*;
import org.bukkit.inventory.meta.components.CustomModelDataComponent;
import org.bukkit.plugin.java.JavaPlugin;
import java.io.*;
import java.util.*;
import java.util.function.Consumer;
import static dev.easyitem.ItemUtil.*;

public class EasyItem extends JavaPlugin implements TabExecutor {
    public static EasyItem I;
    public CircleManager circles;
    public Editor editor;
    private File itemFile;
    private YamlConfiguration items;

    @Override public void onEnable() {
        I = this;
        saveDefaultConfig();
        circles = new CircleManager();
        editor = new Editor();
        var pm = getServer().getPluginManager();
        pm.registerEvents(circles, this);
        pm.registerEvents(editor, this);
        pm.registerEvents(new AbilityListener(), this);
        pm.registerEvents(new ProtectListener(), this);
        getCommand("easyitem").setExecutor(this);
        itemFile = new File(getDataFolder(), "items.yml");
        items = YamlConfiguration.loadConfiguration(itemFile);
    }

    @Override public void onDisable() { if (circles != null) circles.restoreAll(); }

    public void saveItem(String id, ItemStack it) {
        if (it.getType().isAir()) throw new IllegalArgumentException("Hold an item first!");
        try { items.set("items." + id, it.clone()); items.save(itemFile); }
        catch (IOException e) { throw new RuntimeException("Couldn't save: " + e.getMessage()); }
    }
    private Set<String> itemIds() { var s = items.getConfigurationSection("items"); return s == null ? Set.of() : s.getKeys(false); }
    private Set<String> presetIds() { var s = getConfig().getConfigurationSection("presets"); return s == null ? Set.of() : s.getKeys(false); }

    /** Adds every ability line of a config preset to the meta. Line: TRIGGER EFFECT COOLDOWN [params] */
    public void applyPreset(ItemMeta m, String name) {
        List<String> lines = getConfig().getStringList("presets." + name);
        if (lines.isEmpty()) throw new IllegalArgumentException("Unknown preset: " + name + " (/ei preset list)");
        for (String line : lines) {
            String[] t = line.trim().split("\\s+", 4);
            String tr = t[0].toUpperCase(), ty = t[1].toUpperCase();
            if (!Ability.TRIGGERS.contains(tr) || !Ability.TYPES.contains(ty)) throw new IllegalArgumentException("Bad preset line: " + line);
            addAbility(m, new Ability(tr, ty, t.length > 3 ? t[3] : "", Double.parseDouble(t[2])));
        }
    }

    private void ed(Player p, Consumer<ItemMeta> c) { if (edit(p, c)) msg(p, "&aDone."); }

    private void help(Player p) {
        for (String l : new String[]{
            "&6&lEasyItem &7- hold an item, then:",
            "&e/ei gui &7- visual editor (easiest)",
            "&e/ei name <text> &7| &e/ei lore add|set|remove|clear",
            "&e/ei enchant <ench> <level> &7(unsafe, up to 255; 0 removes)",
            "&e/ei unbreakable &7| &e/ei glow &7| &e/ei flag <flag>",
            "&e/ei attribute <attr> <amount> [slot] [operation]",
            "&e/ei model <n> &7| &e/ei material <MAT> &7| &e/ei amount <n>",
            "&e/ei color <hex> &7(leather) | &e/ei skull <name> &7| &e/ei durability <n>",
            "&e/ei protect soulbound|undroppable|noplace",
            "&e/ei ability add <trigger> <effect> <cooldown> [params]",
            "&e/ei ability list|remove <n>|clear|trigger <n> <T>|cooldown <n> <s>|param <n> <text>",
            "&e/ei triggers &7| &e/ei effects &7- list everything you can use",
            "&e/ei preset <name|list> &7| &e/ei info",
            "&e/ei save|give|delete <id> &7| &e/ei list &7| &e/ei reload"})
            p.sendMessage(color(l));
    }

    @Override public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (!(s instanceof Player p)) { s.sendMessage("Players only."); return true; }
        if (a.length == 0) { help(p); return true; }
        try {
            switch (a[0].toLowerCase()) {
                case "gui", "editor" -> editor.open(p);
                case "name" -> { String n = txt(a, 1); ed(p, m -> m.displayName(color(n))); }
                case "lore" -> {
                    switch (a[1].toLowerCase()) {
                        case "add" -> { String t = txt(a, 2); ed(p, m -> { List<Component> lo = lore(m); lo.add(color(t)); m.lore(lo); }); }
                        case "set" -> {
                            int n = Integer.parseInt(a[2]) - 1; String t = txt(a, 3);
                            ed(p, m -> { List<Component> lo = lore(m); while (lo.size() <= n) lo.add(Component.empty()); lo.set(n, color(t)); m.lore(lo); });
                        }
                        case "remove" -> {
                            int n = Integer.parseInt(a[2]) - 1;
                            ed(p, m -> { List<Component> lo = lore(m); if (n >= 0 && n < lo.size()) lo.remove(n); m.lore(lo); });
                        }
                        case "clear" -> ed(p, m -> m.lore(null));
                        default -> help(p);
                    }
                }
                case "enchant" -> {
                    Enchantment en = enchant(a[1]);
                    if (en == null) throw new IllegalArgumentException("Unknown enchantment: " + a[1]);
                    int lv = Math.min(255, Integer.parseInt(a[2]));
                    ed(p, m -> { if (lv <= 0) m.removeEnchant(en); else m.addEnchant(en, lv, true); });
                }
                case "unbreakable" -> ed(p, m -> m.setUnbreakable(!m.isUnbreakable()));
                case "glow" -> ed(p, m -> m.setEnchantmentGlintOverride(!Boolean.TRUE.equals(m.getEnchantmentGlintOverride())));
                case "flag" -> {
                    ItemFlag f = ItemFlag.valueOf(a[1].toUpperCase());
                    ed(p, m -> { if (m.hasItemFlag(f)) m.removeItemFlags(f); else m.addItemFlags(f); });
                }
                case "attribute" -> ed(p, m -> addAttribute(m, a[1], Double.parseDouble(a[2]), a.length > 3 ? a[3] : "mainhand", a.length > 4 ? a[4] : "add_number"));
                case "model" -> { int v = Integer.parseInt(a[1]); ed(p, m -> { CustomModelDataComponent cm = m.getCustomModelDataComponent(); cm.setFloats(List.of((float) v)); m.setCustomModelDataComponent(cm); }); }
                case "material" -> {
                    ItemStack it = p.getInventory().getItemInMainHand();
                    p.getInventory().setItemInMainHand(it.withType(Material.valueOf(a[1].toUpperCase())));
                    msg(p, "&aDone.");
                }
                case "amount" -> { p.getInventory().getItemInMainHand().setAmount(Integer.parseInt(a[1])); msg(p, "&aDone."); }
                case "color" -> {
                    int rgb = Integer.parseInt(a[1].replace("#", ""), 16);
                    ed(p, m -> { if (!(m instanceof LeatherArmorMeta lm)) throw new IllegalArgumentException("Leather armor only."); lm.setColor(Color.fromRGB(rgb)); });
                }
                case "skull" -> ed(p, m -> { if (!(m instanceof SkullMeta sm)) throw new IllegalArgumentException("Hold a player head."); sm.setOwningPlayer(Bukkit.getOfflinePlayer(a[1])); });
                case "durability" -> {
                    int max = p.getInventory().getItemInMainHand().getType().getMaxDurability();
                    int left = Integer.parseInt(a[1]);
                    ed(p, m -> { if (!(m instanceof Damageable d)) throw new IllegalArgumentException("This item has no durability."); d.setDamage(Math.max(0, max - left)); });
                }
                case "protect" -> {
                    String f = a[1].toLowerCase();
                    if (!ProtectListener.FLAGS.contains(f)) throw new IllegalArgumentException("Flags: " + ProtectListener.FLAGS);
                    ed(p, m -> toggleFlag(m, f));
                }
                case "ability" -> ability(p, a);
                case "triggers" -> Ability.TRIGGERS.forEach(t -> msg(p, "&e" + t + " &7- " + Ability.TRIGGER_INFO.get(t)));
                case "effects" -> Ability.TYPES.forEach(t -> msg(p, "&b" + t + " &7" + Ability.HINT.getOrDefault(t, "")));
                case "preset" -> {
                    if (a[1].equalsIgnoreCase("list")) msg(p, "&7Presets: &f" + String.join(", ", presetIds()));
                    else ed(p, m -> applyPreset(m, a[1]));
                }
                case "info" -> {
                    ItemStack it = p.getInventory().getItemInMainHand();
                    ItemMeta m = it.getItemMeta();
                    msg(p, "&7Item: &f" + it.getType() + " x" + it.getAmount());
                    msg(p, "&7Enchants: &f" + (m.hasEnchants() ? m.getEnchants().size() : 0) + " &7| Lore lines: &f" + lore(m).size() + " &7| Flags: &f" + flags(m));
                    abilities(m).forEach(ab -> msg(p, "&6" + ab.trigger() + " &7-> &f" + ab.type() + " " + ab.param() + " &7(" + ab.cooldown() + "s)"));
                }
                case "save" -> { saveItem(a[1], p.getInventory().getItemInMainHand()); msg(p, "&aSaved as &e" + a[1]); }
                case "give" -> {
                    ItemStack it = items.getItemStack("items." + a[1]);
                    if (it == null) throw new IllegalArgumentException("No saved item: " + a[1]);
                    Player t = a.length > 2 ? Bukkit.getPlayer(a[2]) : p;
                    if (t == null) throw new IllegalArgumentException("Player not found.");
                    t.getInventory().addItem(it.clone());
                    msg(p, "&aGave &e" + a[1]);
                }
                case "delete" -> { items.set("items." + a[1], null); items.save(itemFile); msg(p, "&aDeleted."); }
                case "list" -> msg(p, "&7Saved items: &f" + String.join(", ", itemIds()));
                case "reload" -> { reloadConfig(); items = YamlConfiguration.loadConfiguration(itemFile); msg(p, "&aReloaded."); }
                default -> help(p);
            }
        } catch (ArrayIndexOutOfBoundsException ex) {
            msg(p, "&cMissing arguments. Type /ei for help.");
        } catch (Exception ex) {
            msg(p, "&c" + ex.getMessage());
        }
        return true;
    }

    private void ability(Player p, String[] a) {
        switch (a[1].toLowerCase()) {
            case "add" -> {
                String tr = a[2].toUpperCase(), ty = a[3].toUpperCase();
                if (!Ability.TRIGGERS.contains(tr)) throw new IllegalArgumentException("Triggers: " + Ability.TRIGGERS);
                if (!Ability.TYPES.contains(ty)) throw new IllegalArgumentException("Effects: " + Ability.TYPES);
                Ability ab = new Ability(tr, ty, txt(a, 5), Double.parseDouble(a[4]));
                ed(p, m -> addAbility(m, ab));
            }
            case "list" -> {
                var l = abilities(p.getInventory().getItemInMainHand());
                if (l.isEmpty()) msg(p, "&7No abilities.");
                for (int i = 0; i < l.size(); i++)
                    msg(p, "&e" + (i + 1) + ". &f" + l.get(i).trigger() + " &7-> &f" + l.get(i).type() + " " + l.get(i).param() + " &7(" + l.get(i).cooldown() + "s)");
            }
            case "remove" -> {
                int n = Integer.parseInt(a[2]) - 1;
                ed(p, m -> { List<Ability> l = abilities(m); if (n >= 0 && n < l.size()) l.remove(n); setAbilities(m, l); });
            }
            case "clear" -> ed(p, m -> setAbilities(m, new ArrayList<>()));
            case "trigger", "cooldown", "param" -> {
                int n = Integer.parseInt(a[2]) - 1;
                String what = a[1].toLowerCase(), v = txt(a, 3);
                ed(p, m -> {
                    List<Ability> l = abilities(m);
                    if (n < 0 || n >= l.size()) throw new IllegalArgumentException("No ability #" + (n + 1));
                    Ability o = l.get(n);
                    Ability nu;
                    if (what.equals("trigger")) {
                        String t = v.toUpperCase();
                        if (!Ability.TRIGGERS.contains(t)) throw new IllegalArgumentException("Triggers: " + Ability.TRIGGERS);
                        nu = new Ability(t, o.type(), o.param(), o.cooldown());
                    } else if (what.equals("cooldown")) nu = new Ability(o.trigger(), o.type(), o.param(), Double.parseDouble(v));
                    else nu = new Ability(o.trigger(), o.type(), v, o.cooldown());
                    l.set(n, nu);
                    setAbilities(m, l);
                });
            }
            default -> help(p);
        }
    }

    @Override public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        final List<String> o = new ArrayList<>();
        if (a.length == 1) o.addAll(List.of("gui", "name", "lore", "enchant", "unbreakable", "glow", "flag", "attribute", "model", "material", "amount",
            "color", "skull", "durability", "protect", "ability", "triggers", "effects", "preset", "info", "save", "give", "list", "delete", "reload"));
        else if (a.length == 2) {
            switch (a[0].toLowerCase()) {
                case "enchant" -> Registry.ENCHANTMENT.forEach(e -> o.add(e.getKey().getKey()));
                case "attribute" -> Registry.ATTRIBUTE.forEach(e -> o.add(e.getKey().getKey()));
                case "flag" -> { for (ItemFlag f : ItemFlag.values()) o.add(f.name().toLowerCase()); }
                case "lore" -> o.addAll(List.of("add", "set", "remove", "clear"));
                case "ability" -> o.addAll(List.of("add", "list", "remove", "clear", "trigger", "cooldown", "param"));
                case "protect" -> o.addAll(ProtectListener.FLAGS);
                case "preset" -> { o.add("list"); o.addAll(presetIds()); }
                case "give", "delete" -> o.addAll(itemIds());
            }
        } else if (a.length == 3 && a[0].equalsIgnoreCase("ability") && (a[1].equalsIgnoreCase("add"))) o.addAll(Ability.TRIGGERS);
        else if (a.length == 4 && a[0].equalsIgnoreCase("ability") && a[1].equalsIgnoreCase("trigger")) o.addAll(Ability.TRIGGERS);
        else if (a.length == 4 && a[0].equalsIgnoreCase("ability") && a[1].equalsIgnoreCase("add")) o.addAll(Ability.TYPES);
        String last = a[a.length - 1].toLowerCase();
        return o.stream().filter(x -> x.toLowerCase().startsWith(last)).toList();
    }
}
