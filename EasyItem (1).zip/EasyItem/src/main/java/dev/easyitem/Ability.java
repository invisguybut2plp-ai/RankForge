package dev.easyitem;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.*;
import org.bukkit.potion.*;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

/** One ability: WHEN (trigger) -> DO (type + params), with a cooldown. Stored on the item as TRIGGER|TYPE|PARAM|COOLDOWN. */
public record Ability(String trigger, String type, String param, double cooldown) {

    public static final List<String> TRIGGERS = List.of(
        "RIGHT_CLICK", "LEFT_CLICK", "SHIFT_RIGHT_CLICK", "SHIFT_LEFT_CLICK", "RIGHT_CLICK_BLOCK", "LEFT_CLICK_BLOCK",
        "RIGHT_CLICK_ENTITY", "HIT_ENTITY", "DROP", "SWAP_HAND", "SNEAK", "JUMP", "KILL", "DAMAGED", "BREAK_BLOCK", "HOLD", "WEAR");

    public static final Map<String, String> TRIGGER_INFO = Map.ofEntries(
        Map.entry("RIGHT_CLICK", "any right click"), Map.entry("LEFT_CLICK", "any left click"),
        Map.entry("SHIFT_RIGHT_CLICK", "sneak + right click"), Map.entry("SHIFT_LEFT_CLICK", "sneak + left click"),
        Map.entry("RIGHT_CLICK_BLOCK", "right click a block"), Map.entry("LEFT_CLICK_BLOCK", "left click a block"),
        Map.entry("RIGHT_CLICK_ENTITY", "right click a mob/player"), Map.entry("HIT_ENTITY", "hit a mob/player"),
        Map.entry("DROP", "press Q (item stays)"), Map.entry("SWAP_HAND", "press F (no swap)"),
        Map.entry("SNEAK", "start sneaking"), Map.entry("JUMP", "jump"), Map.entry("KILL", "kill something"),
        Map.entry("DAMAGED", "you take damage"), Map.entry("BREAK_BLOCK", "break a block"),
        Map.entry("HOLD", "every second while held"), Map.entry("WEAR", "every second while worn"));

    public static final List<String> TYPES = List.of(
        "PARTICLE", "PARTICLE_SHAPE", "CIRCLE", "CAGE", "WALL", "POTION", "CLEANSE", "HEAL", "FEED", "LIGHTNING", "STORM",
        "EXPLOSION", "TNT", "SMASH", "SHOCKWAVE", "PULL", "FREEZE", "IGNITE", "DAMAGE", "THROW", "LAUNCH", "LEAP",
        "TELEPORT", "PROJECTILE", "FIREBALL", "FLAMETHROWER", "ARROW_RAIN", "SUMMON", "SOUND", "MESSAGE", "ACTIONBAR",
        "TITLE", "COMMAND", "PLAYER_COMMAND");

    /** Example params, shown in the GUI and /ei effects. */
    public static final Map<String, String> HINT = Map.ofEntries(
        Map.entry("PARTICLE", "FLAME 40"), Map.entry("PARTICLE_SHAPE", "RING|SPHERE|HELIX|LINE FLAME 3"),
        Map.entry("CIRCLE", "4 10 GLASS  (radius seconds block)"), Map.entry("CAGE", "ICE 5  (block seconds, traps target)"),
        Map.entry("WALL", "STONE 5 3 10  (block width height seconds)"), Map.entry("POTION", "SPEED 10 1  (effect seconds level)"),
        Map.entry("CLEANSE", ""), Map.entry("HEAL", "6"), Map.entry("FEED", ""), Map.entry("LIGHTNING", ""),
        Map.entry("STORM", "6 6  (bolts radius)"), Map.entry("EXPLOSION", "3  (no block damage)"),
        Map.entry("TNT", "40 3  (fuse ticks, count)"), Map.entry("SMASH", "5 8  (radius damage)"),
        Map.entry("SHOCKWAVE", "6 1.5  (radius force)"), Map.entry("PULL", "8 1.2  (radius force)"),
        Map.entry("FREEZE", "3 4  (radius seconds)"), Map.entry("IGNITE", "3 5  (radius seconds)"),
        Map.entry("DAMAGE", "6 3  (amount radius)"), Map.entry("THROW", "3 1.2  (radius height)"),
        Map.entry("LAUNCH", "1.5"), Map.entry("LEAP", "1.2 0.5  (up forward)"), Map.entry("TELEPORT", "25  (max blocks)"),
        Map.entry("PROJECTILE", "SMALL_FIREBALL 2  (entity speed)"), Map.entry("FIREBALL", ""),
        Map.entry("FLAMETHROWER", "3  (seconds)"), Map.entry("ARROW_RAIN", "20 4  (arrows radius)"),
        Map.entry("SUMMON", "ZOMBIE 2"), Map.entry("SOUND", "entity.wither.spawn 1 1"),
        Map.entry("MESSAGE", "&aHello %player%!"), Map.entry("ACTIONBAR", "&bBoom!"), Map.entry("TITLE", "&cBOOM|&7subtitle"),
        Map.entry("COMMAND", "give %player% diamond 1  (console)"), Map.entry("PLAYER_COMMAND", "spawn  (as the player)"));

    public String serialize() { return trigger + "|" + type + "|" + param.replace("|", "%7C") + "|" + cooldown; }

    public static Ability parse(String s) {
        String[] p = s.split("\\|", 4);
        return new Ability(p[0], p[1], p[2].replace("%7C", "|"), Double.parseDouble(p[3]));
    }

    // ---------- helpers ----------
    private static double d(String[] a, int i, double def) { return a.length > i ? Double.parseDouble(a[i]) : def; }
    private static int n(String[] a, int i, int def) { return a.length > i ? Integer.parseInt(a[i]) : def; }
    private static Material mat(String s) { return Material.valueOf(s.toUpperCase()); }
    private static Particle particle(String s) {
        Particle t = Registry.PARTICLE_TYPE.get(NamespacedKey.minecraft(s.toLowerCase()));
        if (t == null) throw new IllegalArgumentException("Unknown particle: " + s);
        return t;
    }
    private static EntityType entity(String s) {
        EntityType t = Registry.ENTITY_TYPE.get(NamespacedKey.minecraft(s.toLowerCase()));
        if (t == null) throw new IllegalArgumentException("Unknown entity: " + s);
        return t;
    }
    private static double rnd(double r) { return ThreadLocalRandom.current().nextDouble(-r, r); }
    private static PotionEffectType eff(String s) {
        PotionEffectType t = Registry.EFFECT.get(NamespacedKey.minecraft(s.toLowerCase()));
        if (t == null) throw new IllegalArgumentException("Unknown potion effect: " + s);
        return t;
    }
    static Location target(Player p) {
        var b = p.getTargetBlockExact(40);
        return b != null ? b.getLocation().add(0.5, 1, 0.5) : p.getEyeLocation().add(p.getLocation().getDirection().multiply(20));
    }
    private static List<LivingEntity> near(Player p, Location at, double r) {
        List<LivingEntity> out = new ArrayList<>();
        for (Entity e : at.getWorld().getNearbyEntities(at, r, r, r))
            if (e instanceof LivingEntity le && e != p && !(e instanceof ArmorStand)) out.add(le);
        return out;
    }

    // ---------- the effects ----------
    public void run(Player p, Entity victim, Location ctx) {
        String[] a = param.isBlank() ? new String[0] : param.trim().split("\\s+");
        World w = p.getWorld();
        Location at = ctx != null ? ctx : victim != null ? victim.getLocation() : target(p);
        String text = param.replace("%player%", p.getName()).replace("%target%", victim != null ? victim.getName() : "");
        try {
            switch (type) {
                case "PARTICLE" -> w.spawnParticle(particle(a[0]), p.getLocation().add(0, 1, 0), n(a, 1, 30), 0.5, 0.7, 0.5, 0.05);
                case "PARTICLE_SHAPE" -> shape(p, a);
                case "CIRCLE" -> {
                    int cnt = EasyItem.I.circles.create(p, n(a, 0, 4), n(a, 1, 10), mat(a[2]));
                    if (cnt == 0) ItemUtil.msg(p, "&7No blocks to transform here.");
                }
                case "CAGE" -> EasyItem.I.circles.cage(at, mat(a[0]), n(a, 1, 10));
                case "WALL" -> EasyItem.I.circles.wall(p, mat(a[0]), n(a, 1, 5), n(a, 2, 3), n(a, 3, 10));
                case "POTION" -> {
                    LivingEntity le = victim instanceof LivingEntity x ? x : p;
                    le.addPotionEffect(new PotionEffect(eff(a[0]), n(a, 1, 10) * 20, n(a, 2, 0)));
                }
                case "CLEANSE" -> new ArrayList<>(p.getActivePotionEffects()).forEach(pe -> p.removePotionEffect(pe.getType()));
                case "HEAL" -> p.setHealth(Math.min(p.getAttribute(Attribute.MAX_HEALTH).getValue(), p.getHealth() + d(a, 0, 4)));
                case "FEED" -> { p.setFoodLevel(20); p.setSaturation(20f); }
                case "LIGHTNING" -> w.strikeLightning(at);
                case "STORM" -> { for (int i = 0; i < n(a, 0, 5); i++) w.strikeLightning(at.clone().add(rnd(d(a, 1, 5)), 0, rnd(d(a, 1, 5)))); }
                case "EXPLOSION" -> w.createExplosion(at, (float) d(a, 0, 3), false, false, p);
                case "TNT" -> { for (int i = 0; i < n(a, 1, 1); i++) w.spawn(at.clone().add(0, 0.5, 0), TNTPrimed.class, t -> { t.setFuseTicks(n(a, 0, 40)); t.setSource(p); }); }
                case "SMASH" -> {
                    w.spawnParticle(Particle.EXPLOSION, p.getLocation(), 3, 1, 0.2, 1, 0);
                    for (LivingEntity le : near(p, p.getLocation(), d(a, 0, 5))) { le.damage(d(a, 1, 6), p); le.setVelocity(le.getVelocity().setY(0.9)); }
                }
                case "SHOCKWAVE" -> {
                    for (LivingEntity le : near(p, p.getLocation(), d(a, 0, 6))) {
                        Vector v = le.getLocation().toVector().subtract(p.getLocation().toVector()).setY(0);
                        if (v.lengthSquared() > 0) v.normalize();
                        le.setVelocity(v.multiply(d(a, 1, 1.5)).setY(0.4));
                    }
                }
                case "PULL" -> {
                    for (LivingEntity le : near(p, p.getLocation(), d(a, 0, 8))) {
                        Vector v = p.getLocation().toVector().subtract(le.getLocation().toVector());
                        if (v.lengthSquared() > 0) v.normalize();
                        le.setVelocity(v.multiply(d(a, 1, 1.2)).setY(0.3));
                    }
                }
                case "FREEZE" -> {
                    int sec = n(a, 1, 5);
                    for (LivingEntity le : near(p, at, d(a, 0, 3))) { le.addPotionEffect(new PotionEffect(eff("slowness"), sec * 20, 9)); le.setFreezeTicks(sec * 20 + 140); }
                }
                case "IGNITE" -> { for (LivingEntity le : near(p, at, d(a, 0, 3))) le.setFireTicks(n(a, 1, 5) * 20); }
                case "DAMAGE" -> { for (LivingEntity le : near(p, at, d(a, 1, 2.5))) le.damage(d(a, 0, 5), p); }
                case "THROW" -> { for (LivingEntity le : near(p, at, d(a, 0, 3))) le.setVelocity(new Vector(0, d(a, 1, 1.2), 0)); }
                case "LAUNCH" -> p.setVelocity(p.getLocation().getDirection().multiply(d(a, 0, 1.5)));
                case "LEAP" -> {
                    Vector dir = p.getLocation().getDirection(); dir.setY(0);
                    if (dir.lengthSquared() > 0) dir.normalize();
                    p.setVelocity(dir.multiply(d(a, 1, 0.5)).setY(d(a, 0, 1.0)));
                }
                case "TELEPORT" -> {
                    double dist = d(a, 0, 25);
                    Vector dir = p.getEyeLocation().getDirection();
                    RayTraceResult r = p.rayTraceBlocks(dist);
                    Location dest = (r != null ? r.getHitPosition().toLocation(w).subtract(dir.clone().multiply(0.7))
                                               : p.getEyeLocation().add(dir.clone().multiply(dist))).subtract(0, 1.6, 0);
                    dest.setYaw(p.getLocation().getYaw()); dest.setPitch(p.getLocation().getPitch());
                    w.spawnParticle(Particle.PORTAL, p.getLocation().add(0, 1, 0), 40, 0.3, 0.6, 0.3, 0.5);
                    p.teleport(dest);
                    w.spawnParticle(Particle.PORTAL, dest.clone().add(0, 1, 0), 40, 0.3, 0.6, 0.3, 0.5);
                }
                case "PROJECTILE" -> {
                    Vector dir = p.getEyeLocation().getDirection();
                    Entity en = w.spawnEntity(p.getEyeLocation().add(dir.clone().multiply(1.2)), entity(a[0]));
                    if (en instanceof Projectile pr) pr.setShooter(p);
                    if (en instanceof Fireball f) f.setDirection(dir); else en.setVelocity(dir.multiply(d(a, 1, 2)));
                }
                case "FIREBALL" -> p.launchProjectile(Fireball.class);
                case "FLAMETHROWER" -> flame(p, d(a, 0, 3));
                case "ARROW_RAIN" -> {
                    for (int i = 0; i < n(a, 0, 20); i++) {
                        Arrow ar = w.spawnArrow(at.clone().add(rnd(d(a, 1, 4)), 15, rnd(d(a, 1, 4))), new Vector(0, -1, 0), 2f, 0f);
                        ar.setShooter(p); ar.setPickupStatus(AbstractArrow.PickupStatus.DISALLOWED);
                    }
                }
                case "SUMMON" -> { EntityType et = entity(a[0]); for (int i = 0; i < Math.min(n(a, 1, 1), 20); i++) w.spawnEntity(at, et); }
                case "SOUND" -> w.playSound(p.getLocation(), a[0], (float) d(a, 1, 1), (float) d(a, 2, 1));
                case "MESSAGE" -> p.sendMessage(ItemUtil.color(text));
                case "ACTIONBAR" -> p.sendActionBar(ItemUtil.color(text));
                case "TITLE" -> { String[] t = text.split("\\|", 2); p.showTitle(Title.title(ItemUtil.color(t[0]), t.length > 1 ? ItemUtil.color(t[1]) : Component.empty())); }
                case "COMMAND" -> Bukkit.dispatchCommand(Bukkit.getConsoleSender(), text);
                case "PLAYER_COMMAND" -> p.performCommand(text);
                default -> throw new IllegalArgumentException("Unknown effect");
            }
        } catch (Exception ex) {
            ItemUtil.msg(p, "&cAbility error (" + type + "): " + ex.getMessage());
        }
    }

    private static void shape(Player p, String[] a) {
        String sh = a[0].toUpperCase();
        Particle pt = particle(a[1]);
        double r = d(a, 2, 3);
        World w = p.getWorld();
        Location c = sh.equals("LINE") ? p.getEyeLocation() : p.getLocation();
        switch (sh) {
            case "RING" -> { for (int i = 0; i < 60; i++) { double t = i * Math.PI / 30; w.spawnParticle(pt, c.clone().add(Math.cos(t) * r, 0.2, Math.sin(t) * r), 1, 0, 0, 0, 0); } }
            case "SPHERE" -> { for (int i = 0; i < 120; i++) { double y = 1 - 2.0 * i / 119, rad = Math.sqrt(1 - y * y), t = i * 2.399963; w.spawnParticle(pt, c.clone().add(Math.cos(t) * rad * r, y * r + 1, Math.sin(t) * rad * r), 1, 0, 0, 0, 0); } }
            case "HELIX" -> { for (int i = 0; i < 80; i++) { double t = i * 0.45; w.spawnParticle(pt, c.clone().add(Math.cos(t) * r * 0.6, i * 0.05, Math.sin(t) * r * 0.6), 1, 0, 0, 0, 0); } }
            case "LINE" -> { Vector dir = c.getDirection(); for (double i = 0; i < r * 5; i += 0.4) w.spawnParticle(pt, c.clone().add(dir.clone().multiply(i)), 1, 0, 0, 0, 0); }
            default -> throw new IllegalArgumentException("Shapes: RING SPHERE HELIX LINE");
        }
    }

    private static void flame(Player p, double seconds) {
        int[] ticks = {0};
        int max = (int) (seconds * 10);
        Bukkit.getScheduler().runTaskTimer(EasyItem.I, task -> {
            if (!p.isOnline() || ticks[0]++ >= max) { task.cancel(); return; }
            Location eye = p.getEyeLocation();
            Vector dir = eye.getDirection();
            for (int i = 1; i <= 8; i++) {
                Location l = eye.clone().add(dir.clone().multiply(i * 0.8));
                p.getWorld().spawnParticle(Particle.FLAME, l, 3, 0.15, 0.15, 0.15, 0.01);
                for (Entity en : p.getWorld().getNearbyEntities(l, 1, 1, 1)) if (en instanceof LivingEntity le && en != p) le.setFireTicks(60);
            }
        }, 0, 2);
    }
}
