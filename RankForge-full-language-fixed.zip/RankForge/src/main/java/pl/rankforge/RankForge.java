package pl.rankforge;

import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.permissions.Permission;
import org.bukkit.plugin.java.JavaPlugin;
import pl.rankforge.gui.GuiListener;
import pl.rankforge.kit.KitCommand;
import pl.rankforge.kit.KitListener;
import pl.rankforge.kit.KitManager;
import pl.rankforge.kit.KitUtil;
import pl.rankforge.kit.Lang;
import pl.rankforge.kit.gui.KitItemsEditor;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

public class RankForge extends JavaPlugin {
    public record PendingInput(Consumer<String> handler, Runnable onCancel) {}

    private static final MiniMessage MM = MiniMessage.miniMessage();
    private RankManager ranks;
    private ResourcePackService pack;
    private KitManager kits;
    private final Map<UUID, PendingInput> inputs = new ConcurrentHashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        Lang.load(this);   // must be first: every text below (logs, GUIs, messages) comes from lang/<language>.yml
        applyCommandTexts();
        ranks = new RankManager(this);
        ranks.load();
        pack = new ResourcePackService(this);
        pack.start();

        Bukkit.getPluginManager().registerEvents(new GuiListener(), this);
        Bukkit.getPluginManager().registerEvents(new ChatListener(this), this);

        RankCommand cmd = new RankCommand(this);
        getCommand("rank").setExecutor(cmd);
        getCommand("rank").setTabCompleter(cmd);

        kits = new KitManager(this);
        kits.load();
        Bukkit.getPluginManager().registerEvents(new KitListener(this, kits), this);
        KitCommand kitCmd = new KitCommand(this, kits);
        getCommand("kit").setExecutor(kitCmd);
        getCommand("kit").setTabCompleter(kitCmd);

        if (Bukkit.getPluginManager().isPluginEnabled("PlaceholderAPI")) {
            pl.rankforge.kit.KitPlaceholders.hook(this, kits);
        }

        ranks.applyAll();
        getLogger().info(Lang.s("log.enabled", "count", String.valueOf(ranks.sorted().size())));
    }

    @Override
    public void onDisable() {
        for (Player pl : Bukkit.getOnlinePlayers()) {
            if (pl.getOpenInventory().getTopInventory().getHolder() instanceof KitItemsEditor) pl.closeInventory();
        }
        if (kits != null) kits.shutdown();
        if (pack != null) pack.stop();
        if (ranks != null) ranks.shutdown();
    }

    public ResourcePackService pack() {
        return pack;
    }

    public KitManager kits() {
        return kits;
    }

    public RankManager ranks() {
        return ranks;
    }

    public Map<UUID, PendingInput> inputs() {
        return inputs;
    }

    /** Sends an already-translated MiniMessage text with the localized [Ranks] prefix. */
    public void msg(CommandSender s, String mini) {
        s.sendMessage(KitUtil.mm(Lang.s("rank.prefix") + mini));
    }

    /** Sends the text lang key "rank.<key>" (placeholders: name, value, name, value...). Values are tag-escaped. */
    public void tr(CommandSender s, String key, String... kv) {
        String[] esc = kv.clone();
        for (int i = 1; i < esc.length; i += 2) esc[i] = MM.escapeTags(esc[i] == null ? "" : esc[i]);
        msg(s, Lang.s("rank." + key, esc));
    }

    /**
     * Re-reads config.yml and the language file, and refreshes everything that is cached in the
     * active language (rank hover text, command descriptions, permission descriptions).
     */
    public void reloadLanguage() {
        reloadConfig();
        Lang.load(this);
        if (ranks != null) ranks.clearCache();
        applyCommandTexts();
    }

    /** Command and permission descriptions (shown by /help and permission plugins) in the active language. */
    private void applyCommandTexts() {
        PluginCommand rc = getCommand("rank");
        if (rc != null) rc.setDescription(Lang.s("cmd.rank"));
        PluginCommand kc = getCommand("kit");
        if (kc != null) kc.setDescription(Lang.s("cmd.kit"));
        String[][] perms = {
                {"rankforge.admin", "admin"}, {"rankforge.kit", "kit"},
                {"rankforge.kit.admin", "kit-admin"}, {"rankforge.kit.bypass", "kit-bypass"}};
        for (String[] pm : perms) {
            Permission perm = Bukkit.getPluginManager().getPermission(pm[0]);
            if (perm != null) perm.setDescription(Lang.s("cmd.perm." + pm[1]));
        }
    }

    /** Closes the GUI and waits for the player's chat message (they type "cancel"/"anuluj" to go back). */
    public void awaitInput(Player p, String prompt, Consumer<String> handler, Runnable onCancel) {
        inputs.put(p.getUniqueId(), new PendingInput(handler, onCancel));
        Bukkit.getScheduler().runTask(this, (Runnable) p::closeInventory);
        msg(p, prompt);
    }
}
